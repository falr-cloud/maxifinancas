# MAXI FINANÇAS - Sistema de Gestão Financeira

## 📋 Descrição
Sistema de gestão financeira recriado com base no vídeo fornecido, mantendo o visual idêntico ao original. O front-end foi desenvolvido em React com interface moderna e responsiva.

## 🚀 Tecnologias Utilizadas
- **React 18** - Framework principal
- **Tailwind CSS** - Estilização
- **Shadcn/UI** - Componentes de interface
- **Lucide React** - Ícones
- **Vite** - Build tool

## 🎨 Características da Interface

### Layout Principal
- **Header**: Logo MF + título "MAXI FINANÇAS" + botão Sair
- **Sidebar**: Menu lateral com Dashboard, Transações, Relatórios e Configurações
- **Conteúdo Principal**: Área de trabalho com a página de Transações

### Página de Transações
- **Botões de Ação Coloridos**:
  - Selecionar Todos (laranja)
  - Importar (verde)
  - Exportar (roxo)
  - Gerar Categorias (azul)
  - Gerar Centros de Custo (azul escuro)
  - Criar Lançamento (verde claro)
  - Deletar Todos (vermelho)

- **Seção de Filtros**:
  - Data Início e Data Fim
  - Busca por descrição
  - Filtro por categoria
  - Filtro por centro de custo
  - Botões Filtrar e Desfazer Filtros
  - Opção de minimizar/expandir

- **Card de Saldo**:
  - Exibe saldo bancário atual
  - Valores negativos em vermelho
  - Ícone de cifrão

- **Tabela de Transações**:
  - Colunas: Data, Descrição, Categoria, Centro de Custo, Valor, Ações
  - Valores negativos em vermelho
  - Botão de exclusão por linha
  - Clique na linha abre modal de edição

- **Modal de Edição**:
  - Campos: Data, Descrição, Categoria, Centro de Custo, Valor, Observações
  - Botões Cancelar e Salvar
  - Validação visual dos campos obrigatórios

## 📊 Dados Mock
O sistema inclui dados de exemplo idênticos aos do vídeo original:
- 8 transações de exemplo
- Saldo total: -R$ 9.646,54
- Categorias e centros de custo pré-definidos

## 🔧 Funcionalidades Implementadas (Front-end)

### ✅ Funcionais
- Visualização de transações
- Filtros por descrição (busca)
- Modal de edição de transações
- Cálculo automático do saldo
- Interface responsiva
- Navegação entre componentes

### 🎯 Simuladas (Sem Backend)
- Importação/Exportação de dados
- Geração de categorias e centros de custo
- Criação de novos lançamentos
- Exclusão de transações
- Filtros por data, categoria e centro de custo
- Salvamento de alterações

## 🚀 Como Executar

### Pré-requisitos
- Node.js 18+
- pnpm (ou npm/yarn)

### Instalação e Execução
```bash
# Navegar para o diretório do projeto
cd maxi-financas

# Instalar dependências (já instaladas)
pnpm install

# Executar em modo desenvolvimento
pnpm run dev --host

# Acessar no navegador
http://localhost:5173
```

### Build para Produção
```bash
# Gerar build de produção
pnpm run build

# Visualizar build localmente
pnpm run preview
```

## 📱 Responsividade
- **Desktop**: Layout completo com sidebar fixa
- **Tablet**: Adaptações nos filtros e tabela
- **Mobile**: Menu lateral colapsável, tabela com scroll horizontal

## 🎨 Esquema de Cores
- **Azul primário**: #007bff (botões principais, logo)
- **Verde**: #28a745 (ações positivas)
- **Vermelho**: #dc3545 (valores negativos, exclusões)
- **Laranja**: #fd7e14 (seleção)
- **Roxo**: #6f42c1 (exportação)
- **Cinza claro**: Backgrounds e bordas

## 📁 Estrutura do Projeto
```
src/
├── components/
│   ├── layout/          # Header, Sidebar, MainContent
│   ├── transacoes/      # Componentes específicos de transações
│   └── ui/              # Componentes base (shadcn/ui)
├── pages/               # Páginas da aplicação
├── data/                # Dados mock
└── App.jsx              # Componente principal
```

## 🔄 Próximos Passos
Para implementar as funcionalidades backend:
1. Integrar com API REST
2. Implementar autenticação
3. Adicionar persistência de dados
4. Implementar upload/download de arquivos
5. Adicionar validações server-side
6. Implementar relatórios dinâmicos

## 📝 Notas Técnicas
- Interface idêntica ao vídeo original
- Código limpo e bem estruturado
- Componentes reutilizáveis
- Preparado para integração com backend
- Totalmente funcional no front-end

