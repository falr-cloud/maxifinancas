import { AlertTriangle, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

const DeleteAllModal = ({ isOpen, onClose, onConfirm, totalTransacoes }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
        {/* Header */}
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
            <AlertTriangle className="w-6 h-6 text-red-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">
              Deletar Todos os Lançamentos
            </h3>
            <p className="text-sm text-gray-500">
              Esta ação não pode ser desfeita
            </p>
          </div>
        </div>

        {/* Content */}
        <div className="mb-6">
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
            <div className="flex items-start space-x-3">
              <Trash2 className="w-5 h-5 text-red-500 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-red-800">
                  Atenção: Exclusão Permanente
                </p>
                <p className="text-sm text-red-700 mt-1">
                  Você está prestes a deletar <strong>{totalTransacoes} transação(ões)</strong> permanentemente do banco de dados.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-2 text-sm text-gray-600">
            <p>• Todos os lançamentos serão removidos</p>
            <p>• O saldo será zerado</p>
            <p>• Esta ação é irreversível</p>
            <p>• Não há como recuperar os dados após a exclusão</p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex space-x-3">
          <Button
            variant="outline"
            onClick={onClose}
            className="flex-1"
          >
            Cancelar
          </Button>
          <Button
            variant="destructive"
            onClick={onConfirm}
            className="flex-1 bg-red-600 hover:bg-red-700"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Deletar Todos
          </Button>
        </div>

        {/* Warning footer */}
        <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
          <p className="text-xs text-yellow-800 text-center">
            ⚠️ Certifique-se de ter um backup dos dados antes de prosseguir
          </p>
        </div>
      </div>
    </div>
  );
};

export default DeleteAllModal;

