import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ChevronUp, ChevronDown } from 'lucide-react';

const FilterSection = ({ onFilter, onClearFilters }) => {
  const [isMinimized, setIsMinimized] = useState(false);
  const [filters, setFilters] = useState({
    dataInicio: '',
    dataFim: '',
    buscar: '',
    categoria: '',
    centroCusto: '',
    buscarDescricao: ''
  });

  const handleInputChange = (field, value) => {
    setFilters(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleFilter = () => {
    onFilter(filters);
  };

  const handleClearFilters = () => {
    setFilters({
      dataInicio: '',
      dataFim: '',
      buscar: '',
      categoria: '',
      centroCusto: '',
      buscarDescricao: ''
    });
    onClearFilters();
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 mb-6">
      {/* Header dos filtros */}
      <div className="flex justify-between items-center p-4 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-800">Filtros</h3>
        <button
          onClick={() => setIsMinimized(!isMinimized)}
          className="flex items-center text-sm text-gray-600 hover:text-gray-800"
        >
          {isMinimized ? (
            <>
              <ChevronDown className="w-4 h-4 mr-1" />
              EXPANDIR
            </>
          ) : (
            <>
              <ChevronUp className="w-4 h-4 mr-1" />
              MINIMIZAR
            </>
          )}
        </button>
      </div>

      {/* Conteúdo dos filtros */}
      {!isMinimized && (
        <div className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            {/* Data Início */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Data Início
              </label>
              <Input
                type="date"
                value={filters.dataInicio}
                onChange={(e) => handleInputChange('dataInicio', e.target.value)}
                className="w-full"
              />
            </div>

            {/* Data Fim */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Data Fim
              </label>
              <Input
                type="date"
                value={filters.dataFim}
                onChange={(e) => handleInputChange('dataFim', e.target.value)}
                className="w-full"
              />
            </div>

            {/* Buscar */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Buscar
              </label>
              <Input
                type="text"
                placeholder="Descrição..."
                value={filters.buscar}
                onChange={(e) => handleInputChange('buscar', e.target.value)}
                className="w-full"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            {/* Categoria */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Categoria
              </label>
              <select
                value={filters.categoria}
                onChange={(e) => handleInputChange('categoria', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Nenhuma categoria disponível</option>
              </select>
            </div>

            {/* Centros de Custo */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Centros de Custo
              </label>
              <select
                value={filters.centroCusto}
                onChange={(e) => handleInputChange('centroCusto', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Nenhum centro de custo disponível</option>
              </select>
            </div>
          </div>

          {/* Campo de busca adicional */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Buscar
            </label>
            <Input
              type="text"
              placeholder="Descrição..."
              value={filters.buscarDescricao}
              onChange={(e) => handleInputChange('buscarDescricao', e.target.value)}
              className="w-full"
            />
          </div>

          {/* Botões de ação */}
          <div className="flex gap-3">
            <Button
              onClick={handleFilter}
              className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2"
            >
              Filtrar
            </Button>
            <Button
              onClick={handleClearFilters}
              variant="destructive"
              className="bg-red-500 hover:bg-red-600 text-white px-6 py-2"
            >
              DESFAZER FILTROS
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default FilterSection;

