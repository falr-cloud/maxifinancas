import { Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

const TransacoesTable = ({ 
  transacoes, 
  onEdit, 
  onDelete, 
  selectedTransacoes = [], 
  onSelectTransacao, 
  onSelectAll 
}) => {
  const formatarMoeda = (valor) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(valor);
  };

  const isAllSelected = transacoes.length > 0 && selectedTransacoes.length === transacoes.length;
  const isIndeterminate = selectedTransacoes.length > 0 && selectedTransacoes.length < transacoes.length;

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
      {/* Header da tabela */}
      <div className="p-4 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-800">
          Transações
        </h3>
        <p className="text-sm text-gray-600">
          {transacoes.length} transação(ões) encontrada(s)
          {selectedTransacoes.length > 0 && (
            <span className="ml-2 text-blue-600 font-medium">
              • {selectedTransacoes.length} selecionada(s)
            </span>
          )}
        </p>
      </div>

      {/* Tabela */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                <input
                  type="checkbox"
                  checked={isAllSelected}
                  ref={(el) => {
                    if (el) el.indeterminate = isIndeterminate;
                  }}
                  onChange={onSelectAll}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                DATA
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                DESCRIÇÃO
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                CATEGORIA
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                CENTRO DE CUSTO
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                VALOR
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                AÇÕES
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {transacoes.map((transacao) => (
              <tr 
                key={transacao.id} 
                className={`hover:bg-gray-50 ${selectedTransacoes.includes(transacao.id) ? 'bg-blue-50' : ''}`}
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <input
                    type="checkbox"
                    checked={selectedTransacoes.includes(transacao.id)}
                    onChange={() => onSelectTransacao(transacao.id)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    onClick={(e) => e.stopPropagation()}
                  />
                </td>
                <td 
                  className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 cursor-pointer"
                  onClick={() => onEdit(transacao)}
                >
                  {transacao.data}
                </td>
                <td 
                  className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 cursor-pointer"
                  onClick={() => onEdit(transacao)}
                >
                  {transacao.descricao}
                </td>
                <td 
                  className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 cursor-pointer"
                  onClick={() => onEdit(transacao)}
                >
                  {transacao.categoria}
                </td>
                <td 
                  className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 cursor-pointer"
                  onClick={() => onEdit(transacao)}
                >
                  {transacao.centroCusto}
                </td>
                <td 
                  className="px-6 py-4 whitespace-nowrap text-sm font-medium cursor-pointer"
                  onClick={() => onEdit(transacao)}
                >
                  <span className={transacao.valor < 0 ? 'text-red-500' : 'text-green-500'}>
                    {formatarMoeda(transacao.valor)}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDelete(transacao.id);
                    }}
                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Footer da tabela */}
      {transacoes.length === 0 && (
        <div className="p-8 text-center text-gray-500">
          <p>Nenhuma transação encontrada</p>
        </div>
      )}
    </div>
  );
};

export default TransacoesTable;

