import { useState } from 'react';
import { Upload, FileSpreadsheet, AlertCircle, CheckCircle, X } from 'lucide-react';
import * as XLSX from 'xlsx';

const ImportModal = ({ isOpen, onClose, onImport }) => {
  const [file, setFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [previewData, setPreviewData] = useState([]);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setError('');
      setSuccess('');
      setPreviewData([]);
      
      // Validar tipo de arquivo
      const validTypes = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-excel',
        '.xlsx',
        '.xls'
      ];
      
      const isValidType = validTypes.some(type => 
        selectedFile.type === type || selectedFile.name.toLowerCase().endsWith(type)
      );
      
      if (!isValidType) {
        setError('Por favor, selecione um arquivo Excel (.xlsx ou .xls)');
        setFile(null);
        return;
      }
      
      // Preview do arquivo
      processFilePreview(selectedFile);
    }
  };

  const processFilePreview = (file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        
        if (jsonData.length === 0) {
          setError('A planilha está vazia ou não contém dados válidos');
          return;
        }
        
        // Validar colunas obrigatórias
        const requiredColumns = ['DATA', 'DESCRIÇÃO', 'CATEGORIA', 'CENTRO DE CUSTO', 'VALOR'];
        const fileColumns = Object.keys(jsonData[0]);
        const missingColumns = requiredColumns.filter(col => 
          !fileColumns.some(fileCol => 
            fileCol.toUpperCase().trim() === col.toUpperCase().trim()
          )
        );
        
        if (missingColumns.length > 0) {
          setError(`Colunas obrigatórias não encontradas: ${missingColumns.join(', ')}`);
          return;
        }
        
        // Mostrar preview dos primeiros 5 registros
        setPreviewData(jsonData.slice(0, 5));
        setSuccess(`${jsonData.length} registro(s) encontrado(s) na planilha`);
        
      } catch (err) {
        setError('Erro ao processar arquivo. Verifique se é um arquivo Excel válido.');
        console.error('Erro ao processar arquivo:', err);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleImport = async () => {
    if (!file) {
      setError('Por favor, selecione um arquivo para importar');
      return;
    }
    
    setIsProcessing(true);
    setError('');
    
    try {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: 'array' });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet);
          
          // Processar e normalizar dados
          const processedData = jsonData.map((row, index) => {
            // Normalizar nomes das colunas
            const normalizedRow = {};
            Object.keys(row).forEach(key => {
              const normalizedKey = key.toUpperCase().trim();
              normalizedRow[normalizedKey] = row[key];
            });
            
            // Processar data
            let data = normalizedRow['DATA'];
            if (data instanceof Date) {
              data = data.toISOString().split('T')[0];
            } else if (typeof data === 'number') {
              // Excel serial date
              const excelDate = new Date((data - 25569) * 86400 * 1000);
              data = excelDate.toISOString().split('T')[0];
            } else if (typeof data === 'string') {
              // Tentar converter string para data
              const parsedDate = new Date(data);
              if (!isNaN(parsedDate.getTime())) {
                data = parsedDate.toISOString().split('T')[0];
              }
            }
            
            // Converter data para formato brasileiro
            const [year, month, day] = data.split('-');
            const dataFormatada = `${day}/${month}/${year}`;
            
            return {
              id: Date.now() + index, // ID único
              data: dataFormatada,
              descricao: normalizedRow['DESCRIÇÃO'] || normalizedRow['DESCRICAO'] || '',
              categoria: normalizedRow['CATEGORIA'] || 'Sem categoria',
              centroCusto: normalizedRow['CENTRO DE CUSTO'] || normalizedRow['CENTRO_DE_CUSTO'] || 'Sem centro de custo',
              valor: parseFloat(normalizedRow['VALOR']) || 0,
              observacoes: normalizedRow['OBSERVAÇÕES'] || normalizedRow['OBSERVACOES'] || ''
            };
          });
          
          // Chamar função de importação
          onImport(processedData);
          setSuccess(`${processedData.length} registro(s) importado(s) com sucesso!`);
          
          // Fechar modal após 2 segundos
          setTimeout(() => {
            onClose();
            setFile(null);
            setPreviewData([]);
            setSuccess('');
            setError('');
          }, 2000);
          
        } catch (err) {
          setError('Erro ao processar dados da planilha');
          console.error('Erro ao processar dados:', err);
        } finally {
          setIsProcessing(false);
        }
      };
      reader.readAsArrayBuffer(file);
      
    } catch (err) {
      setError('Erro ao importar arquivo');
      console.error('Erro na importação:', err);
      setIsProcessing(false);
    }
  };

  const handleClose = () => {
    setFile(null);
    setPreviewData([]);
    setError('');
    setSuccess('');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-gray-800 flex items-center gap-2">
            <Upload className="w-5 h-5 text-green-600" />
            Importar Planilha
          </h2>
          <button
            onClick={handleClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Upload Area */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Selecionar Arquivo Excel
          </label>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-green-400 transition-colors">
            <FileSpreadsheet className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <input
              type="file"
              accept=".xlsx,.xls"
              onChange={handleFileChange}
              className="hidden"
              id="file-upload"
            />
            <label
              htmlFor="file-upload"
              className="cursor-pointer text-green-600 hover:text-green-700 font-medium"
            >
              Clique para selecionar arquivo
            </label>
            <p className="text-sm text-gray-500 mt-2">
              Formatos aceitos: .xlsx, .xls
            </p>
            {file && (
              <p className="text-sm text-green-600 mt-2 font-medium">
                Arquivo selecionado: {file.name}
              </p>
            )}
          </div>
        </div>

        {/* Mensagens */}
        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-red-500" />
            <span className="text-red-700">{error}</span>
          </div>
        )}

        {success && (
          <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-500" />
            <span className="text-green-700">{success}</span>
          </div>
        )}

        {/* Preview dos dados */}
        {previewData.length > 0 && (
          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-800 mb-3">
              Preview dos Dados (primeiros 5 registros)
            </h3>
            <div className="overflow-x-auto">
              <table className="min-w-full border border-gray-200 rounded-lg">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left text-sm font-medium text-gray-700 border-b">Data</th>
                    <th className="px-4 py-2 text-left text-sm font-medium text-gray-700 border-b">Descrição</th>
                    <th className="px-4 py-2 text-left text-sm font-medium text-gray-700 border-b">Categoria</th>
                    <th className="px-4 py-2 text-left text-sm font-medium text-gray-700 border-b">Centro de Custo</th>
                    <th className="px-4 py-2 text-left text-sm font-medium text-gray-700 border-b">Valor</th>
                  </tr>
                </thead>
                <tbody>
                  {previewData.map((row, index) => (
                    <tr key={index} className="border-b">
                      <td className="px-4 py-2 text-sm text-gray-900">
                        {row.DATA || row.data || '-'}
                      </td>
                      <td className="px-4 py-2 text-sm text-gray-900">
                        {row.DESCRIÇÃO || row['DESCRIÇÃO'] || '-'}
                      </td>
                      <td className="px-4 py-2 text-sm text-gray-900">
                        {row.CATEGORIA || '-'}
                      </td>
                      <td className="px-4 py-2 text-sm text-gray-900">
                        {row['CENTRO DE CUSTO'] || '-'}
                      </td>
                      <td className="px-4 py-2 text-sm text-gray-900">
                        R$ {(row.VALOR || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Instruções */}
        <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <h4 className="font-medium text-blue-800 mb-2">Formato da Planilha</h4>
          <p className="text-sm text-blue-700 mb-2">
            A planilha deve conter as seguintes colunas obrigatórias:
          </p>
          <ul className="text-sm text-blue-700 list-disc list-inside space-y-1">
            <li><strong>DATA</strong> - Data da transação (formato: DD/MM/AAAA)</li>
            <li><strong>DESCRIÇÃO</strong> - Descrição da transação</li>
            <li><strong>CATEGORIA</strong> - Categoria da transação</li>
            <li><strong>CENTRO DE CUSTO</strong> - Centro de custo</li>
            <li><strong>VALOR</strong> - Valor da transação (negativo para saídas, positivo para entradas)</li>
          </ul>
        </div>

        {/* Botões */}
        <div className="flex justify-end gap-3">
          <button
            onClick={handleClose}
            className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50"
            disabled={isProcessing}
          >
            Cancelar
          </button>
          <button
            onClick={handleImport}
            disabled={!file || isProcessing}
            className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {isProcessing ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                Processando...
              </>
            ) : (
              <>
                <Upload className="w-4 h-4" />
                Importar
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ImportModal;

