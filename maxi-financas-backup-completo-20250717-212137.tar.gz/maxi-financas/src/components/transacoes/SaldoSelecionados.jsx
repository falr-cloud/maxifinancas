import { CheckSquare } from 'lucide-react';

const SaldoSelecionados = ({ transacoesSelecionadas, todasTransacoes }) => {
  const formatarMoeda = (valor) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(valor);
  };

  // Calcular soma dos selecionados
  const saldoSelecionados = todasTransacoes
    .filter(transacao => transacoesSelecionadas.includes(transacao.id))
    .reduce((total, transacao) => total + transacao.valor, 0);

  const isNegativo = saldoSelecionados < 0;

  if (transacoesSelecionadas.length === 0) {
    return null;
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6 border-l-4 border-l-blue-500">
      <div className="flex justify-between items-center">
        <div>
          <p className="text-sm font-medium text-gray-600 mb-1">
            SALDO SELECIONADOS ({transacoesSelecionadas.length} item{transacoesSelecionadas.length !== 1 ? 's' : ''})
          </p>
          <p className={`text-2xl font-bold ${isNegativo ? 'text-red-500' : 'text-green-500'}`}>
            {formatarMoeda(saldoSelecionados)}
          </p>
        </div>
        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
          <CheckSquare className="w-6 h-6 text-blue-600" />
        </div>
      </div>
    </div>
  );
};

export default SaldoSelecionados;

