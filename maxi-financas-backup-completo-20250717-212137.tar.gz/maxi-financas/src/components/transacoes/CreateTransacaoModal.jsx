import { useState } from 'react';
import { X, Calendar, FileText, Tag, Building, DollarSign, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';

const CreateTransacaoModal = ({ isOpen, onClose, onSave, categorias = [], centrosCusto = [] }) => {
  const [formData, setFormData] = useState({
    data: new Date().toISOString().split('T')[0].split('-').reverse().join('/'),
    descricao: '',
    categoria: '',
    centroCusto: '',
    valor: '',
    observacoes: ''
  });

  const [errors, setErrors] = useState({});

  if (!isOpen) return null;

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Limpar erro do campo quando o usuário começar a digitar
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.data.trim()) {
      newErrors.data = 'Data é obrigatória';
    }

    if (!formData.descricao.trim()) {
      newErrors.descricao = 'Descrição é obrigatória';
    }

    if (!formData.categoria) {
      newErrors.categoria = 'Categoria é obrigatória';
    }

    if (!formData.centroCusto) {
      newErrors.centroCusto = 'Centro de Custo é obrigatório';
    }

    if (!formData.valor.trim()) {
      newErrors.valor = 'Valor é obrigatório';
    } else {
      const valorNumerico = parseFloat(formData.valor.replace(',', '.'));
      if (isNaN(valorNumerico)) {
        newErrors.valor = 'Valor deve ser um número válido';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (validateForm()) {
      const valorNumerico = parseFloat(formData.valor.replace(',', '.'));
      
      const novaTransacao = {
        id: Date.now(), // ID temporário
        data: formData.data,
        descricao: formData.descricao.toUpperCase(),
        categoria: formData.categoria,
        centroCusto: formData.centroCusto,
        valor: valorNumerico,
        observacoes: formData.observacoes
      };

      onSave(novaTransacao);
      handleClose();
    }
  };

  const handleClose = () => {
    setFormData({
      data: new Date().toISOString().split('T')[0].split('-').reverse().join('/'),
      descricao: '',
      categoria: '',
      centroCusto: '',
      valor: '',
      observacoes: ''
    });
    setErrors({});
    onClose();
  };

  const formatDateForInput = (dateStr) => {
    if (dateStr.includes('/')) {
      const [day, month, year] = dateStr.split('/');
      return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
    }
    return dateStr;
  };

  const formatDateForDisplay = (dateStr) => {
    if (dateStr.includes('-')) {
      const [year, month, day] = dateStr.split('-');
      return `${day}/${month}/${year}`;
    }
    return dateStr;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">
            Criar Lançamento
          </h3>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <div className="space-y-4">
          {/* Data */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <Calendar className="w-4 h-4 mr-2" />
              Data *
            </label>
            <input
              type="date"
              value={formatDateForInput(formData.data)}
              onChange={(e) => handleInputChange('data', formatDateForDisplay(e.target.value))}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                errors.data ? 'border-red-500' : 'border-gray-300'
              }`}
            />
            {errors.data && <p className="text-red-500 text-xs mt-1">{errors.data}</p>}
          </div>

          {/* Descrição */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <FileText className="w-4 h-4 mr-2" />
              Descrição *
            </label>
            <input
              type="text"
              value={formData.descricao}
              onChange={(e) => handleInputChange('descricao', e.target.value)}
              placeholder="Digite a descrição da transação"
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                errors.descricao ? 'border-red-500' : 'border-gray-300'
              }`}
            />
            {errors.descricao && <p className="text-red-500 text-xs mt-1">{errors.descricao}</p>}
          </div>

          {/* Categoria */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <Tag className="w-4 h-4 mr-2" />
              Categoria *
            </label>
            <select
              value={formData.categoria}
              onChange={(e) => handleInputChange('categoria', e.target.value)}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                errors.categoria ? 'border-red-500' : 'border-gray-300'
              }`}
            >
              <option value="">Selecione uma categoria</option>
              {categorias.map((categoria) => (
                <option key={categoria.id} value={categoria.nome}>
                  {categoria.nome}
                </option>
              ))}
            </select>
            {errors.categoria && <p className="text-red-500 text-xs mt-1">{errors.categoria}</p>}
          </div>

          {/* Centro de Custo */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <Building className="w-4 h-4 mr-2" />
              Centro de Custo *
            </label>
            <select
              value={formData.centroCusto}
              onChange={(e) => handleInputChange('centroCusto', e.target.value)}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                errors.centroCusto ? 'border-red-500' : 'border-gray-300'
              }`}
            >
              <option value="">Selecione um centro de custo</option>
              {centrosCusto.map((centro) => (
                <option key={centro.id} value={centro.nome}>
                  {centro.nome}
                </option>
              ))}
            </select>
            {errors.centroCusto && <p className="text-red-500 text-xs mt-1">{errors.centroCusto}</p>}
          </div>

          {/* Valor */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <DollarSign className="w-4 h-4 mr-2" />
              Valor *
            </label>
            <input
              type="text"
              value={formData.valor}
              onChange={(e) => handleInputChange('valor', e.target.value)}
              placeholder="0,00"
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
                errors.valor ? 'border-red-500' : 'border-gray-300'
              }`}
            />
            <p className="text-xs text-gray-500 mt-1">
              Use valores negativos para saídas e positivos para entradas
            </p>
            {errors.valor && <p className="text-red-500 text-xs mt-1">{errors.valor}</p>}
          </div>

          {/* Observações */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <MessageSquare className="w-4 h-4 mr-2" />
              Observações
            </label>
            <textarea
              value={formData.observacoes}
              onChange={(e) => handleInputChange('observacoes', e.target.value)}
              placeholder="Observações adicionais (opcional)"
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>

        {/* Actions */}
        <div className="flex space-x-3 mt-6">
          <Button
            variant="outline"
            onClick={handleClose}
            className="flex-1"
          >
            Cancelar
          </Button>
          <Button
            onClick={handleSave}
            className="flex-1 bg-blue-600 hover:bg-blue-700"
          >
            Salvar
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CreateTransacaoModal;

