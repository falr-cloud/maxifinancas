import { Button } from '@/components/ui/button';
import { 
  CheckSquare, 
  Upload, 
  Download, 
  Tags, 
  Building, 
  Plus, 
  Trash2 
} from 'lucide-react';

const ActionButtons = ({ selectedCount = 0, onDeleteAll, onCreateLancamento, onImport }) => {
  const handleButtonClick = (buttonLabel) => {
    switch (buttonLabel) {
      case 'Deletar Todos':
        if (onDeleteAll) {
          onDeleteAll();
        }
        break;
      case 'Criar Lançamento':
        if (onCreateLancamento) {
          onCreateLancamento();
        }
        break;
      case 'Importar':
        if (onImport) {
          onImport();
        }
        break;
      default:
        console.log(`Clicou em: ${buttonLabel}`);
    }
  };

  const buttons = [
    {
      label: `Selecionar Todos (${selectedCount})`,
      icon: CheckSquare,
      className: "bg-orange-500 hover:bg-orange-600 text-white"
    },
    {
      label: "Importar",
      icon: Upload,
      className: "bg-green-500 hover:bg-green-600 text-white"
    },
    {
      label: "Exportar",
      icon: Download,
      className: "bg-purple-500 hover:bg-purple-600 text-white"
    },
    {
      label: "Gerar Categorias",
      icon: Tags,
      className: "bg-blue-500 hover:bg-blue-600 text-white"
    },
    {
      label: "Gerar Centros de Custo",
      icon: Building,
      className: "bg-blue-700 hover:bg-blue-800 text-white"
    },
    {
      label: "Criar Lançamento",
      icon: Plus,
      className: "bg-green-400 hover:bg-green-500 text-white"
    },
    {
      label: "Deletar Todos",
      icon: Trash2,
      className: "bg-red-500 hover:bg-red-600 text-white"
    }
  ];

  return (
    <div className="flex flex-wrap gap-3 mb-6">
      {buttons.map((button, index) => {
        const IconComponent = button.icon;
        return (
          <Button
            key={index}
            className={`${button.className} px-4 py-2 text-sm font-medium`}
            onClick={() => handleButtonClick(button.label)}
          >
            <IconComponent className="w-4 h-4 mr-2" />
            {button.label}
          </Button>
        );
      })}
    </div>
  );
};

export default ActionButtons;

