import { DollarSign } from 'lucide-react';

const SaldoCard = ({ saldo }) => {
  const formatarMoeda = (valor) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(valor);
  };

  const isNegativo = saldo < 0;

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
      <div className="flex justify-between items-center">
        <div>
          <p className="text-sm font-medium text-gray-600 mb-1">SALDO BANCO</p>
          <p className={`text-2xl font-bold ${isNegativo ? 'text-red-500' : 'text-green-500'}`}>
            {formatarMoeda(saldo)}
          </p>
        </div>
        <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
          <DollarSign className="w-6 h-6 text-green-600" />
        </div>
      </div>
    </div>
  );
};

export default SaldoCard;

