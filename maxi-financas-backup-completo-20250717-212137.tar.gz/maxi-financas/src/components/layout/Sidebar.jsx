import { LayoutDashboard, CreditCard, FileText, Settings } from 'lucide-react';

const Sidebar = ({ activeItem = 'Transações' }) => {
  const menuItems = [
    { id: 1, nome: "Dashboard", icone: LayoutDashboard },
    { id: 2, nome: "Transações", icone: CreditCard },
    { id: 3, nome: "Relatórios", icone: FileText },
    { id: 4, nome: "Configurações", icone: Settings }
  ];

  return (
    <aside className="w-64 bg-gray-50 border-r border-gray-200 min-h-screen">
      <nav className="p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const IconComponent = item.icone;
            const isActive = item.nome === activeItem;
            
            return (
              <li key={item.id}>
                <button
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors ${
                    isActive 
                      ? 'bg-blue-100 text-blue-700 border-l-4 border-blue-600' 
                      : 'text-gray-600 hover:bg-gray-100 hover:text-gray-800'
                  }`}
                >
                  <IconComponent className="w-5 h-5" />
                  <span className="font-medium">{item.nome}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;

