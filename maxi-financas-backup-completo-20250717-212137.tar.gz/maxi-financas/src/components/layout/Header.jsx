import { Button } from '@/components/ui/button';
import { LogOut } from 'lucide-react';

const Header = () => {
  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center">
      {/* Logo e título */}
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
          <span className="text-white font-bold text-lg">MF</span>
        </div>
        <h1 className="text-xl font-semibold text-gray-800">MAXI FINANÇAS</h1>
      </div>

      {/* Área do usuário */}
      <div className="flex items-center space-x-4">
        <span className="text-gray-600">Olá, Administrador</span>
        <Button 
          variant="destructive" 
          size="sm"
          className="bg-red-500 hover:bg-red-600"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Sair
        </Button>
      </div>
    </header>
  );
};

export default Header;

