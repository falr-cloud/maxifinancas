// Dados mock para o sistema MAXI FINANÇAS

export const transacoesMock = [
  {
    id: 1,
    data: "15/07/2025",
    descricao: "CONTABILIDADE",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -3008.40,
    observacoes: ""
  },
  {
    id: 2,
    data: "15/07/2025",
    descricao: "ALUGUEL MAXIMO CONS.",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -3163.34,
    observacoes: ""
  },
  {
    id: 3,
    data: "14/07/2025",
    descricao: "SERVIÇO MOTO BOY",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -43.30,
    observacoes: ""
  },
  {
    id: 4,
    data: "14/07/2025",
    descricao: "FRANCIELLE LOYD PEREIRA",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -200.00,
    observacoes: ""
  },
  {
    id: 5,
    data: "13/07/2025",
    descricao: "WESIK HENRIQUE ALVES DE ALMEIDA",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -106.00,
    observacoes: ""
  },
  {
    id: 6,
    data: "11/07/2025",
    descricao: "MONIQUE APARECIDA CATALDI",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -1499.85,
    observacoes: ""
  },
  {
    id: 7,
    data: "11/07/2025",
    descricao: "ADVOGADO SEQUENCIA PROCESSOS",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -1000.00,
    observacoes: ""
  },
  {
    id: 8,
    data: "10/07/2025",
    descricao: "RESTAURANTE DIVINOS (FUNDO)",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -625.65,
    observacoes: ""
  },
  {
    id: 9,
    data: "09/07/2025",
    descricao: "SUPERMERCADO EXTRA",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -450.30,
    observacoes: ""
  },
  {
    id: 10,
    data: "09/07/2025",
    descricao: "POSTO DE GASOLINA SHELL",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -180.00,
    observacoes: ""
  },
  {
    id: 11,
    data: "08/07/2025",
    descricao: "FARMACIA DROGASIL",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -85.50,
    observacoes: ""
  },
  {
    id: 12,
    data: "08/07/2025",
    descricao: "UBER VIAGEM",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -25.40,
    observacoes: ""
  },
  {
    id: 13,
    data: "07/07/2025",
    descricao: "NETFLIX ASSINATURA",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -32.90,
    observacoes: ""
  },
  {
    id: 14,
    data: "07/07/2025",
    descricao: "ENERGIA ELÉTRICA CEMIG",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -320.75,
    observacoes: ""
  },
  {
    id: 15,
    data: "06/07/2025",
    descricao: "INTERNET VIVO FIBRA",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -99.90,
    observacoes: ""
  },
  {
    id: 16,
    data: "06/07/2025",
    descricao: "PADARIA DO BAIRRO",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -15.80,
    observacoes: ""
  },
  {
    id: 17,
    data: "05/07/2025",
    descricao: "LOJA DE ROUPAS RENNER",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -250.00,
    observacoes: ""
  },
  {
    id: 18,
    data: "05/07/2025",
    descricao: "ACADEMIA SMART FIT",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -79.90,
    observacoes: ""
  },
  {
    id: 19,
    data: "04/07/2025",
    descricao: "IFOOD DELIVERY",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -45.60,
    observacoes: ""
  },
  {
    id: 20,
    data: "04/07/2025",
    descricao: "BANCO SANTANDER TARIFA",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -12.50,
    observacoes: ""
  },
  {
    id: 21,
    data: "03/07/2025",
    descricao: "SPOTIFY PREMIUM",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -21.90,
    observacoes: ""
  },
  {
    id: 22,
    data: "03/07/2025",
    descricao: "MERCADO LIVRE COMPRA",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: -150.00,
    observacoes: ""
  },
  {
    id: 23,
    data: "02/07/2025",
    descricao: "DEPOSITO CLIENTE JOÃO",
    categoria: "Sem categoria",
    centroCusto: "Sem centro de custo",
    valor: 2500.00,
    observacoes: ""
  }
];

export const categorias = [
  { id: 1, nome: "Alimentação" },
  { id: 2, nome: "Transporte" },
  { id: 3, nome: "Moradia" },
  { id: 4, nome: "Saúde" },
  { id: 5, nome: "Educação" },
  { id: 6, nome: "Lazer" },
  { id: 7, nome: "Vestuário" },
  { id: 8, nome: "Serviços" },
  { id: 9, nome: "Impostos" },
  { id: 10, nome: "Investimentos" }
];

export const centrosCusto = [
  { id: 1, nome: "Administrativo" },
  { id: 2, nome: "Vendas" },
  { id: 3, nome: "Marketing" },
  { id: 4, nome: "Operacional" },
  { id: 5, nome: "Financeiro" },
  { id: 6, nome: "Recursos Humanos" },
  { id: 7, nome: "Tecnologia" },
  { id: 8, nome: "Jurídico" }
];

export const menuItems = [
  { id: 1, nome: "Dashboard", icone: "LayoutDashboard", ativo: false },
  { id: 2, nome: "Transações", icone: "CreditCard", ativo: true },
  { id: 3, nome: "Relatórios", icone: "FileText", ativo: false },
  { id: 4, nome: "Configurações", icone: "Settings", ativo: false }
];

// Função para calcular saldo total
export const calcularSaldoTotal = (transacoes) => {
  return transacoes.reduce((total, transacao) => total + transacao.valor, 0);
};

// Função para formatar valor em moeda brasileira
export const formatarMoeda = (valor) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(valor);
};

// Função para formatar data
export const formatarData = (data) => {
  return data; // Já está no formato dd/mm/aaaa
};

