import { useState, useMemo } from 'react';
import MainContent from '../components/layout/MainContent';
import ActionButtons from '../components/transacoes/ActionButtons';
import FilterSection from '../components/transacoes/FilterSection';
import SaldoCard from '../components/transacoes/SaldoCard';
import SaldoSelecionados from '../components/transacoes/SaldoSelecionados';
import TransacoesTable from '../components/transacoes/TransacoesTable';
import Pagination from '../components/transacoes/Pagination';
import EditTransacaoModal from '../components/transacoes/EditTransacaoModal';
import DeleteAllModal from '../components/transacoes/DeleteAllModal';
import CreateTransacaoModal from '../components/transacoes/CreateTransacaoModal';
import ImportModal from '../components/transacoes/ImportModal';
import { transacoesMock, categorias, centrosCusto } from '../data/mockData';

const Transacoes = () => {
  const [transacoes, setTransacoes] = useState(transacoesMock);
  const [filteredTransacoes, setFilteredTransacoes] = useState(transacoesMock);
  const [selectedTransacao, setSelectedTransacao] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTransacoes, setSelectedTransacoes] = useState([]);
  const [isDeleteAllModalOpen, setIsDeleteAllModalOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  
  // Estados da paginação
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(20);

  // Calcular dados da paginação
  const totalItems = filteredTransacoes.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentTransacoes = filteredTransacoes.slice(startIndex, endIndex);

  // Calcular saldo total
  const saldoTotal = filteredTransacoes.reduce((total, transacao) => total + transacao.valor, 0);

  const handleFilter = (filters) => {
    let filtered = [...transacoes];

    // Filtrar por descrição
    if (filters.buscar || filters.buscarDescricao) {
      const searchTerm = (filters.buscar || filters.buscarDescricao).toLowerCase();
      filtered = filtered.filter(t => 
        t.descricao.toLowerCase().includes(searchTerm)
      );
    }

    // Filtrar por data (simulado)
    if (filters.dataInicio || filters.dataFim) {
      console.log('Filtrar por data:', filters.dataInicio, filters.dataFim);
    }

    // Filtrar por categoria
    if (filters.categoria) {
      filtered = filtered.filter(t => t.categoria === filters.categoria);
    }

    // Filtrar por centro de custo
    if (filters.centroCusto) {
      filtered = filtered.filter(t => t.centroCusto === filters.centroCusto);
    }

    setFilteredTransacoes(filtered);
    setCurrentPage(1); // Resetar para primeira página
    setSelectedTransacoes([]); // Limpar seleções
  };

  const handleClearFilters = () => {
    setFilteredTransacoes(transacoes);
    setCurrentPage(1);
    setSelectedTransacoes([]);
  };

  const handleEditTransacao = (transacao) => {
    setSelectedTransacao(transacao);
    setIsModalOpen(true);
  };

  const handleSaveTransacao = (updatedTransacao) => {
    const updatedTransacoes = transacoes.map(t => 
      t.id === updatedTransacao.id ? updatedTransacao : t
    );
    setTransacoes(updatedTransacoes);
    setFilteredTransacoes(updatedTransacoes);
    console.log('Transação salva:', updatedTransacao);
  };

  const handleDeleteTransacao = (id) => {
    const updatedTransacoes = transacoes.filter(t => t.id !== id);
    setTransacoes(updatedTransacoes);
    setFilteredTransacoes(updatedTransacoes);
    setSelectedTransacoes(prev => prev.filter(selectedId => selectedId !== id));
    console.log('Transação deletada:', id);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedTransacao(null);
  };

  // Funções para deletar todos
  const handleDeleteAll = () => {
    setIsDeleteAllModalOpen(true);
  };

  const handleConfirmDeleteAll = () => {
    // Limpar todos os dados
    setTransacoes([]);
    setFilteredTransacoes([]);
    setSelectedTransacoes([]);
    setCurrentPage(1);
    setIsDeleteAllModalOpen(false);
    console.log('Todos os lançamentos foram deletados');
  };

  const handleCloseDeleteAllModal = () => {
    setIsDeleteAllModalOpen(false);
  };

  // Funções para criar nova transação
  const handleCreateTransacao = () => {
    setIsCreateModalOpen(true);
  };

  const handleSaveNewTransacao = (novaTransacao) => {
    // Gerar ID único baseado no timestamp
    const transacaoComId = {
      ...novaTransacao,
      id: Date.now()
    };

    // Adicionar nova transação ao início da lista
    const updatedTransacoes = [transacaoComId, ...transacoes];
    setTransacoes(updatedTransacoes);
    setFilteredTransacoes(updatedTransacoes);
    setIsCreateModalOpen(false);
    console.log('Nova transação criada:', transacaoComId);
  };

  const handleCloseCreateModal = () => {
    setIsCreateModalOpen(false);
  };

  // Funções de importação
  const handleImport = () => {
    setIsImportModalOpen(true);
  };

  const handleImportData = (importedData) => {
    // Inserir dados importados no início da lista (conforme conhecimento relacionado)
    const updatedTransacoes = [...importedData, ...transacoes];
    setTransacoes(updatedTransacoes);
    setFilteredTransacoes(updatedTransacoes);
    console.log(`${importedData.length} transações importadas com sucesso`);
  };

  const handleCloseImportModal = () => {
    setIsImportModalOpen(false);
  };

  // Funções de seleção
  const handleSelectTransacao = (id) => {
    setSelectedTransacoes(prev => {
      if (prev.includes(id)) {
        return prev.filter(selectedId => selectedId !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  const handleSelectAll = () => {
    if (selectedTransacoes.length === currentTransacoes.length) {
      // Se todos estão selecionados, desselecionar todos
      setSelectedTransacoes([]);
    } else {
      // Selecionar todos os visíveis na página atual
      const currentIds = currentTransacoes.map(t => t.id);
      setSelectedTransacoes(currentIds);
    }
  };

  // Funções de paginação
  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleItemsPerPageChange = (newItemsPerPage) => {
    setItemsPerPage(newItemsPerPage);
    setCurrentPage(1); // Resetar para primeira página
  };

  return (
    <div>
      {/* Título da página */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Transações</h1>
      </div>

      {/* Botões de ação */}
      <ActionButtons 
        selectedCount={selectedTransacoes.length} 
        onDeleteAll={handleDeleteAll}
        onCreateLancamento={handleCreateTransacao}
        onImport={handleImport}
      />

      {/* Seção de filtros */}
      <FilterSection 
        onFilter={handleFilter}
        onClearFilters={handleClearFilters}
      />

      {/* Cards de saldo */}
      <SaldoCard saldo={saldoTotal} />
      <SaldoSelecionados 
        transacoesSelecionadas={selectedTransacoes}
        todasTransacoes={filteredTransacoes}
      />

      {/* Tabela de transações */}
      <TransacoesTable 
        transacoes={currentTransacoes}
        selectedTransacoes={selectedTransacoes}
        onEdit={handleEditTransacao}
        onDelete={handleDeleteTransacao}
        onSelectTransacao={handleSelectTransacao}
        onSelectAll={handleSelectAll}
      />

      {/* Paginação */}
      {totalPages > 1 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          itemsPerPage={itemsPerPage}
          totalItems={totalItems}
          onPageChange={handlePageChange}
          onItemsPerPageChange={handleItemsPerPageChange}
        />
      )}

      {/* Modal de edição */}
      <EditTransacaoModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        transacao={selectedTransacao}
        onSave={handleSaveTransacao}
      />

      {/* Modal de deletar todos */}
      <DeleteAllModal
        isOpen={isDeleteAllModalOpen}
        onClose={handleCloseDeleteAllModal}
        onConfirm={handleConfirmDeleteAll}
        totalTransacoes={transacoes.length}
      />

      {/* Modal de criar lançamento */}
      <CreateTransacaoModal
        isOpen={isCreateModalOpen}
        onClose={handleCloseCreateModal}
        onSave={handleSaveNewTransacao}
        categorias={categorias}
        centrosCusto={centrosCusto}
      />

      {/* Modal de importação */}
      <ImportModal
        isOpen={isImportModalOpen}
        onClose={handleCloseImportModal}
        onImport={handleImportData}
      />
    </div>
  );
};

export default Transacoes;

