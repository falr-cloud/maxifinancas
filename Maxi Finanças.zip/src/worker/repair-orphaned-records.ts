// Utility endpoint to fix orphaned records (records without user_id)
// This can be called manually to assign orphaned records to the current user

export async function repairOrphanedRecords(c: any) {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }

    console.log(`🔧 REPAIR: Starting orphaned records repair for user: ${user.id}`);

    // Find and fix orphaned fixed accounts
    const orphanedFixedAccounts = await c.env.DB.prepare(
      "SELECT COUNT(*) as count FROM fixed_accounts WHERE user_id IS NULL OR user_id = ''"
    ).first();

    if (orphanedFixedAccounts && orphanedFixedAccounts.count > 0) {
      console.log(`🔧 REPAIR: Found ${orphanedFixedAccounts.count} orphaned fixed accounts`);
      
      const fixResult = await c.env.DB.prepare(
        "UPDATE fixed_accounts SET user_id = ? WHERE user_id IS NULL OR user_id = ''"
      ).bind(user.id).run();
      
      console.log(`🔧 REPAIR: Fixed ${fixResult.meta?.changes || 0} fixed accounts`);
    }

    // Find and fix orphaned variable accounts
    const orphanedVariableAccounts = await c.env.DB.prepare(
      "SELECT COUNT(*) as count FROM variable_accounts WHERE user_id IS NULL OR user_id = ''"
    ).first();

    if (orphanedVariableAccounts && orphanedVariableAccounts.count > 0) {
      console.log(`🔧 REPAIR: Found ${orphanedVariableAccounts.count} orphaned variable accounts`);
      
      const fixResult = await c.env.DB.prepare(
        "UPDATE variable_accounts SET user_id = ? WHERE user_id IS NULL OR user_id = ''"
      ).bind(user.id).run();
      
      console.log(`🔧 REPAIR: Fixed ${fixResult.meta?.changes || 0} variable accounts`);
    }

    // Fix other types as well
    const tables = ['transactions', 'payroll', 'accounts_receivable', 'categories', 'cost_centers'];
    const results: any = {};

    for (const table of tables) {
      const orphanedCount = await c.env.DB.prepare(
        `SELECT COUNT(*) as count FROM ${table} WHERE user_id IS NULL OR user_id = ''`
      ).first();

      if (orphanedCount && orphanedCount.count > 0) {
        console.log(`🔧 REPAIR: Found ${orphanedCount.count} orphaned records in ${table}`);
        
        const fixResult = await c.env.DB.prepare(
          `UPDATE ${table} SET user_id = ? WHERE user_id IS NULL OR user_id = ''`
        ).bind(user.id).run();
        
        results[table] = fixResult.meta?.changes || 0;
        console.log(`🔧 REPAIR: Fixed ${results[table]} records in ${table}`);
      } else {
        results[table] = 0;
      }
    }

    return c.json({
      success: true,
      message: "Registros órfãos reparados com sucesso",
      repaired: {
        fixed_accounts: orphanedFixedAccounts?.count || 0,
        variable_accounts: orphanedVariableAccounts?.count || 0,
        ...results
      },
      userId: user.id
    });

  } catch (error) {
    console.error("🔧 REPAIR: Error repairing orphaned records:", error);
    return c.json({ 
      success: false, 
      error: "Erro ao reparar registros órfãos",
      details: error instanceof Error ? error.message : 'Unknown error'
    }, 500);
  }
}
