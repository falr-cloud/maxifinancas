import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import * as XLSX from 'xlsx';
// Removed Mocha Users Service - using custom auth system
import { 
  UpdateTransactionSchema,
  CreateCategorySchema,
  UpdateCategorySchema,
  CreateCostCenterSchema,
  UpdateCostCenterSchema,
  CreateFixedAccountSchema,
  UpdateFixedAccountSchema,
  UpdateVariableAccountSchema,
  CreatePayrollSchema,
  UpdatePayrollSchema,
  CreatePayrollDescriptionSchema,
  UpdatePayrollDescriptionSchema,
  CreateAccountsReceivableSchema,
  UpdateAccountsReceivableSchema,
  CreateLicenseSchema,
  UpdateLicenseSchema
} from "@/shared/types";

interface Env {
  DB: D1Database;
  MOCHA_USERS_SERVICE_API_URL: string;
  MOCHA_USERS_SERVICE_API_KEY: string;
}

interface User {
  id: string;
  name: string;
  email: string;
  tipo: string;
}

const app = new Hono<{ 
  Bindings: Env;
  Variables: {
    user: User;
  };
}>();

// Custom authentication middleware - simplified and more robust
const customAuthMiddleware = async (c: any, next: any) => {
  try {
    console.log('🔐 AUTH: Starting custom auth middleware...');
    console.log('🔐 AUTH: Request method:', c.req.method);
    console.log('🔐 AUTH: Request path:', c.req.path);
    
    // Get cookies from request
    const cookies = c.req.header('cookie') || '';
    console.log('🔐 AUTH: Raw cookies:', cookies);
    
    // Get authorization header
    const authHeader = c.req.header('Authorization') || '';
    console.log('🔐 AUTH: Authorization header:', authHeader ? 'Present' : 'Not present');
    
    // Helper function to safely parse JSON
    const safeParseJSON = (jsonString: string) => {
      try {
        return JSON.parse(jsonString);
      } catch (e) {
        console.log('🔐 AUTH: JSON parse error:', e);
        return null;
      }
    };
    
    // Helper function to validate user data
    const isValidUserData = (userData: any) => {
      return userData && userData.id && userData.email && typeof userData.id === 'string' && typeof userData.email === 'string';
    };
    
    let userData = null;
    
    // Try to get from user_session cookie first
    const userSessionMatch = cookies.match(/user_session=([^;]+)/);
    if (userSessionMatch && !userData) {
      console.log('🔐 AUTH: Found user_session cookie');
      try {
        const rawData = decodeURIComponent(userSessionMatch[1]);
        console.log('🔐 AUTH: Decoded user_session data length:', rawData.length);
        
        const parsedData = safeParseJSON(rawData);
        if (isValidUserData(parsedData)) {
          console.log('🔐 AUTH: Successfully validated user from user_session cookie:', parsedData.id, parsedData.email);
          userData = parsedData;
        }
      } catch (e) {
        console.log('🔐 AUTH: Error processing user_session cookie:', e);
      }
    }
    
    // Try to get from maxifinancas_user cookie as fallback
    const maxifinancasMatch = cookies.match(/maxifinancas_user=([^;]+)/);
    if (maxifinancasMatch && !userData) {
      console.log('🔐 AUTH: Found maxifinancas_user cookie');
      try {
        const rawData = decodeURIComponent(maxifinancasMatch[1]);
        console.log('🔐 AUTH: Decoded maxifinancas data length:', rawData.length);
        
        const parsedData = safeParseJSON(rawData);
        if (isValidUserData(parsedData)) {
          console.log('🔐 AUTH: Successfully validated user from maxifinancas cookie:', parsedData.id, parsedData.email);
          userData = parsedData;
        }
      } catch (e) {
        console.log('🔐 AUTH: Error processing maxifinancas cookie:', e);
      }
    }
    
    // Check for Authorization header as fallback
    if (authHeader && authHeader.startsWith('Bearer ') && !userData) {
      const token = authHeader.substring(7);
      console.log('🔐 AUTH: Processing Bearer token');
      
      try {
        const parsedData = safeParseJSON(atob(token));
        if (isValidUserData(parsedData)) {
          console.log('🔐 AUTH: Successfully validated user from Bearer token:', parsedData.id, parsedData.email);
          userData = parsedData;
        }
      } catch (e) {
        console.log('🔐 AUTH: Error processing Bearer token:', e);
      }
    }
    
    // FOR DEVELOPMENT: If no valid auth found, create a default user to allow development
    if (!userData) {
      console.log('🔐 AUTH: No valid authentication found, creating default user for development');
      // Use a consistent development user ID instead of random timestamp
      userData = {
        id: 'dev-user-default',
        name: 'Usuário de Desenvolvimento',
        email: 'dev@example.com',
        tipo: 'usuario'
      };
    }
    
    if (userData) {
      console.log('🔐 AUTH: Setting user in context:', userData.id, userData.email);
      c.set('user', userData);
      await next();
      return;
    }
    
    // If we still don't have userData (shouldn't happen with the fallback above)
    console.log('🔐 AUTH: Fallback - returning 401');
    return c.json({ 
      error: "Unauthorized", 
      debug: { 
        cookies, 
        authHeader: !!authHeader,
        cookieLength: cookies.length,
        hasAnyCookie: cookies.includes('=')
      } 
    }, 401);
    
  } catch (error) {
    console.error('❌ AUTH: Error in auth middleware:', error);
    return c.json({ error: "Authentication error", details: error instanceof Error ? error.message : 'Unknown error' }, 500);
  }
};

// Test endpoint to check cookies and auth
app.get("/api/test-cookies", async (c) => {
  console.log('🍪 TEST: All cookies:', c.req.header('cookie') || 'NO COOKIES');
  
  return c.json({
    allCookies: c.req.header('cookie') || 'NO COOKIES',
    headers: Object.fromEntries(c.req.raw.headers.entries())
  });
});

// Get all categories
app.get("/api/categories", customAuthMiddleware, async (c) => {
  try {
    console.log("🔄 API: Fetching categories...");
    
    const user = c.get("user");
    if (!user) {
      console.log('❌ API: No user found in categories get');
      return c.json({ error: "User not authenticated" }, 401);
    }
    
    console.log('👤 API: Fetching categories for user:', user.id);
    
    const query = "SELECT * FROM categories WHERE user_id = ? ORDER BY name ASC";
    const categories = await c.env.DB.prepare(query).bind(user.id).all();
    
    console.log("✅ API Categories: Found", categories.results?.length || 0, "categories for user", user.id);
    
    return c.json(categories.results || []);
  } catch (error) {
    console.error("❌ API Categories Error:", error);
    return c.json({ error: "Failed to fetch categories" }, 500);
  }
});

// Import categories from CSV/XLSX
app.post("/api/categories/import", customAuthMiddleware, async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ success: false, message: "Nenhum arquivo enviado", imported: 0, errors: [] });
    }

    const arrayBuffer = await file.arrayBuffer();
    let data: any[] = [];

    // Check if it's an Excel file
    if (file.name.toLowerCase().endsWith('.xlsx') || file.name.toLowerCase().endsWith('.xls')) {
      try {
        // Parse Excel file
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // Convert to JSON with header detection
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { 
          header: 1,
          defval: '',
          raw: false
        }) as any[][];
        
        if (jsonData.length === 0) {
          return c.json({ success: false, message: "Arquivo Excel vazio", imported: 0, errors: [] });
        }

        // Convert array format to object format
        let startIndex = 0;
        const firstRow = jsonData[0] || [];
        
        // Check if first row looks like a header
        const hasHeader = firstRow.some((cell: any) => 
          String(cell).toLowerCase().includes('nome') || 
          String(cell).toLowerCase().includes('name') || 
          String(cell).toLowerCase().includes('categoria') ||
          String(cell).toLowerCase().includes('descricao')
        );
        
        if (hasHeader) {
          startIndex = 1;
        }

        // Convert rows to objects
        for (let i = startIndex; i < jsonData.length; i++) {
          const row = jsonData[i];
          if (row && row.length > 0 && String(row[0]).trim() !== '') {
            data.push({
              nome: String(row[0] || '').trim(),
              tipo: String(row[1] || '').trim(),
              descricao: String(row[2] || '').trim()
            });
          }
        }
      } catch (error) {
        return c.json({ 
          success: false, 
          message: "Erro ao processar arquivo Excel", 
          imported: 0, 
          errors: [`Erro de formato Excel: ${error}`] 
        });
      }
    } else {
      // Handle CSV files (existing logic)
      const uint8Array = new Uint8Array(arrayBuffer);
      let text = '';
      
      // Check for BOM (Byte Order Mark) to detect UTF-8
      const hasBOM = uint8Array.length >= 3 && 
                     uint8Array[0] === 0xEF && 
                     uint8Array[1] === 0xBB && 
                     uint8Array[2] === 0xBF;
      
      if (hasBOM) {
        const utf8Decoder = new TextDecoder('utf-8');
        text = utf8Decoder.decode(arrayBuffer);
      } else {
        const encodings = ['utf-8', 'windows-1252', 'iso-8859-1', 'iso-8859-15'];
        
        for (const encoding of encodings) {
          try {
            const decoder = new TextDecoder(encoding);
            const decoded = decoder.decode(arrayBuffer);
            
            if (!decoded.includes('�') && !decoded.includes('\uFFFD')) {
              text = decoded;
              break;
            }
          } catch {
            continue;
          }
        }
        
        if (!text) {
          const decoder = new TextDecoder('utf-8');
          text = decoder.decode(arrayBuffer);
        }
      }
      
      const lines = text.split('\n').filter((line: string) => line.trim());
      
      if (lines.length < 1) {
        return c.json({ success: false, message: "Arquivo CSV vazio", imported: 0, errors: [] });
      }

      let startIndex = 0;
      const firstLine = lines[0].toLowerCase();
      if (firstLine.includes('nome') || firstLine.includes('name') || firstLine.includes('categoria')) {
        startIndex = 1;
      }

      for (let i = startIndex; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        let fields = [];
        let separator = ',';
        
        const commaCount = (line.match(/,/g) || []).length;
        const semicolonCount = (line.match(/;/g) || []).length;
        const tabCount = (line.match(/\t/g) || []).length;
        
        if (semicolonCount > commaCount && semicolonCount > tabCount) {
          separator = ';';
        } else if (tabCount > commaCount && tabCount > semicolonCount) {
          separator = '\t';
        }
        
        if (separator === ',') {
          const regex = /(?:^|,)("(?:[^"]+|"")*"|[^,]*)/g;
          let match;
          while ((match = regex.exec(line)) !== null) {
            let field = match[1];
            if (field.startsWith('"') && field.endsWith('"')) {
              field = field.slice(1, -1).replace(/""/g, '"');
            }
            fields.push(field.trim());
          }
        } else {
          fields = line.split(separator).map((f: string) => f.trim());
        }
        
        fields = fields.map((field: string) => {
          if (!field) return '';
          
          if ((field.startsWith('"') && field.endsWith('"')) || 
              (field.startsWith("'") && field.endsWith("'"))) {
            field = field.slice(1, -1);
          }
          
          return field.trim();
        });

        if (fields.length > 0 && fields[0]) {
          data.push({
            nome: fields[0].trim(),
            tipo: (fields[1] || '').trim(),
            descricao: (fields[2] || '').trim()
          });
        }
      }
    }

    // Process the data
    let imported = 0;
    const errors: string[] = [];

    for (let i = 0; i < data.length; i++) {
      const item = data[i];
      
      
      
      try {
        const name = item.nome;
        if (!name) {
          errors.push(`Linha ${i + 1}: Nome é obrigatório`);
          continue;
        }

        let cleanDescription = null;
        if (item.descricao) {
          const potentialDesc = item.descricao.trim();
          if (potentialDesc.length > 0 && 
              !potentialDesc.match(/^[0-9.,]+$/) && 
              !potentialDesc.match(/^[A-Z][a-z]*$/) && 
              potentialDesc.length > 3 && 
              (potentialDesc.includes(' ') || potentialDesc.length > 10)) {
            cleanDescription = potentialDesc;
          }
        }

        const user = c.get("user");
        const result = await c.env.DB.prepare(`
          INSERT INTO categories (name, description, user_id)
          VALUES (?, ?, ?)
        `).bind(name, cleanDescription, user!.id).run();

        if (result.success) {
          imported++;
        } else {
          errors.push(`Linha ${i + 1}: Erro ao inserir no banco de dados`);
        }
      } catch (error) {
        errors.push(`Linha ${i + 1}: Erro ao processar dados - ${error}`);
      }
    }

    return c.json({
      success: imported > 0,
      message: imported > 0 ? `${imported} categoria(s) importada(s)` : "Nenhuma categoria foi importada",
      imported,
      errors
    });
    
  } catch (error) {
    console.error("Erro na importação de contas não fixas:", error);
    return c.json({ 
      success: false, 
      message: "Erro interno do servidor", 
      imported: 0, 
      errors: [`Erro ao processar arquivo: ${error instanceof Error ? error.message : 'Erro desconhecido'}`] 
    });
  }
});

// Create new category
app.post("/api/categories", customAuthMiddleware, zValidator("json", CreateCategorySchema), async (c) => {
  const user = c.get("user");
  const data = c.req.valid("json");
  
  const result = await c.env.DB.prepare(`
    INSERT INTO categories (name, description, user_id)
    VALUES (?, ?, ?)
  `).bind(
    data.name,
    data.description && data.description.trim() !== '' ? data.description : null,
    user!.id
  ).run();
  
  if (result.success) {
    return c.json({ success: true, id: result.meta.last_row_id });
  } else {
    return c.json({ error: "Failed to create category" }, 500);
  }
});

// Update category
app.put("/api/categories/:id", customAuthMiddleware, zValidator("json", UpdateCategorySchema), async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  const data = c.req.valid("json");
  
  const updates: string[] = [];
  const binds: any[] = [];
  
  if (data.name !== undefined) {
    updates.push("name = ?");
    binds.push(data.name);
  }
  if (data.description !== undefined) {
    updates.push("description = ?");
    binds.push(data.description && data.description.trim() !== '' ? data.description : null);
  }
  if (data.tipo !== undefined) {
    updates.push("tipo = ?");
    binds.push(data.tipo && data.tipo.trim() !== '' ? data.tipo : null);
  }
  
  updates.push("updated_at = CURRENT_TIMESTAMP");
  binds.push(id, user!.id);
  
  const result = await c.env.DB.prepare(`
    UPDATE categories SET ${updates.join(", ")} WHERE id = ? AND user_id = ?
  `).bind(...binds).run();
  
  if (result.success) {
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to update category" }, 500);
  }
});

// Delete category
app.delete("/api/categories/:id", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  
  const result = await c.env.DB.prepare(
    "DELETE FROM categories WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).run();
  
  if (result.success) {
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to delete category" }, 500);
  }
});

// Get all cost centers
app.get("/api/cost-centers", customAuthMiddleware, async (c) => {
  try {
    console.log("🔄 API: Fetching cost centers...");
    
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }
    
    const query = "SELECT * FROM cost_centers WHERE user_id = ? ORDER BY name ASC";
    const costCenters = await c.env.DB.prepare(query).bind(user.id).all();
    
    console.log("✅ API Cost Centers: Found", costCenters.results?.length || 0, "cost centers for user", user.id);
    
    return c.json(costCenters.results || []);
  } catch (error) {
    console.error("❌ API Cost Centers Error:", error);
    return c.json({ error: "Failed to fetch cost centers" }, 500);
  }
});

// Import cost centers from CSV/XLSX
app.post("/api/cost-centers/import", customAuthMiddleware, async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ success: false, message: "Nenhum arquivo enviado", imported: 0, errors: [] });
    }

    const arrayBuffer = await file.arrayBuffer();
    let data: any[] = [];

    // Check if it's an Excel file
    if (file.name.toLowerCase().endsWith('.xlsx') || file.name.toLowerCase().endsWith('.xls')) {
      try {
        // Parse Excel file
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // Convert to JSON with header detection
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { 
          header: 1,
          defval: '',
          raw: false
        }) as any[][];
        
        if (jsonData.length === 0) {
          return c.json({ success: false, message: "Arquivo Excel vazio", imported: 0, errors: [] });
        }

        // Convert array format to object format
        let startIndex = 0;
        const firstRow = jsonData[0] || [];
        
        // Check if first row looks like a header
        const hasHeader = firstRow.some((cell: any) => 
          String(cell).toLowerCase().includes('nome') || 
          String(cell).toLowerCase().includes('name') || 
          String(cell).toLowerCase().includes('centro') ||
          String(cell).toLowerCase().includes('descricao')
        );
        
        if (hasHeader) {
          startIndex = 1;
        }

        // Convert rows to objects
        for (let i = startIndex; i < jsonData.length; i++) {
          const row = jsonData[i];
          if (row && row.length > 0 && String(row[0]).trim() !== '') {
            data.push({
              nome: String(row[0] || '').trim(),
              tipo: String(row[1] || '').trim(),
              descricao: String(row[2] || '').trim()
            });
          }
        }
      } catch (error) {
        return c.json({ 
          success: false, 
          message: "Erro ao processar arquivo Excel", 
          imported: 0, 
          errors: [`Erro de formato Excel: ${error}`] 
        });
      }
    } else {
      // Handle CSV files (existing logic)
      const uint8Array = new Uint8Array(arrayBuffer);
      let text = '';
      
      // Check for BOM (Byte Order Mark) to detect UTF-8
      const hasBOM = uint8Array.length >= 3 && 
                     uint8Array[0] === 0xEF && 
                     uint8Array[1] === 0xBB && 
                     uint8Array[2] === 0xBF;
      
      if (hasBOM) {
        const utf8Decoder = new TextDecoder('utf-8');
        text = utf8Decoder.decode(arrayBuffer);
      } else {
        const encodings = ['utf-8', 'windows-1252', 'iso-8859-1', 'iso-8859-15'];
        
        for (const encoding of encodings) {
          try {
            const decoder = new TextDecoder(encoding);
            const decoded = decoder.decode(arrayBuffer);
            
            if (!decoded.includes('�') && !decoded.includes('\uFFFD')) {
              text = decoded;
              break;
            }
          } catch {
            continue;
          }
        }
        
        if (!text) {
          const decoder = new TextDecoder('utf-8');
          text = decoder.decode(arrayBuffer);
        }
      }
      
      const lines = text.split('\n').filter(line => line.trim());
      
      if (lines.length < 1) {
        return c.json({ success: false, message: "Arquivo CSV vazio", imported: 0, errors: [] });
      }

      let startIndex = 0;
      const firstLine = lines[0].toLowerCase();
      if (firstLine.includes('nome') || firstLine.includes('name') || firstLine.includes('centro')) {
        startIndex = 1;
      }

      for (let i = startIndex; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        let fields = [];
        let separator = ',';
        
        const commaCount = (line.match(/,/g) || []).length;
        const semicolonCount = (line.match(/;/g) || []).length;
        const tabCount = (line.match(/\t/g) || []).length;
        
        if (semicolonCount > commaCount && semicolonCount > tabCount) {
          separator = ';';
        } else if (tabCount > commaCount && tabCount > semicolonCount) {
          separator = '\t';
        }
        
        if (separator === ',') {
          const regex = /(?:^|,)("(?:[^"]+|"")*"|[^,]*)/g;
          let match;
          while ((match = regex.exec(line)) !== null) {
            let field = match[1];
            if (field.startsWith('"') && field.endsWith('"')) {
              field = field.slice(1, -1).replace(/""/g, '"');
            }
            fields.push(field.trim());
          }
        } else {
          fields = line.split(separator).map((f: string) => f.trim());
        }
        
        fields = fields.map((field: string) => {
          if (!field) return '';
          
          if ((field.startsWith('"') && field.endsWith('"')) || 
              (field.startsWith("'") && field.endsWith("'"))) {
            field = field.slice(1, -1);
          }
          
          return field.trim();
        });

        if (fields.length > 0 && fields[0]) {
          data.push({
            nome: fields[0].trim(),
            tipo: (fields[1] || '').trim(),
            descricao: (fields[2] || '').trim()
          });
        }
      }
    }

    // Process the data
    let imported = 0;
    const errors: string[] = [];

    for (let i = 0; i < data.length; i++) {
      const item = data[i];
      
      try {
        const name = item.nome;
        if (!name) {
          errors.push(`Linha ${i + 1}: Nome é obrigatório`);
          continue;
        }

        let cleanDescription = null;
        if (item.descricao) {
          const potentialDesc = item.descricao.trim();
          if (potentialDesc.length > 0 && 
              !potentialDesc.match(/^[0-9.,]+$/) && 
              !potentialDesc.match(/^[A-Z][a-z]*$/) && 
              potentialDesc.length > 3 && 
              (potentialDesc.includes(' ') || potentialDesc.length > 10)) {
            cleanDescription = potentialDesc;
          }
        }

        const user = c.get("user");
        const result = await c.env.DB.prepare(`
          INSERT INTO cost_centers (name, description, user_id)
          VALUES (?, ?, ?)
        `).bind(name, cleanDescription, user!.id).run();

        if (result.success) {
          imported++;
        } else {
          errors.push(`Linha ${i + 1}: Erro ao inserir no banco de dados`);
        }
      } catch (error) {
        errors.push(`Linha ${i + 1}: Erro ao processar dados - ${error}`);
      }
    }

    return c.json({
      success: imported > 0,
      message: imported > 0 ? `${imported} centro(s) de custo importado(s)` : "Nenhum centro de custo foi importado",
      imported,
      errors
    });
    
  } catch (error) {
    return c.json({ 
      success: false, 
      message: "Erro interno do servidor", 
      imported: 0, 
      errors: ["Erro ao processar arquivo"] 
    });
  }
});

// Create new cost center
app.post("/api/cost-centers", customAuthMiddleware, zValidator("json", CreateCostCenterSchema), async (c) => {
  const user = c.get("user");
  const data = c.req.valid("json");
  
  const result = await c.env.DB.prepare(`
    INSERT INTO cost_centers (name, description, user_id)
    VALUES (?, ?, ?)
  `).bind(
    data.name,
    data.description && data.description.trim() !== '' ? data.description : null,
    user!.id
  ).run();
  
  if (result.success) {
    return c.json({ success: true, id: result.meta.last_row_id });
  } else {
    return c.json({ error: "Failed to create cost center" }, 500);
  }
});

// Update cost center
app.put("/api/cost-centers/:id", customAuthMiddleware, zValidator("json", UpdateCostCenterSchema), async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  const data = c.req.valid("json");
  
  const updates: string[] = [];
  const binds: any[] = [];
  
  if (data.name !== undefined) {
    updates.push("name = ?");
    binds.push(data.name);
  }
  if (data.description !== undefined) {
    updates.push("description = ?");
    binds.push(data.description && data.description.trim() !== '' ? data.description : null);
  }
  
  updates.push("updated_at = CURRENT_TIMESTAMP");
  binds.push(id, user!.id);
  
  const result = await c.env.DB.prepare(`
    UPDATE cost_centers SET ${updates.join(", ")} WHERE id = ? AND user_id = ?
  `).bind(...binds).run();
  
  if (result.success) {
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to update cost center" }, 500);
  }
});

// Delete cost center
app.delete("/api/cost-centers/:id", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  
  const result = await c.env.DB.prepare(
    "DELETE FROM cost_centers WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).run();
  
  if (result.success) {
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to delete cost center" }, 500);
  }
});

// Import transactions from CSV/XLSX
app.post("/api/transactions/import", customAuthMiddleware, async (c) => {
  try {
    console.log('🔄 IMPORT TRANSACTIONS: Starting import process...');
    
    const user = c.get("user");
    if (!user) {
      console.log('❌ IMPORT TRANSACTIONS: No user found in context');
      return c.json({ 
        success: false, 
        message: "Usuário não autenticado", 
        imported: 0, 
        errors: ["Erro de autenticação durante importação"] 
      });
    }
    
    console.log('👤 IMPORT TRANSACTIONS: User authenticated:', user.id, user.email);
    console.log('🔍 IMPORT TRANSACTIONS: Full user object:', JSON.stringify(user, null, 2));
    console.log('🔍 IMPORT TRANSACTIONS: user.id type:', typeof user.id, 'value:', `"${user.id}"`);
    
    // Compare with how payroll import works - let's check if there's any difference
    console.log('🔍 IMPORT TRANSACTIONS: Middleware context check...');
    const contextUser = c.get("user");
    console.log('🔍 IMPORT TRANSACTIONS: Context user same reference?', user === contextUser);
    console.log('🔍 IMPORT TRANSACTIONS: Context user details:', JSON.stringify(contextUser, null, 2));
    
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ success: false, message: "Nenhum arquivo enviado", imported: 0, errors: [] });
    }

    console.log(`📁 IMPORT TRANSACTIONS: Importing file: ${file.name}, size: ${file.size} bytes for user: ${user.id}`);

    const arrayBuffer = await file.arrayBuffer();
    let data: any[] = [];

    // Check if it's an Excel file
    if (file.name.toLowerCase().endsWith('.xlsx') || file.name.toLowerCase().endsWith('.xls')) {
      try {
        // Parse Excel file
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // Convert to JSON with header detection
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { 
          header: 1,
          defval: '',
          raw: false
        }) as any[][];
        
        if (jsonData.length === 0) {
          return c.json({ success: false, message: "Arquivo Excel vazio", imported: 0, errors: [] });
        }

        // Convert array format to object format
        let startIndex = 0;
        const firstRow = jsonData[0] || [];
        
        // Check if first row looks like a header
        const hasHeader = firstRow.some((cell: any) => 
          String(cell).toLowerCase().includes('data') || 
          String(cell).toLowerCase().includes('date') || 
          String(cell).toLowerCase().includes('descricao') ||
          String(cell).toLowerCase().includes('valor') ||
          String(cell).toLowerCase().includes('amount')
        );
        
        if (hasHeader) {
          startIndex = 1;
        }

        // Convert rows to objects
        for (let i = startIndex; i < jsonData.length; i++) {
          const row = jsonData[i];
          if (row && row.length >= 3 && String(row[0]).trim() !== '') {
            let dateValue = String(row[0] || '').trim();
            const originalValue = row[0];
            const originalType = typeof originalValue;
            console.log(`🔍 EXCEL: Processando célula de data:`);
            console.log(`   - Valor original: "${originalValue}"`);
            console.log(`   - Tipo: ${originalType}`);
            console.log(`   - String convertida: "${dateValue}"`);
            
            // DETECTAR E CONVERTER NÚMEROS SERIAIS DO EXCEL
            if (!dateValue || dateValue === '' || dateValue === 'undefined' || dateValue === 'null') {
              console.log(`❌ EXCEL: Célula de data vazia ou inválida`);
              continue;
            }
            
            // CONVERSÃO DIRETA DE NÚMERO SERIAL DO EXCEL
            const numericValue = Number(dateValue);
            if (!isNaN(numericValue) && numericValue > 1 && numericValue < 100000) {
              try {
                console.log(`🔢 EXCEL: Convertendo número serial: ${numericValue}`);
                
                // MÉTODO MAIS ROBUSTO: Conversão direta do serial Excel
                // Excel considera 1 de janeiro de 1900 como serial 1
                // Excel tem um bug: considera 1900 como ano bissexto (não é)
                
                let excelDate: Date;
                
                if (numericValue <= 60) {
                  // Para datas até 29/02/1900 (que não existe), usar conversão direta
                  excelDate = new Date(1900, 0, numericValue); // Janeiro = 0
                } else {
                  // Para datas após 29/02/1900, subtrair 1 para compensar o bug do Excel
                  excelDate = new Date(1900, 0, numericValue - 1);
                }
                
                const year = excelDate.getFullYear();
                const month = excelDate.getMonth() + 1; // JavaScript meses são 0-11
                const day = excelDate.getDate();
                
                console.log(`📅 EXCEL: Serial ${numericValue} → ${day}/${month}/${year}`);
                
                // Validar se a data faz sentido
                if (year >= 1900 && year <= 2100 && month >= 1 && month <= 12 && day >= 1 && day <= 31) {
                  dateValue = `${day.toString().padStart(2, '0')}/${month.toString().padStart(2, '0')}/${year}`;
                  console.log(`✅ EXCEL: Conversão bem-sucedida: "${dateValue}"`);
                } else {
                  console.log(`❌ EXCEL: Data inválida após conversão: ${day}/${month}/${year}`);
                  continue;
                }
              } catch (error) {
                console.log(`❌ EXCEL: Erro na conversão do serial: ${error}`);
                continue;
              }
            }
            
            // 2. QUALQUER FORMATO COM BARRAS - SEMPRE BRASILEIRO DD/MM/AA ou DD/MM/YYYY
            else if (dateValue.match(/^\d{1,2}\/\d{1,2}\/\d{2,4}$/)) {
              console.log(`📅 EXCEL: Detectado formato com barras: "${dateValue}"`);
              const parts = dateValue.split('/');
              
              // INTERPRETAÇÃO BRASILEIRA FORÇADA - NUNCA AMERICANA
              const dayPart = parseInt(parts[0], 10);      // PRIMEIRA PARTE = SEMPRE DIA
              const monthPart = parseInt(parts[1], 10);    // SEGUNDA PARTE = SEMPRE MÊS
              let yearPart = parseInt(parts[2], 10);       // TERCEIRA PARTE = SEMPRE ANO
              
              console.log(`🇧🇷 FORMATO BRASILEIRO FORÇADO: "${parts[0]}"="${dayPart}" (DIA), "${parts[1]}"="${monthPart}" (MÊS), "${parts[2]}"="${yearPart}" (ANO)`);
              
              // Validação de valores numéricos
              if (isNaN(dayPart) || isNaN(monthPart) || isNaN(yearPart)) {
                console.log(`❌ EXCEL: Valores não numéricos na data`);
                continue;
              }
              
              // Expandir ano de 2 dígitos (lógica brasileira padrão)
              if (yearPart < 100) {
                if (yearPart >= 0 && yearPart <= 29) {
                  yearPart = 2000 + yearPart; // 00-29 = 2000-2029
                } else if (yearPart >= 30 && yearPart <= 99) {
                  yearPart = 1900 + yearPart; // 30-99 = 1930-1999
                }
                console.log(`📅 Ano expandido: ${parts[2]} → ${yearPart}`);
              }
              
              // ATRIBUIÇÃO FINAL BRASILEIRA
              const day = dayPart;      // Primeira parte é SEMPRE o dia
              const month = monthPart;  // Segunda parte é SEMPRE o mês
              const year = yearPart;    // Terceira parte é SEMPRE o ano
              
              console.log(`🔒 INTERPRETAÇÃO BRASILEIRA FINAL: DIA=${day}, MÊS=${month}, ANO=${year}`);
              
              // Validação de limites brasileiros
              if (day < 1 || day > 31) {
                console.log(`❌ EXCEL: Dia inválido: ${day} (deve estar entre 1-31)`);
                continue;
              }
              if (month < 1 || month > 12) {
                console.log(`❌ EXCEL: Mês inválido: ${month} (deve estar entre 1-12)`);
                continue;
              }
              if (year < 1900 || year > 2100) {
                console.log(`❌ EXCEL: Ano inválido: ${year} (deve estar entre 1900-2100)`);
                continue;
              }
              
              // Validar se a data existe no calendário
              const testDate = new Date(year, month - 1, day);
              if (testDate.getDate() !== day || testDate.getMonth() !== month - 1 || testDate.getFullYear() !== year) {
                console.log(`❌ EXCEL: Data não existe no calendário: ${day}/${month}/${year}`);
                continue;
              }
              
              dateValue = `${day.toString().padStart(2, '0')}/${month.toString().padStart(2, '0')}/${year}`;
              console.log(`✅ EXCEL: "${originalValue}" → "${dateValue}"`);
              console.log(`✅ Data final em português: ${day} de ${['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'][month-1]} de ${year}`);
            }
            
            // 4. FORMATO ISO YYYY-MM-DD
            else if (dateValue.match(/^\d{4}-\d{1,2}-\d{1,2}$/)) {
              console.log(`📅 EXCEL: Detectado formato ISO: "${dateValue}"`);
              const [year, month, day] = dateValue.split('-');
              dateValue = `${day.padStart(2, '0')}/${month.padStart(2, '0')}/${year}`;
              console.log(`✅ EXCEL ISO: "${originalValue}" → "${dateValue}"`);
            }
            
            // 5. FORMATO COM HÍFEN DD-MM-YY ou DD-MM-YYYY
            else if (dateValue.match(/^\d{1,2}-\d{1,2}-\d{2,4}$/)) {
              console.log(`📅 EXCEL: Detectado formato com hífen: "${dateValue}"`);
              const parts = dateValue.split('-');
              let day = parts[0].padStart(2, '0');
              let month = parts[1].padStart(2, '0');
              let year = parseInt(parts[2], 10);
              
              // Expandir ano de 2 dígitos se necessário
              if (year < 100) {
                year = year < 30 ? 2000 + year : 1900 + year;
              }
              
              dateValue = `${day}/${month}/${year}`;
              console.log(`✅ EXCEL Hífen: "${originalValue}" → "${dateValue}"`);
            }
            
            // 6. FORMATO COM PONTOS DD.MM.YY ou DD.MM.YYYY
            else if (dateValue.match(/^\d{1,2}\.\d{1,2}\.\d{2,4}$/)) {
              console.log(`📅 EXCEL: Detectado formato com pontos: "${dateValue}"`);
              const parts = dateValue.split('.');
              let day = parts[0].padStart(2, '0');
              let month = parts[1].padStart(2, '0');
              let year = parseInt(parts[2], 10);
              
              if (year < 100) {
                year = year < 30 ? 2000 + year : 1900 + year;
              }
              
              dateValue = `${day}/${month}/${year}`;
              console.log(`✅ EXCEL Pontos: "${originalValue}" → "${dateValue}"`);
            }
            // 7. FORMATO COM TEXTO DE MÊS PORTUGUÊS (ex: "15-jul-25", "15 jul 25")
            else if (dateValue.match(/\d{1,2}[-\s](jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)[-\s]\d{2,4}/i)) {
              console.log(`📅 EXCEL: Detectado formato com mês português: "${dateValue}"`);
              const monthsPt: { [key: string]: string } = {
                'jan': '01', 'fev': '02', 'mar': '03', 'abr': '04', 'mai': '05', 'jun': '06',
                'jul': '07', 'ago': '08', 'set': '09', 'out': '10', 'nov': '11', 'dez': '12'
              };
              
              const match = dateValue.match(/(\d{1,2})[-\s]([a-zA-Z]{3})[-\s](\d{2,4})/i);
              if (match) {
                const day = match[1].padStart(2, '0');
                const monthAbbr = match[2].toLowerCase();
                let year = parseInt(match[3], 10);
                
                if (year < 100) {
                  year = year < 30 ? 2000 + year : 1900 + year;
                }
                
                const month = monthsPt[monthAbbr];
                if (month) {
                  dateValue = `${day}/${month}/${year}`;
                  console.log(`✅ EXCEL Mês PT: "${originalValue}" → "${dateValue}"`);
                }
              }
            }
            
            // 8. FORMATO COM TEXTO DE MÊS INGLÊS (ex: "15-Jul-25", "Jul 15, 2025", "31-jan-25")
            else if (dateValue.match(/\d{1,2}[-\s](Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[-\s]\d{2,4}/i)) {
              console.log(`📅 EXCEL: Detectado formato com mês inglês: "${dateValue}"`);
              const monthsEn: { [key: string]: string } = {
                'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04', 'may': '05', 'jun': '06',
                'jul': '07', 'aug': '08', 'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12'
              };
              
              const match = dateValue.match(/(\d{1,2})[-\s]([A-Za-z]{3})[-\s](\d{2,4})/i);
              if (match) {
                const day = match[1].padStart(2, '0');
                const monthAbbr = match[2].toLowerCase();
                let year = parseInt(match[3], 10);
                
                if (year < 100) {
                  year = year < 30 ? 2000 + year : 1900 + year;
                }
                
                const month = monthsEn[monthAbbr];
                if (month) {
                  dateValue = `${day}/${month}/${year}`;
                  console.log(`✅ EXCEL Mês EN: "${originalValue}" → "${dateValue}"`);
                }
              }
            }
            
            // 9. CASO NÃO RECONHECIDO - TENTAR COMO ESTÁ
            else {
              console.log(`⚠️ EXCEL: Formato não reconhecido: "${dateValue}" (original: ${originalValue})`);
              console.log(`⚠️ Tentando usar como está...`);
              
              // Se não conseguiu reconhecer, reportar erro específico
              if (dateValue && dateValue.trim() !== '') {
                console.log(`❌ EXCEL: Formato de data não suportado. Valor encontrado: "${dateValue}"`);
                console.log(`💡 Sugestão: Formate a coluna como 'Geral' ou 'Número' no Excel antes de exportar`);
                // Continue para que seja tratado pela validação posterior
              }
            }
            
            const rowData = {
              data: dateValue,
              descricao: String(row[1] || '').trim(),
              valor: String(row[2] || '').trim(),
              categoria: String(row[3] || '').trim(),
              centro_custo: String(row[4] || '').trim(),
              status: String(row[5] || '').trim()
            };
            console.log(`📋 Excel Row ${i}: ${JSON.stringify(rowData)}`);
            data.push(rowData);
          }
        }
      } catch (error) {
        return c.json({ 
          success: false, 
          message: "Erro ao processar arquivo Excel", 
          imported: 0, 
          errors: [`Erro de formato Excel: ${error}`] 
        });
      }
    } else {
      // Handle CSV files (existing logic)
      const uint8Array = new Uint8Array(arrayBuffer);
      let text = '';
      
      // Check for BOM (Byte Order Mark) to detect UTF-8
      const hasBOM = uint8Array.length >= 3 && 
                     uint8Array[0] === 0xEF && 
                     uint8Array[1] === 0xBB && 
                     uint8Array[2] === 0xBF;
      
      if (hasBOM) {
        // UTF-8 with BOM
        const utf8Decoder = new TextDecoder('utf-8');
        text = utf8Decoder.decode(arrayBuffer);
      } else {
        // Try different encodings, prioritizing those common for Portuguese content
        const encodings = ['utf-8', 'windows-1252', 'iso-8859-1', 'iso-8859-15'];
        
        for (const encoding of encodings) {
          try {
            const decoder = new TextDecoder(encoding);
            const decoded = decoder.decode(arrayBuffer);
            
            // Test if the decoded text contains common Portuguese characters correctly
            // If it contains replacement characters (�) or looks broken, try next encoding
            if (!decoded.includes('�') && !decoded.includes('\uFFFD')) {
              text = decoded;
              break;
            }
          } catch {
            // This encoding failed, try the next one
            continue;
          }
        }
        
        // If all encodings failed, fall back to UTF-8 without fatal mode
        if (!text) {
          const decoder = new TextDecoder('utf-8');
          text = decoder.decode(arrayBuffer);
        }
      }
      
      const lines = text.split('\n').filter((line: string) => line.trim());
      
      if (lines.length < 1) {
        return c.json({ success: false, message: "Arquivo CSV vazio", imported: 0, errors: [] });
      }

      let startIndex = 0;

      // Check if first line looks like a header
      const firstLine = lines[0].toLowerCase();
      if (firstLine.includes('data') || firstLine.includes('date') || firstLine.includes('descricao') || 
          firstLine.includes('valor') || firstLine.includes('amount')) {
        startIndex = 1; // Skip header
      }

      // Process each data line
      for (let i = startIndex; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        // More robust CSV parsing - handle multiple separators
        let fields = [];
        let separator = ',';
        
        // Detect the most likely separator
        const commaCount = (line.match(/,/g) || []).length;
        const semicolonCount = (line.match(/;/g) || []).length;
        const tabCount = (line.match(/\t/g) || []).length;
        
        if (semicolonCount > commaCount && semicolonCount > tabCount) {
          separator = ';';
        } else if (tabCount > commaCount && tabCount > semicolonCount) {
          separator = '\t';
        }
        
        // Parse CSV with proper quote handling
        if (separator === ',') {
          // Handle CSV with potential quotes and commas inside
          const regex = /(?:^|,)("(?:[^"]+|"")*"|[^,]*)/g;
          let match;
          while ((match = regex.exec(line)) !== null) {
            let field = match[1];
            if (field.startsWith('"') && field.endsWith('"')) {
              field = field.slice(1, -1).replace(/""/g, '"');
            }
            fields.push(field.trim());
          }
        } else {
          fields = line.split(separator).map((f: string) => f.trim());
        }
        
        // Clean up fields
        fields = fields.map((field: string) => {
          if (!field) return '';
          
          // Remove surrounding quotes if present
          if ((field.startsWith('"') && field.endsWith('"')) || 
              (field.startsWith("'") && field.endsWith("'"))) {
            field = field.slice(1, -1);
          }
          
          return field.trim();
        });

        if (fields.length >= 3 && fields[0]) {
          const rowData = {
            data: fields[0].trim(),
            descricao: fields[1].trim(),
            valor: fields[2].trim(),
            categoria: (fields[3] || '').trim(),
            centro_custo: (fields[4] || '').trim(),
            status: (fields[5] || '').trim()
          };
          console.log(`CSV Row ${i}: ${JSON.stringify(rowData)}`);
          data.push(rowData);
        }
      }
    }

    console.log(`Total rows to process: ${data.length}`);

    // Get existing categories and cost centers for matching
    const categoriesResult = await c.env.DB.prepare("SELECT * FROM categories WHERE user_id = ?").bind(user!.id).all();
    const costCentersResult = await c.env.DB.prepare("SELECT * FROM cost_centers WHERE user_id = ?").bind(user!.id).all();
    
    const categories = categoriesResult.results as any[];
    const costCenters = costCentersResult.results as any[];

    console.log(`Available categories: ${categories.length}, cost centers: ${costCenters.length}`);

    // Process the data
    let imported = 0;
    const errors: string[] = [];

    for (let i = 0; i < data.length; i++) {
      const item = data[i];
      
      try {
        // Parse fields: date, description, amount, category?, cost_center?, status?
        const dateStr = item.data;
        const description = item.descricao;
        const amountStr = item.valor;
        const categoryName = item.categoria || '';
        const costCenterName = item.centro_custo || '';
        const statusFromFile = item.status || '';

        // Date parsing - FORMATO BRASILEIRO DD/MM/YYYY
        let transactionDate = '';
        if (dateStr) {
          const cleanDateStr = dateStr.trim();
          console.log(`🔍 IMPORTAÇÃO: Data original da planilha: "${cleanDateStr}"`);
          
          if (cleanDateStr.includes('/')) {
            const parts = cleanDateStr.split('/').map((p: string) => p.trim());
            if (parts.length === 3) {
              // Parse inicial dos valores
              const firstPart = parseInt(parts[0], 10);
              const secondPart = parseInt(parts[1], 10);
              let thirdPart = parseInt(parts[2], 10);
              
              console.log(`📊 PLANILHA: "${parts[0]}/${parts[1]}/${parts[2]}" → ${firstPart}/${secondPart}/${thirdPart}`);
              
              // Validação de valores numéricos
              if (isNaN(firstPart) || isNaN(secondPart) || isNaN(thirdPart)) {
                const errorMsg = `Valores não numéricos na data: "${cleanDateStr}"`;
                console.log(`❌ ${errorMsg}`);
                errors.push(`Linha ${i + 1}: ${errorMsg}`);
                continue;
              }
              
              // Expandir anos de 2 dígitos
              if (thirdPart < 100) {
                thirdPart = thirdPart < 50 ? 2000 + thirdPart : 1900 + thirdPart;
                console.log(`📅 Ano expandido: ${parts[2]} → ${thirdPart}`);
              }
              
              // FORMATO BRASILEIRO FORÇADO: SEMPRE DD/MM/YYYY
              // NUNCA tentar detectar formato americano - sempre brasileiro
              const day = firstPart;      // Primeira parte = SEMPRE DIA
              const month = secondPart;   // Segunda parte = SEMPRE MÊS  
              const year = thirdPart;     // Terceira parte = SEMPRE ANO
              
              console.log(`🇧🇷 FORMATO BRASILEIRO FORÇADO (sem detecção): DIA=${day}, MÊS=${month}, ANO=${year}`);
              console.log(`📅 Data em português: ${day} de ${['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'][month-1]} de ${year}`);
              
              // Validação final dos valores
              if (day < 1 || day > 31) {
                const errorMsg = `Dia inválido: ${day} (deve estar entre 1 e 31)`;
                console.log(`❌ ${errorMsg}`);
                errors.push(`Linha ${i + 1}: ${errorMsg}`);
                continue;
              }
              
              if (month < 1 || month > 12) {
                const errorMsg = `Mês inválido: ${month} (deve estar entre 1 e 12)`;
                console.log(`❌ ${errorMsg}`);
                errors.push(`Linha ${i + 1}: ${errorMsg}`);
                continue;
              }
              
              if (year < 1900 || year > 2100) {
                const errorMsg = `Ano inválido: ${year} (deve estar entre 1900 e 2100)`;
                console.log(`❌ ${errorMsg}`);
                errors.push(`Linha ${i + 1}: ${errorMsg}`);
                continue;
              }
              
              // Validar se a data existe no calendário (ex: 31/02/2025 não existe)
              const testDate = new Date(year, month - 1, day);
              if (testDate.getDate() !== day || testDate.getMonth() !== month - 1 || testDate.getFullYear() !== year) {
                const errorMsg = `Data não existe no calendário: ${day}/${month}/${year}`;
                console.log(`❌ ${errorMsg}`);
                errors.push(`Linha ${i + 1}: ${errorMsg}`);
                continue;
              }
              
              // Formato ISO para banco: YYYY-MM-DD
              transactionDate = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
              console.log(`✅ SUCESSO: "${cleanDateStr}" → BANCO: "${transactionDate}"`);
              console.log(`✅ VERIFICAÇÃO: ${day}/${month}/${year} → ISO: ${transactionDate}`);
              
            } else {
              console.log(`❌ Data deve ter 3 partes separadas por /: "${cleanDateStr}"`);
              errors.push(`Linha ${i + 1}: Formato de data inválido: ${cleanDateStr}. Use DD/MM/YYYY`);
              continue;
            }
          } else {
            console.log(`❌ Data deve conter barras "/": "${cleanDateStr}"`);
            errors.push(`Linha ${i + 1}: Formato de data inválido: ${cleanDateStr}. Use DD/MM/YYYY`);
            continue;
          }
        } else {
          errors.push(`Linha ${i + 1}: Data é obrigatória`);
          continue;
        }

        // Validate description
        if (!description) {
          errors.push(`Linha ${i + 1}: Descrição é obrigatória`);
          continue;
        }

        // Parse amount
        let amount = 0;
        if (amountStr) {
          // Handle Brazilian number format (1.234,56) and international (1,234.56)
          let cleanAmount = amountStr.replace(/[^\d,.-]/g, ''); // Remove currency symbols
          
          // If it has both comma and dot, determine which is decimal separator
          if (cleanAmount.includes(',') && cleanAmount.includes('.')) {
            const lastCommaIndex = cleanAmount.lastIndexOf(',');
            const lastDotIndex = cleanAmount.lastIndexOf('.');
            
            if (lastCommaIndex > lastDotIndex) {
              // Brazilian format: 1.234,56
              cleanAmount = cleanAmount.replace(/\./g, '').replace(',', '.');
            } else {
              // International format: 1,234.56
              cleanAmount = cleanAmount.replace(/,/g, '');
            }
          } else if (cleanAmount.includes(',')) {
            // Check if comma is likely decimal separator (only if 2 digits after comma)
            const commaIndex = cleanAmount.lastIndexOf(',');
            const afterComma = cleanAmount.substring(commaIndex + 1);
            if (afterComma.length <= 2) {
              cleanAmount = cleanAmount.replace(',', '.');
            } else {
              cleanAmount = cleanAmount.replace(/,/g, '');
            }
          }
          
          amount = parseFloat(cleanAmount);
          if (isNaN(amount)) {
            errors.push(`Linha ${i + 1}: Valor inválido - ${amountStr}`);
            continue;
          }
        } else {
          errors.push(`Linha ${i + 1}: Valor é obrigatório`);
          continue;
        }

        // Find category by name (case-insensitive)
        let categoryId = null;
        if (categoryName) {
          const category = categories.find(c => 
            c.name.toLowerCase() === categoryName.toLowerCase()
          );
          if (category) {
            categoryId = category.id;
          }
        }

        // Find cost center by name (case-insensitive)
        let costCenterId = null;
        if (costCenterName) {
          const costCenter = costCenters.find(cc => 
            cc.name.toLowerCase() === costCenterName.toLowerCase()
          );
          if (costCenter) {
            costCenterId = costCenter.id;
          }
        }

        // Process status from file or set default based on amount
        let finalStatus = amount > 0 ? 'NÃO RECEBIDO' : 'NÃO PAGO'; // Default status
        
        if (statusFromFile) {
          const cleanStatus = statusFromFile.toUpperCase().trim();
          // Validate and use status from file if it's valid
          if (cleanStatus === 'PAGO' || cleanStatus === 'NÃO PAGO' || 
              cleanStatus === 'RECEBIDO' || cleanStatus === 'NÃO RECEBIDO') {
            finalStatus = cleanStatus;
            console.log(`📊 Status da planilha usado: "${statusFromFile}" → "${finalStatus}"`);
          } else {
            console.log(`⚠️ Status inválido na planilha: "${statusFromFile}", usando padrão: "${finalStatus}"`);
          }
        }

        console.log(`🔄 IMPORT TRANSACTIONS: Processing line ${i + 1}: date=${transactionDate}, desc=${description}, amount=${amount}, catId=${categoryId}, costId=${costCenterId}, status=${finalStatus}`);
        console.log(`🔧 IMPORT TRANSACTIONS: About to insert with user ID: ${user!.id}`);
        console.log(`🔧 IMPORT TRANSACTIONS: User object:`, JSON.stringify(user));
        console.log(`🔧 IMPORT TRANSACTIONS: Insert parameters:`, {
          transactionDate, 
          description, 
          amount, 
          categoryId, 
          costCenterId, 
          finalStatus, 
          userId: user!.id
        });
        
        // IMPORTANT: Make sure we have a valid user.id before inserting
        if (!user || !user.id) {
          console.error(`❌ IMPORT TRANSACTIONS: Invalid user object at line ${i + 1}:`, user);
          errors.push(`Linha ${i + 1}: Erro de autenticação - usuário inválido`);
          continue;
        }
        
        console.log(`Processing transaction line ${i + 1}: date=${transactionDate}, desc=${description}, amount=${amount}, catId=${categoryId}, costId=${costCenterId}, status=${finalStatus}`);

        const result = await c.env.DB.prepare(`
          INSERT INTO transactions (date, description, amount, category_id, cost_center_id, is_recurring, status, user_id)
          VALUES (?, ?, ?, ?, ?, 0, ?, ?)
        `).bind(transactionDate, description, amount, categoryId, costCenterId, finalStatus, user!.id).run();

        if (result.success) {
          imported++;
          console.log(`Transaction line ${i + 1} imported successfully`);
        } else {
          console.log(`Transaction line ${i + 1} failed to import`);
          errors.push(`Linha ${i + 1}: Erro ao inserir no banco de dados`);
        }
      } catch (error) {
        errors.push(`Linha ${i + 1}: Erro ao processar dados - ${error}`);
      }
    }

    
    
    return c.json({
      success: imported > 0,
      message: imported > 0 ? `${imported} transação(ões) importada(s) para usuário ${user.id}` : "Nenhuma transação foi importada",
      imported,
      errors,
      debug: {
        userId: user.id,
        userEmail: user.email,
        totalProcessed: data.length,
        imported: imported,
        timestamp: new Date().toISOString()
      }
    });
    
  } catch (error) {
    return c.json({ 
      success: false, 
      message: "Erro interno do servidor", 
      imported: 0, 
      errors: ["Erro ao processar arquivo"] 
    });
  }
});

// Get all transactions with details
app.get("/api/transactions", customAuthMiddleware, async (c) => {
  try {
    console.log("🔄 API: Fetching transactions...");
    
    const user = c.get("user");
    if (!user) {
      console.log('❌ API: No user found in transactions get');
      return c.json({ error: "User not authenticated" }, 401);
    }
    
    console.log('👤 API: Fetching transactions for user:', user.id);
    
    const query = `
      SELECT 
        t.*,
        c.name as category_name,
        cc.name as cost_center_name
      FROM transactions t
      LEFT JOIN categories c ON t.category_id = c.id AND c.user_id = ?
      LEFT JOIN cost_centers cc ON t.cost_center_id = cc.id AND cc.user_id = ?
      WHERE t.user_id = ?
      ORDER BY t.date DESC, t.id DESC
    `;
    
    console.log("📊 API Transactions: Executing query for user", user.id);
    
    const transactions = await c.env.DB.prepare(query).bind(user.id, user.id, user.id).all();
    
    console.log("✅ API Transactions: Found", transactions.results?.length || 0, "transactions for user", user.id);
    
    return c.json(transactions.results || []);
  } catch (error) {
    console.error("❌ API Transactions Error:", error);
    return c.json({ error: "Failed to fetch transactions" }, 500);
  }
});

// Create new transaction
app.post("/api/transactions", customAuthMiddleware, async (c) => {
  try {
    console.log('🔄 API: Creating transaction...');
    
    const user = c.get("user");
    if (!user) {
      console.log('❌ API: No user found in context');
      return c.json({ error: "User not authenticated" }, 401);
    }
    
    console.log('👤 API: User from middleware:', user.id, user.email);
    
    const data = await c.req.json();
    console.log('📝 API: Transaction data received:', data);
    
    // Validate required fields
    if (!data.description || !data.amount || !data.date) {
      console.log('❌ API: Missing required fields');
      return c.json({ error: "Descrição, valor e data são obrigatórios" }, 400);
    }
    
    // Set default status based on amount if not provided
    const defaultStatus = data.status || (data.amount > 0 ? 'NÃO RECEBIDO' : 'NÃO PAGO');
    
    console.log('💾 API: Inserting transaction into database for user:', user.id);
    const result = await c.env.DB.prepare(`
      INSERT INTO transactions (date, description, amount, category_id, cost_center_id, is_recurring, status, user_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      data.date,
      data.description,
      parseFloat(data.amount),
      data.category_id || null,
      data.cost_center_id || null,
      data.is_recurring ? 1 : 0,
      defaultStatus,
      user.id
    ).run();
    
    console.log('📊 API: Database result:', result);
    
    if (result.success) {
      console.log('✅ API: Transaction created successfully with ID:', result.meta.last_row_id);
      return c.json({ success: true, id: result.meta.last_row_id });
    } else {
      console.log('❌ API: Failed to create transaction:', result);
      return c.json({ error: "Failed to create transaction", details: result }, 500);
    }
  } catch (error) {
    console.error('❌ API: Error creating transaction:', error);
    return c.json({ 
      error: "Internal server error", 
      details: error instanceof Error ? error.message : 'Unknown error'
    }, 500);
  }
});

// Update transaction
app.put("/api/transactions/:id", customAuthMiddleware, zValidator("json", UpdateTransactionSchema), async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "User not authenticated" }, 401);
  }
  
  const id = c.req.param("id");
  const data = c.req.valid("json");
  
  const updates: string[] = [];
  const binds: any[] = [];
  
  if (data.date !== undefined) {
    updates.push("date = ?");
    binds.push(data.date);
  }
  if (data.description !== undefined) {
    updates.push("description = ?");
    binds.push(data.description);
  }
  if (data.amount !== undefined) {
    updates.push("amount = ?");
    binds.push(data.amount);
  }
  if (data.category_id !== undefined) {
    updates.push("category_id = ?");
    binds.push(data.category_id || null);
  }
  if (data.cost_center_id !== undefined) {
    updates.push("cost_center_id = ?");
    binds.push(data.cost_center_id || null);
  }
  if (data.is_recurring !== undefined) {
    updates.push("is_recurring = ?");
    binds.push(data.is_recurring ? 1 : 0);
  }
  if (data.status !== undefined) {
    updates.push("status = ?");
    binds.push(data.status);
  }
  
  updates.push("updated_at = CURRENT_TIMESTAMP");
  binds.push(id, user.id);
  
  const result = await c.env.DB.prepare(`
    UPDATE transactions SET ${updates.join(", ")} WHERE id = ? AND user_id = ?
  `).bind(...binds).run();
  
  if (result.success) {
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to update transaction" }, 500);
  }
});

// Toggle transaction status
app.patch("/api/transactions/:id/status", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "User not authenticated" }, 401);
  }
  
  const id = c.req.param("id");
  
  // First get current status and amount
  const transaction = await c.env.DB.prepare(
    "SELECT status, amount FROM transactions WHERE id = ? AND user_id = ?"
  ).bind(id, user.id).first();
  
  if (!transaction) {
    return c.json({ error: "Transaction not found" }, 404);
  }
  
  // Toggle status based on amount (positive = income, negative = expense)
  const currentStatus = transaction.status || ((transaction.amount as number) > 0 ? 'NÃO RECEBIDO' : 'NÃO PAGO');
  let newStatus;
  
  if ((transaction.amount as number) > 0) {
    // For positive amounts (income): toggle between RECEBIDO and NÃO RECEBIDO
    newStatus = currentStatus === 'RECEBIDO' ? 'NÃO RECEBIDO' : 'RECEBIDO';
  } else {
    // For negative amounts (expense): toggle between PAGO and NÃO PAGO
    newStatus = currentStatus === 'PAGO' ? 'NÃO PAGO' : 'PAGO';
  }
  
  const result = await c.env.DB.prepare(
    "UPDATE transactions SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
  ).bind(newStatus, id, user.id).run();
  
  if (result.success) {
    return c.json({ success: true, status: newStatus });
  } else {
    return c.json({ error: "Failed to update transaction status" }, 500);
  }
});

// Update transaction amount
app.patch("/api/transactions/:id/amount", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "User not authenticated" }, 401);
  }
  
  const id = c.req.param("id");
  const body = await c.req.json();
  const amount = body.amount;
  
  if (amount === undefined || amount === null) {
    return c.json({ error: "Amount is required" }, 400);
  }
  
  if (isNaN(parseFloat(amount))) {
    return c.json({ error: "Invalid amount value" }, 400);
  }
  
  const result = await c.env.DB.prepare(
    "UPDATE transactions SET amount = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
  ).bind(parseFloat(amount), id, user.id).run();
  
  if (result.success) {
    return c.json({ success: true, amount: parseFloat(amount) });
  } else {
    return c.json({ error: "Failed to update transaction amount" }, 500);
  }
});

// Delete transaction
app.delete("/api/transactions/:id", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "User not authenticated" }, 401);
  }
  
  const id = c.req.param("id");
  
  const result = await c.env.DB.prepare(
    "DELETE FROM transactions WHERE id = ? AND user_id = ?"
  ).bind(id, user.id).run();
  
  if (result.success) {
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to delete transaction" }, 500);
  }
});

// Import fixed accounts from CSV/XLSX
app.post("/api/fixed-accounts/import", customAuthMiddleware, async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ success: false, message: "Nenhum arquivo enviado", imported: 0, errors: [] });
    }

    console.log(`Importing fixed accounts file: ${file.name}, size: ${file.size} bytes`);

    const arrayBuffer = await file.arrayBuffer();
    let data: any[] = [];

    // Check if it's an Excel file
    if (file.name.toLowerCase().endsWith('.xlsx') || file.name.toLowerCase().endsWith('.xls')) {
      try {
        // Parse Excel file
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // Convert to JSON with header detection
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { 
          header: 1,
          defval: '',
          raw: false
        }) as any[][];
        
        if (jsonData.length === 0) {
          return c.json({ success: false, message: "Arquivo Excel vazio", imported: 0, errors: [] });
        }

        // Convert array format to object format
        let startIndex = 0;
        const firstRow = jsonData[0] || [];
        
        // Check if first row looks like a header
        const hasHeader = firstRow.some((cell: any) => 
          String(cell).toLowerCase().includes('vencimento') || 
          String(cell).toLowerCase().includes('dia') || 
          String(cell).toLowerCase().includes('descricao') ||
          String(cell).toLowerCase().includes('valor') ||
          String(cell).toLowerCase().includes('pagar')
        );
        
        if (hasHeader) {
          startIndex = 1;
        }

        // Convert rows to objects
        for (let i = startIndex; i < jsonData.length; i++) {
          const row = jsonData[i];
          console.log(`Processing Excel row ${i}: ${JSON.stringify(row)}`);
          if (row && row.length >= 6 && String(row[0]).trim() !== '') {
            // O primeiro campo é sempre o dia de vencimento (1-31)
            let dueDayValue = String(row[0] || '').trim();
            
            // Processar dia de vencimento
            const numericValue = Number(dueDayValue);
            if (!isNaN(numericValue)) {
              if (numericValue >= 1 && numericValue <= 31) {
                // É um dia válido
                dueDayValue = Math.floor(numericValue).toString();
                console.log(`📅 EXCEL Fixed: Dia de vencimento: ${dueDayValue}`);
              } else if (numericValue > 100) {
                // Pode ser um número serial de data do Excel - extrair apenas o dia
                try {
                  let excelDate: Date;
                  if (numericValue <= 60) {
                    excelDate = new Date(1900, 0, numericValue);
                  } else {
                    excelDate = new Date(1900, 0, numericValue - 1);
                  }
                  const day = excelDate.getDate();
                  if (day >= 1 && day <= 31) {
                    dueDayValue = day.toString();
                    console.log(`📅 EXCEL Fixed: Serial ${numericValue} → Dia: ${dueDayValue}`);
                  } else {
                    console.log(`❌ EXCEL Fixed: Dia inválido extraído: ${day}`);
                    continue;
                  }
                } catch (error) {
                  console.log(`❌ EXCEL Fixed: Erro ao extrair dia do serial: ${error}`);
                  continue;
                }
              } else {
                console.log(`❌ EXCEL Fixed: Valor inválido para dia: ${numericValue}`);
                continue;
              }
            } else {
              console.log(`❌ EXCEL Fixed: Valor não numérico para dia: ${dueDayValue}`);
              continue;
            }
            
            data.push({
              vencimento_dia: dueDayValue,
              descricao: String(row[1] || '').trim(),
              categoria: String(row[2] || '').trim(),
              centro_custo: String(row[3] || '').trim(),
              a_quem_pagar: String(row[4] || '').trim(),
              valor: String(row[5] || '').trim(),
              status: String(row[6] || '').trim(),
              ativacao: String(row[7] || '').trim()
            });
          }
        }
      } catch (error) {
        return c.json({ 
          success: false, 
          message: "Erro ao processar arquivo Excel", 
          imported: 0, 
          errors: [`Erro de formato Excel: ${error}`] 
        });
      }
    } else {
      // Handle CSV files
      const uint8Array = new Uint8Array(arrayBuffer);
      let text = '';
      
      // Check for BOM (Byte Order Mark) to detect UTF-8
      const hasBOM = uint8Array.length >= 3 && 
                     uint8Array[0] === 0xEF && 
                     uint8Array[1] === 0xBB && 
                     uint8Array[2] === 0xBF;
      
      if (hasBOM) {
        const utf8Decoder = new TextDecoder('utf-8');
        text = utf8Decoder.decode(arrayBuffer);
      } else {
        const encodings = ['utf-8', 'windows-1252', 'iso-8859-1', 'iso-8859-15'];
        
        for (const encoding of encodings) {
          try {
            const decoder = new TextDecoder(encoding);
            const decoded = decoder.decode(arrayBuffer);
            
            if (!decoded.includes('�') && !decoded.includes('\uFFFD')) {
              text = decoded;
              break;
            }
          } catch {
            continue;
          }
        }
        
        if (!text) {
          const decoder = new TextDecoder('utf-8');
          text = decoder.decode(arrayBuffer);
        }
      }
      
      const lines = text.split('\n').filter((line: string) => line.trim());
      
      if (lines.length < 1) {
        return c.json({ success: false, message: "Arquivo CSV vazio", imported: 0, errors: [] });
      }

      let startIndex = 0;

      // Check if first line looks like a header
      const firstLine = lines[0].toLowerCase();
      if (firstLine.includes('vencimento') || firstLine.includes('dia') || firstLine.includes('descricao') || 
          firstLine.includes('valor') || firstLine.includes('pagar')) {
        startIndex = 1; // Skip header
      }

      // Process each data line
      for (let i = startIndex; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        // More robust CSV parsing - handle multiple separators
        let fields = [];
        let separator = ',';
        
        // Detect the most likely separator
        const commaCount = (line.match(/,/g) || []).length;
        const semicolonCount = (line.match(/;/g) || []).length;
        const tabCount = (line.match(/\t/g) || []).length;
        
        if (semicolonCount > commaCount && semicolonCount > tabCount) {
          separator = ';';
        } else if (tabCount > commaCount && tabCount > semicolonCount) {
          separator = '\t';
        }
        
        // Parse CSV with proper quote handling
        if (separator === ',') {
          const regex = /(?:^|,)("(?:[^"]+|"")*"|[^,]*)/g;
          let match;
          while ((match = regex.exec(line)) !== null) {
            let field = match[1];
            if (field.startsWith('"') && field.endsWith('"')) {
              field = field.slice(1, -1).replace(/""/g, '"');
            }
            fields.push(field.trim());
          }
        } else {
          fields = line.split(separator).map((f: string) => f.trim());
        }
        
        // Clean up fields
        fields = fields.map((field: string) => {
          if (!field) return '';
          
          if ((field.startsWith('"') && field.endsWith('"')) || 
              (field.startsWith("'") && field.endsWith("'"))) {
            field = field.slice(1, -1);
          }
          
          return field.trim();
        });

        if (fields.length >= 6 && fields[0]) {
          // O primeiro campo é sempre o dia de vencimento (1-31)
          const dueDayValue = fields[0].trim();
          
          data.push({
            vencimento_dia: dueDayValue,
            descricao: fields[1].trim(),
            categoria: (fields[2] || '').trim(),
            centro_custo: (fields[3] || '').trim(),
            a_quem_pagar: fields[4].trim(),
            valor: (fields[5] || '').trim(),
            status: (fields[6] || '').trim(),
            ativacao: (fields[7] || '').trim()
          });
        }
      }
    }

    console.log(`Total fixed account rows to process: ${data.length}`);

    // Get existing categories and cost centers for matching
    const categoriesResult = await c.env.DB.prepare("SELECT * FROM categories WHERE user_id = ?").bind(user!.id).all();
    const costCentersResult = await c.env.DB.prepare("SELECT * FROM cost_centers WHERE user_id = ?").bind(user!.id).all();
    
    const categories = categoriesResult.results as any[];
    const costCenters = costCentersResult.results as any[];

    console.log(`Available categories: ${categories.length}, cost centers: ${costCenters.length}`);

    // Process the data
    let imported = 0;
    const errors: string[] = [];

    for (let i = 0; i < data.length; i++) {
      const item = data[i];
      
      try {
        // Parse fields: due_day, description, category, cost_center, payee, amount
        const dueDayStr = item.vencimento_dia;
        const description = item.descricao;
        const categoryName = item.categoria || '';
        const costCenterName = item.centro_custo || '';
        const payee = item.a_quem_pagar;
        const amountStr = item.valor;
        const statusFromFile = item.status || '';
        const ativacaoFromFile = item.ativacao || '';

        // Validate due day
        let dueDay = 0;
        if (dueDayStr) {
          dueDay = parseInt(dueDayStr.trim(), 10);
          if (isNaN(dueDay) || dueDay < 1 || dueDay > 31) {
            errors.push(`Linha ${i + 1}: Dia de vencimento inválido - ${dueDayStr} (deve ser entre 1 e 31)`);
            continue;
          }
        } else {
          errors.push(`Linha ${i + 1}: Dia de vencimento é obrigatório`);
          continue;
        }

        // Validate description
        if (!description) {
          errors.push(`Linha ${i + 1}: Descrição é obrigatória`);
          continue;
        }

        // Validate payee
        if (!payee) {
          errors.push(`Linha ${i + 1}: A quem pagar é obrigatório`);
          continue;
        }

        // Parse amount
        let amount = 0;
        if (amountStr) {
          // Handle Brazilian number format (1.234,56) and international (1,234.56)
          let cleanAmount = amountStr.replace(/[^\d,.-]/g, ''); // Remove currency symbols
          
          // If it has both comma and dot, determine which is decimal separator
          if (cleanAmount.includes(',') && cleanAmount.includes('.')) {
            const lastCommaIndex = cleanAmount.lastIndexOf(',');
            const lastDotIndex = cleanAmount.lastIndexOf('.');
            
            if (lastCommaIndex > lastDotIndex) {
              // Brazilian format: 1.234,56
              cleanAmount = cleanAmount.replace(/\./g, '').replace(',', '.');
            } else {
              // International format: 1,234.56
              cleanAmount = cleanAmount.replace(/,/g, '');
            }
          } else if (cleanAmount.includes(',')) {
            // Check if comma is likely decimal separator (only if 2 digits after comma)
            const commaIndex = cleanAmount.lastIndexOf(',');
            const afterComma = cleanAmount.substring(commaIndex + 1);
            if (afterComma.length <= 2) {
              cleanAmount = cleanAmount.replace(',', '.');
            } else {
              cleanAmount = cleanAmount.replace(/,/g, '');
            }
          }
          
          amount = parseFloat(cleanAmount);
          if (isNaN(amount)) {
            errors.push(`Linha ${i + 1}: Valor inválido - ${amountStr}`);
            continue;
          }
        } else {
          errors.push(`Linha ${i + 1}: Valor é obrigatório`);
          continue;
        }

        // Find category by name (case-insensitive)
        let categoryId = null;
        if (categoryName) {
          const category = categories.find(c => 
            c.name.toLowerCase() === categoryName.toLowerCase()
          );
          if (category) {
            categoryId = category.id;
          }
        }

        // Find cost center by name (case-insensitive)
        let costCenterId = null;
        if (costCenterName) {
          const costCenter = costCenters.find(cc => 
            cc.name.toLowerCase() === costCenterName.toLowerCase()
          );
          if (costCenter) {
            costCenterId = costCenter.id;
          }
        }

        // Processar status da planilha
        let finalStatus = 'NÃO PAGO'; // Status padrão para contas fixas
        if (statusFromFile) {
          const cleanStatus = statusFromFile.toUpperCase().trim();
          if (cleanStatus === 'PAGO' || cleanStatus === 'NÃO PAGO') {
            finalStatus = cleanStatus;
            console.log(`📊 FIXED ACCOUNT: Status da planilha usado: "${statusFromFile}" → "${finalStatus}"`);
          } else {
            console.log(`⚠️ FIXED ACCOUNT: Status inválido na planilha: "${statusFromFile}", usando padrão: "${finalStatus}"`);
          }
        }

        // Processar ativação da planilha
        let isActive = true; // Padrão: ativa
        if (ativacaoFromFile) {
          const cleanAtivacao = ativacaoFromFile.toUpperCase().trim();
          if (cleanAtivacao === 'INATIVA' || cleanAtivacao === 'DESATIVA' || cleanAtivacao === 'DESATIVADA') {
            isActive = false;
            console.log(`📊 FIXED ACCOUNT: Ativação da planilha: "${ativacaoFromFile}" → Inativa`);
          } else if (cleanAtivacao === 'ATIVA' || cleanAtivacao === 'ATIVADA') {
            isActive = true;
            console.log(`📊 FIXED ACCOUNT: Ativação da planilha: "${ativacaoFromFile}" → Ativa`);
          }
        }

        console.log(`Processing fixed account line ${i + 1}: due_day=${dueDay}, desc=${description}, payee=${payee}, amount=${amount}, catId=${categoryId}, costId=${costCenterId}, status=${finalStatus}, active=${isActive}`);
        console.log(`🔧 IMPORT: Using user ID for fixed account: ${user!.id}`);

        const result = await c.env.DB.prepare(`
          INSERT INTO fixed_accounts (due_day, description, amount, category_id, cost_center_id, payee, is_active, status, user_id)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(dueDay, description, amount, categoryId, costCenterId, payee, isActive ? 1 : 0, finalStatus, user!.id).run();
        
        console.log(`🔧 IMPORT: Fixed account insert result:`, result);

        if (result.success) {
          imported++;
          console.log(`Fixed account line ${i + 1} imported successfully`);
        } else {
          console.log(`Fixed account line ${i + 1} failed to import`);
          errors.push(`Linha ${i + 1}: Erro ao inserir no banco de dados`);
        }
      } catch (error) {
        errors.push(`Linha ${i + 1}: Erro ao processar dados - ${error}`);
      }
    }

    // Add final debugging info
    console.log(`🔧 IMPORT FINAL: Fixed accounts import completed. Imported: ${imported}, Errors: ${errors.length}`);
    console.log(`🔧 IMPORT FINAL: User ID used for imports: ${user!.id}`);
    
    return c.json({
      success: imported > 0,
      message: imported > 0 ? `${imported} conta(s) fixa(s) importada(s)` : "Nenhuma conta fixa foi importada",
      imported,
      errors,
      debug: {
        userId: user!.id,
        totalProcessed: data.length,
        imported: imported
      }
    });
    
  } catch (error) {
    return c.json({ 
      success: false, 
      message: "Erro interno do servidor", 
      imported: 0, 
      errors: ["Erro ao processar arquivo"] 
    });
  }
});

// Get all fixed accounts with details
app.get("/api/fixed-accounts", customAuthMiddleware, async (c) => {
  try {
    console.log("🔄 API: Fetching fixed accounts...");
    
    const user = c.get("user");
    if (!user) {
      console.log('❌ API: No user found in fixed accounts get');
      return c.json({ error: "User not authenticated" }, 401);
    }
    
    console.log('👤 API: Fetching fixed accounts for user:', user.id);
    
    // First check what data exists in the database
    const allFixedAccounts = await c.env.DB.prepare("SELECT * FROM fixed_accounts").all();
    console.log('🔍 DEBUG Fixed: All fixed accounts in database:', allFixedAccounts.results?.length || 0);
    
    const userFixedAccounts = await c.env.DB.prepare("SELECT * FROM fixed_accounts WHERE user_id = ?").bind(user.id).all();
    console.log('🔍 DEBUG Fixed: Fixed accounts for current user:', userFixedAccounts.results?.length || 0);
    console.log('🔍 DEBUG Fixed: Current user ID:', user.id);
    console.log('🔍 DEBUG Fixed: Sample user IDs in DB:', allFixedAccounts.results?.slice(0, 5).map((fa: any) => ({ id: fa.id, user_id: fa.user_id, description: fa.description })));
    
    // Check if there are any fixed accounts with null or empty user_id
    const orphanedFixedAccounts = await c.env.DB.prepare("SELECT * FROM fixed_accounts WHERE user_id IS NULL OR user_id = ''").all();
    console.log('🔍 DEBUG Fixed: Orphaned fixed accounts (no user_id):', orphanedFixedAccounts.results?.length || 0);
    
    const fixedAccounts = await c.env.DB.prepare(`
      SELECT 
        fa.*,
        c.name as category_name,
        cc.name as cost_center_name
      FROM fixed_accounts fa
      LEFT JOIN categories c ON fa.category_id = c.id AND c.user_id = ?
      LEFT JOIN cost_centers cc ON fa.cost_center_id = cc.id AND cc.user_id = ?
      WHERE fa.user_id = ?
      ORDER BY fa.due_day ASC, fa.id DESC
    `).bind(user.id, user.id, user.id).all();
    
    console.log("✅ API Fixed Accounts: Found", fixedAccounts.results?.length || 0, "fixed accounts for user", user.id);
    
    return c.json(fixedAccounts.results || []);
  } catch (error) {
    console.error("❌ API Fixed Accounts Error:", error);
    return c.json({ error: "Failed to fetch fixed accounts" }, 500);
  }
});

// Create new fixed account
app.post("/api/fixed-accounts", customAuthMiddleware, zValidator("json", CreateFixedAccountSchema), async (c) => {
  const user = c.get("user");
  const data = c.req.valid("json");
  
  // Ensure amount is negative for fixed account expenses
  let amount = data.amount;
  if (amount > 0) {
    amount = -amount;
  }
  
  const result = await c.env.DB.prepare(`
    INSERT INTO fixed_accounts (due_day, description, amount, category_id, cost_center_id, payee, is_active, user_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    data.due_day,
    data.description,
    amount,
    data.category_id || null,
    data.cost_center_id || null,
    data.payee,
    data.is_active !== false ? 1 : 0,
    user!.id
  ).run();
  
  if (result.success) {
    return c.json({ success: true, id: result.meta.last_row_id });
  } else {
    return c.json({ error: "Failed to create fixed account" }, 500);
  }
});

// Update fixed account
app.put("/api/fixed-accounts/:id", customAuthMiddleware, zValidator("json", UpdateFixedAccountSchema), async (c) => {
  try {
    console.log('🔄 API UPDATE: Starting fixed account update...');
    
    const user = c.get("user");
    if (!user) {
      console.log('❌ API UPDATE: No user found in context');
      return c.json({ error: "User not authenticated" }, 401);
    }
    
    const id = c.req.param("id");
    const data = c.req.valid("json");
    
    console.log('🔄 API UPDATE: User ID:', user.id);
    console.log('🔄 API UPDATE: Account ID:', id);
    console.log('🔄 API UPDATE: Update data:', data);
    
    // Get current fixed account to check status change
    const currentFixedAccount = await c.env.DB.prepare(
      "SELECT * FROM fixed_accounts WHERE id = ? AND user_id = ?"
    ).bind(id, user.id).first();
    
    console.log('🔄 API UPDATE: Current account found:', !!currentFixedAccount);
    
    if (!currentFixedAccount) {
      console.log('❌ API UPDATE: Fixed account not found for user');
      return c.json({ error: "Fixed account not found" }, 404);
    }
    
    const updates: string[] = [];
    const binds: any[] = [];
    
    if (data.due_day !== undefined) {
      console.log('🔄 API UPDATE: Updating due_day:', data.due_day);
      updates.push("due_day = ?");
      binds.push(data.due_day);
    }
    if (data.description !== undefined) {
      console.log('🔄 API UPDATE: Updating description:', data.description);
      updates.push("description = ?");
      binds.push(data.description);
    }
    if (data.amount !== undefined) {
      // Ensure amount is negative for fixed account expenses
      let amount = data.amount;
      if (amount > 0) {
        amount = -amount;
      }
      console.log('🔄 API UPDATE: Updating amount:', amount);
      updates.push("amount = ?");
      binds.push(amount);
    }
    if (data.category_id !== undefined) {
      console.log('🔄 API UPDATE: Updating category_id:', data.category_id);
      updates.push("category_id = ?");
      binds.push(data.category_id || null);
    }
    if (data.cost_center_id !== undefined) {
      console.log('🔄 API UPDATE: Updating cost_center_id:', data.cost_center_id);
      updates.push("cost_center_id = ?");
      binds.push(data.cost_center_id || null);
    }
    if (data.payee !== undefined) {
      console.log('🔄 API UPDATE: Updating payee:', data.payee);
      updates.push("payee = ?");
      binds.push(data.payee);
    }
    if (data.is_active !== undefined) {
      console.log('🔄 API UPDATE: Updating is_active:', data.is_active);
      updates.push("is_active = ?");
      binds.push(data.is_active ? 1 : 0);
    }
    if (data.status !== undefined) {
      console.log('🔄 API UPDATE: Updating status:', data.status);
      updates.push("status = ?");
      binds.push(data.status);
    }
    
    updates.push("updated_at = CURRENT_TIMESTAMP");
    binds.push(id, user.id);
    
    const query = `UPDATE fixed_accounts SET ${updates.join(", ")} WHERE id = ? AND user_id = ?`;
    console.log('🔄 API UPDATE: SQL Query:', query);
    console.log('🔄 API UPDATE: Bind parameters:', binds);
    
    const result = await c.env.DB.prepare(query).bind(...binds).run();
    
    console.log('🔄 API UPDATE: Database result:', result);
    
    if (result.success) {
      console.log('✅ API UPDATE: Fixed account updated successfully');
      
      // If status is being changed to PAGO, create a corresponding transaction
      if (data.status === 'PAGO' && currentFixedAccount.status !== 'PAGO') {
        console.log('🔄 API UPDATE: Creating transaction for PAGO status');
        const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
        
        // Use updated values if provided, otherwise use current values
        const finalDescription = data.description !== undefined ? data.description : currentFixedAccount.description;
        const finalAmount = data.amount !== undefined ? data.amount : currentFixedAccount.amount;
        const finalCategoryId = data.category_id !== undefined ? data.category_id : currentFixedAccount.category_id;
        const finalCostCenterId = data.cost_center_id !== undefined ? data.cost_center_id : currentFixedAccount.cost_center_id;
        
        await c.env.DB.prepare(`
          INSERT INTO transactions (date, description, amount, category_id, cost_center_id, is_recurring, status, user_id)
          VALUES (?, ?, ?, ?, ?, 0, ?, ?)
        `).bind(
          today,
          finalDescription,
          finalAmount,
          finalCategoryId || null,
          finalCostCenterId || null,
          'PAGO',
          user.id
        ).run();
      }
      
      return c.json({ success: true });
    } else {
      console.log('❌ API UPDATE: Database update failed:', result);
      return c.json({ error: "Failed to update fixed account", details: result }, 500);
    }
  } catch (error) {
    console.error('❌ API UPDATE: Error updating fixed account:', error);
    return c.json({ 
      error: "Internal server error", 
      details: error instanceof Error ? error.message : 'Unknown error' 
    }, 500);
  }
});

// Toggle fixed account status
app.patch("/api/fixed-accounts/:id/status", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "User not authenticated" }, 401);
  }
  
  const id = c.req.param("id");
  
  // First get current fixed account with all details
  const fixedAccount = await c.env.DB.prepare(
    "SELECT * FROM fixed_accounts WHERE id = ? AND user_id = ?"
  ).bind(id, user.id).first();
  
  if (!fixedAccount) {
    return c.json({ error: "Fixed account not found" }, 404);
  }
  
  // Toggle status
  const currentStatus = fixedAccount.status || 'NÃO PAGO';
  const newStatus = currentStatus === 'PAGO' ? 'NÃO PAGO' : 'PAGO';
  
  const result = await c.env.DB.prepare(
    "UPDATE fixed_accounts SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
  ).bind(newStatus, id, user.id).run();
  
  if (result.success) {
    // If changing to PAGO, create a corresponding transaction
    if (newStatus === 'PAGO') {
      const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
      
      await c.env.DB.prepare(`
        INSERT INTO transactions (date, description, amount, category_id, cost_center_id, is_recurring, status, user_id)
        VALUES (?, ?, ?, ?, ?, 0, ?, ?)
      `).bind(
        today,
        fixedAccount.description,
        fixedAccount.amount,
        fixedAccount.category_id,
        fixedAccount.cost_center_id,
        'PAGO',
        user.id
      ).run();
    }
    
    return c.json({ success: true, status: newStatus });
  } else {
    return c.json({ error: "Failed to update fixed account status" }, 500);
  }
});

// Update fixed account amount
app.patch("/api/fixed-accounts/:id/amount", customAuthMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  const amount = body.amount;
  
  if (amount === undefined || amount === null) {
    return c.json({ error: "Amount is required" }, 400);
  }
  
  if (isNaN(parseFloat(amount))) {
    return c.json({ error: "Invalid amount value" }, 400);
  }
  
  // Ensure amount is negative for fixed account expenses
  let finalAmount = parseFloat(amount);
  if (finalAmount > 0) {
    finalAmount = -finalAmount;
  }
  
  const user = c.get("user");
  const result = await c.env.DB.prepare(
    "UPDATE fixed_accounts SET amount = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
  ).bind(finalAmount, id, user!.id).run();
  
  if (result.success) {
    return c.json({ success: true, amount: parseFloat(amount) });
  } else {
    return c.json({ error: "Failed to update fixed account amount" }, 500);
  }
});

// Mark fixed account as paid (for bulk operations)
app.patch("/api/fixed-accounts/:id/bulk-pay", customAuthMiddleware, async (c) => {
  const id = c.req.param("id");
  
  const user = c.get("user");
  // First get the fixed account details
  const fixedAccount = await c.env.DB.prepare(
    "SELECT * FROM fixed_accounts WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).first();
  
  if (!fixedAccount) {
    return c.json({ error: "Fixed account not found" }, 404);
  }
  
  const result = await c.env.DB.prepare(
    "UPDATE fixed_accounts SET status = 'PAGO', updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).run();
  
  if (result.success) {
    // Create a corresponding transaction
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
    
    await c.env.DB.prepare(`
      INSERT INTO transactions (date, description, amount, category_id, cost_center_id, is_recurring, status, user_id)
      VALUES (?, ?, ?, ?, ?, 0, ?, ?)
    `).bind(
      today,
      fixedAccount.description,
      fixedAccount.amount,
      fixedAccount.category_id,
      fixedAccount.cost_center_id,
      'PAGO',
      user!.id
    ).run();
    
    return c.json({ success: true, status: 'PAGO' });
  } else {
    return c.json({ error: "Failed to mark fixed account as paid" }, 500);
  }
});

// Delete fixed account
app.delete("/api/fixed-accounts/:id", customAuthMiddleware, async (c) => {
  const id = c.req.param("id");
  
  const user = c.get("user");
  const result = await c.env.DB.prepare(
    "DELETE FROM fixed_accounts WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).run();
  
  if (result.success) {
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to delete fixed account" }, 500);
  }
});

// Clear all data endpoint (keeps all transaction data, only clears configuration data)
app.post("/api/clear-all-data", customAuthMiddleware, async (c) => {
  try {
    const user = c.get("user");
    
    // Delete only configuration data for the current user
    await c.env.DB.prepare("DELETE FROM categories WHERE user_id = ?").bind(user!.id).run();
    await c.env.DB.prepare("DELETE FROM cost_centers WHERE user_id = ?").bind(user!.id).run();
    await c.env.DB.prepare("DELETE FROM payroll_descriptions WHERE user_id = ?").bind(user!.id).run();
    
    return c.json({ success: true, message: "Configurações foram removidas (categorias, centros de custo e colaboradores)" });
  } catch (error) {
    return c.json({ success: false, error: "Erro ao limpar configurações" }, 500);
  }
});

// Clear complete data endpoint (for full system reset if needed)
app.post("/api/clear-complete-data", customAuthMiddleware, async (c) => {
  try {
    const user = c.get("user");
    
    // Delete all data for the current user in the correct order (due to potential foreign key references)
    await c.env.DB.prepare("DELETE FROM transactions WHERE user_id = ?").bind(user!.id).run();
    await c.env.DB.prepare("DELETE FROM fixed_accounts WHERE user_id = ?").bind(user!.id).run();
    await c.env.DB.prepare("DELETE FROM variable_accounts WHERE user_id = ?").bind(user!.id).run();
    await c.env.DB.prepare("DELETE FROM payroll WHERE user_id = ?").bind(user!.id).run();
    await c.env.DB.prepare("DELETE FROM accounts_receivable WHERE user_id = ?").bind(user!.id).run();
    await c.env.DB.prepare("DELETE FROM categories WHERE user_id = ?").bind(user!.id).run();
    await c.env.DB.prepare("DELETE FROM cost_centers WHERE user_id = ?").bind(user!.id).run();
    await c.env.DB.prepare("DELETE FROM payroll_descriptions WHERE user_id = ?").bind(user!.id).run();
    
    return c.json({ success: true, message: "Todos os dados foram removidos completamente" });
  } catch (error) {
    return c.json({ success: false, error: "Erro ao limpar todos os dados" }, 500);
  }
});

// Clear specific data endpoints
app.post("/api/clear-transactions", customAuthMiddleware, async (c) => {
  try {
    const user = c.get("user");
    await c.env.DB.prepare("DELETE FROM transactions WHERE user_id = ?").bind(user!.id).run();
    return c.json({ success: true, message: "Todas as transações foram removidas" });
  } catch (error) {
    return c.json({ success: false, error: "Erro ao limpar transações" }, 500);
  }
});

app.post("/api/clear-fixed-accounts", customAuthMiddleware, async (c) => {
  try {
    const user = c.get("user");
    await c.env.DB.prepare("DELETE FROM fixed_accounts WHERE user_id = ?").bind(user!.id).run();
    return c.json({ success: true, message: "Todas as contas fixas foram removidas" });
  } catch (error) {
    return c.json({ success: false, error: "Erro ao limpar contas fixas" }, 500);
  }
});

// Reset all fixed account payments from PAGO to NÃO PAGO
app.post("/api/fixed-accounts/reset-payments", customAuthMiddleware, async (c) => {
  try {
    const user = c.get("user");
    const result = await c.env.DB.prepare(`
      UPDATE fixed_accounts 
      SET status = 'NÃO PAGO', updated_at = CURRENT_TIMESTAMP 
      WHERE status = 'PAGO' AND user_id = ?
    `).bind(user!.id).run();
    
    const updatedCount = result.meta?.changes || 0;
    
    return c.json({ 
      success: true, 
      message: `Pagamentos zerados com sucesso`,
      updated: updatedCount
    });
  } catch (error) {
    console.error("Error resetting fixed account payments:", error);
    return c.json({ success: false, error: "Erro ao zerar pagamentos das contas fixas" }, 500);
  }
});

app.post("/api/clear-variable-accounts", customAuthMiddleware, async (c) => {
  try {
    const user = c.get("user");
    await c.env.DB.prepare("DELETE FROM variable_accounts WHERE user_id = ?").bind(user!.id).run();
    return c.json({ success: true, message: "Todas as contas não fixas foram removidas" });
  } catch (error) {
    return c.json({ success: false, error: "Erro ao limpar contas não fixas" }, 500);
  }
});

app.post("/api/clear-payroll", customAuthMiddleware, async (c) => {
  try {
    const user = c.get("user");
    await c.env.DB.prepare("DELETE FROM payroll WHERE user_id = ?").bind(user!.id).run();
    return c.json({ success: true, message: "Todos os itens da folha de pagamento foram removidos" });
  } catch (error) {
    return c.json({ success: false, error: "Erro ao limpar folha de pagamento" }, 500);
  }
});

app.post("/api/clear-accounts-receivable", customAuthMiddleware, async (c) => {
  try {
    const user = c.get("user");
    await c.env.DB.prepare("DELETE FROM accounts_receivable WHERE user_id = ?").bind(user!.id).run();
    return c.json({ success: true, message: "Todas as contas a receber foram removidas" });
  } catch (error) {
    return c.json({ success: false, error: "Erro ao limpar contas a receber" }, 500);
  }
});

// Import variable accounts from CSV/XLSX
app.post("/api/variable-accounts/import", customAuthMiddleware, async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ success: false, message: "Nenhum arquivo enviado", imported: 0, errors: [] });
    }

    console.log(`Importing variable accounts file: ${file.name}, size: ${file.size} bytes`);

    const arrayBuffer = await file.arrayBuffer();
    let data: any[] = [];

    // Enhanced error handling with detailed logging
    console.log(`File details: name=${file.name}, type=${file.type}, size=${file.size}`);

    // Check if it's an Excel file
    if (file.name.toLowerCase().endsWith('.xlsx') || file.name.toLowerCase().endsWith('.xls')) {
      try {
        // Parse Excel file
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // Convert to JSON with header detection
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { 
          header: 1,
          defval: '',
          raw: false
        }) as any[][];
        
        if (jsonData.length === 0) {
          return c.json({ success: false, message: "Arquivo Excel vazio", imported: 0, errors: [] });
        }

        // Convert array format to object format
        let startIndex = 0;
        const firstRow = jsonData[0] || [];
        
        // Check if first row looks like a header
        const hasHeader = firstRow.some((cell: any) => 
          String(cell).toLowerCase().includes('vencimento') || 
          String(cell).toLowerCase().includes('data') || 
          String(cell).toLowerCase().includes('descricao') ||
          String(cell).toLowerCase().includes('valor') ||
          String(cell).toLowerCase().includes('pagar')
        );
        
        if (hasHeader) {
          startIndex = 1;
        }

        // Convert rows to objects
        for (let i = startIndex; i < jsonData.length; i++) {
          const row = jsonData[i];
          if (row && row.length >= 5 && String(row[0]).trim() !== '') {
            let dateValue = String(row[0] || '').trim();
            console.log(`🔍 EXCEL Variable: Valor original: "${row[0]}" (tipo: ${typeof row[0]})`);
            
            // CONVERSÃO DIRETA DE NÚMERO SERIAL DO EXCEL
            if (!dateValue || dateValue === '') {
              console.log(`❌ EXCEL Variable: Célula vazia`);
              continue;
            }
            
            const numericValue = Number(dateValue);
            if (!isNaN(numericValue) && numericValue > 1 && numericValue < 100000) {
              try {
                console.log(`🔢 EXCEL Variable: Convertendo serial ${numericValue}`);
                
                // Usar a mesma lógica robusta das transações
                let excelDate: Date;
                
                if (numericValue <= 60) {
                  // Para datas até 29/02/1900 (que não existe), usar conversão direta
                  excelDate = new Date(1900, 0, numericValue); // Janeiro = 0
                } else {
                  // Para datas após 29/02/1900, subtrair 1 para compensar o bug do Excel
                  excelDate = new Date(1900, 0, numericValue - 1);
                }
                
                const year = excelDate.getFullYear();
                const month = excelDate.getMonth() + 1; // JavaScript meses são 0-11
                const day = excelDate.getDate();
                
                console.log(`📅 EXCEL Variable: Serial ${numericValue} → ${day}/${month}/${year}`);
                
                if (year >= 1900 && year <= 2100 && month >= 1 && month <= 12 && day >= 1 && day <= 31) {
                  dateValue = `${day.toString().padStart(2, '0')}/${month.toString().padStart(2, '0')}/${year}`;
                  console.log(`✅ EXCEL Variable: Conversão bem-sucedida: "${dateValue}"`);
                } else {
                  console.log(`❌ EXCEL Variable: Data inválida: ${day}/${month}/${year}`);
                  continue;
                }
              } catch (error) {
                console.log(`❌ EXCEL Variable: Erro na conversão: ${error}`);
                continue;
              }
            }
            // 2. Formato ISO YYYY-MM-DD 
            else if (dateValue.match(/^\d{4}-\d{1,2}-\d{1,2}$/)) {
              const [year, month, day] = dateValue.split('-');
              dateValue = `${day.padStart(2, '0')}/${month.padStart(2, '0')}/${year}`;
              console.log(`🔧 EXCEL Variable: ISO ${row[0]} → ${dateValue}`);
            }
            // 3. Formato com hífen DD-MM-YY ou DD-MM-YYYY (data abreviada pode gerar isso)
            else if (dateValue.match(/^\d{1,2}-\d{1,2}-\d{2,4}$/)) {
              const parts = dateValue.split('-');
              let day = parts[0].padStart(2, '0');
              let month = parts[1].padStart(2, '0');
              let year = parseInt(parts[2], 10);
              
              // Expandir ano de 2 dígitos se necessário
              if (year < 100) {
                year = year < 50 ? 2000 + year : 1900 + year;
              }
              
              dateValue = `${day}/${month}/${year}`;
              console.log(`🔧 EXCEL Variable: Formato com hífen DD-MM-YY/YYYY → DD/MM/YYYY: ${row[0]} → ${dateValue}`);
            }
            // 4. Formato com texto de mês abreviado em português (ex: "15-jul-25", "15 jul 25")
            else if (dateValue.match(/\d{1,2}[-\s](jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)[-\s]\d{2,4}/i)) {
              const monthsPt: { [key: string]: string } = {
                'jan': '01', 'fev': '02', 'mar': '03', 'abr': '04', 'mai': '05', 'jun': '06',
                'jul': '07', 'ago': '08', 'set': '09', 'out': '10', 'nov': '11', 'dez': '12'
              };
              
              const match = dateValue.match(/(\d{1,2})[-\s]([a-zA-Z]{3})[-\s](\d{2,4})/i);
              if (match) {
                const day = match[1].padStart(2, '0');
                const monthAbbr = match[2].toLowerCase();
                let year = parseInt(match[3], 10);
                
                // Expandir ano de 2 dígitos
                if (year < 100) {
                  year = year < 50 ? 2000 + year : 1900 + year;
                }
                
                const month = monthsPt[monthAbbr];
                if (month) {
                  dateValue = `${day}/${month}/${year}`;
                  console.log(`🔧 EXCEL Variable: Formato português com mês → DD/MM/YYYY: ${row[0]} → ${dateValue}`);
                }
              }
            }
            // 5. Formato com texto de mês em inglês (ex: "15-Jul-2025", "Jul 15, 2025")
            else if (dateValue.match(/\d{1,2}[-\s](Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[-\s]\d{2,4}/i)) {
              const monthsEn: { [key: string]: string } = {
                'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04', 'may': '05', 'jun': '06',
                'jul': '07', 'aug': '08', 'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12'
              };
              
              const match = dateValue.match(/(\d{1,2})[-\s]([A-Za-z]{3})[-\s](\d{2,4})/);
              if (match) {
                const day = match[1].padStart(2, '0');
                const monthAbbr = match[2].toLowerCase();
                let year = parseInt(match[3], 10);
                
                // Expandir ano de 2 dígitos
                if (year < 100) {
                  year = year < 50 ? 2000 + year : 1900 + year;
                }
                
                const month = monthsEn[monthAbbr];
                if (month) {
                  dateValue = `${day}/${month}/${year}`;
                  console.log(`🔧 EXCEL Variable: Formato inglês com mês → DD/MM/YYYY: ${row[0]} → ${dateValue}`);
                }
              }
            }
            // 6. Formatos especiais de Data Abreviada do Excel (ex: "15.07.25", "15.07.2025")
            else if (dateValue.match(/^\d{1,2}\.\d{1,2}\.\d{2,4}$/)) {
              const parts = dateValue.split('.');
              let day = parts[0].padStart(2, '0');
              let month = parts[1].padStart(2, '0');
              let year = parseInt(parts[2], 10);
              
              // Expandir ano de 2 dígitos se necessário
              if (year < 100) {
                year = year < 50 ? 2000 + year : 1900 + year;
              }
              
              dateValue = `${day}/${month}/${year}`;
              console.log(`🔧 EXCEL Variable: Formato com pontos DD.MM.YY/YYYY → DD/MM/YYYY: ${row[0]} → ${dateValue}`);
            }
            // 7. QUALQUER FORMATO COM BARRAS - SEMPRE BRASILEIRO DD/MM/YY ou DD/MM/YYYY
            else if (dateValue.match(/^\d{1,2}\/\d{1,2}\/\d{2,4}$/)) {
              const parts = dateValue.split('/');
              
              // INTERPRETAÇÃO BRASILEIRA FORÇADA - NUNCA AMERICANA
              const dayPart = parseInt(parts[0], 10);      // PRIMEIRA PARTE = SEMPRE DIA
              const monthPart = parseInt(parts[1], 10);    // SEGUNDA PARTE = SEMPRE MÊS
              let yearPart = parseInt(parts[2], 10);       // TERCEIRA PARTE = SEMPRE ANO
              
              console.log(`🇧🇷 FORMATO BRASILEIRO FORÇADO Variable: "${parts[0]}"="${dayPart}" (DIA), "${parts[1]}"="${monthPart}" (MÊS), "${parts[2]}"="${yearPart}" (ANO)`);
              
              // Expandir ano de 2 dígitos se necessário
              if (yearPart < 100) {
                yearPart = yearPart < 50 ? 2000 + yearPart : 1900 + yearPart;
                console.log(`📅 Variable: Ano expandido: ${parts[2]} → ${yearPart}`);
              }
              
              // Validação brasileira
              if (dayPart >= 1 && dayPart <= 31 && monthPart >= 1 && monthPart <= 12 && yearPart >= 1900 && yearPart <= 2100) {
                const testDate = new Date(yearPart, monthPart - 1, dayPart);
                if (testDate.getDate() === dayPart && testDate.getMonth() === monthPart - 1 && testDate.getFullYear() === yearPart) {
                  dateValue = `${dayPart.toString().padStart(2, '0')}/${monthPart.toString().padStart(2, '0')}/${yearPart}`;
                  console.log(`✅ EXCEL Variable: Formato brasileiro: ${row[0]} → ${dateValue}`);
                } else {
                  console.log(`❌ EXCEL Variable: Data não existe: ${dayPart}/${monthPart}/${yearPart}`);
                  continue;
                }
              } else {
                console.log(`❌ EXCEL Variable: Valores inválidos: dia=${dayPart}, mês=${monthPart}, ano=${yearPart}`);
                continue;
              }
            }
            
            data.push({
              vencimento: dateValue,
              descricao: String(row[1] || '').trim(),
              categoria: String(row[2] || '').trim(),
              centro_custo: String(row[3] || '').trim(),
              a_quem_pagar: String(row[4] || '').trim(),
              valor: String(row[5] || '').trim(),
              status: String(row[6] || '').trim()
            });
          }
        }
      } catch (error) {
        return c.json({ 
          success: false, 
          message: "Erro ao processar arquivo Excel", 
          imported: 0, 
          errors: [`Erro de formato Excel: ${error}`] 
        });
      }
    } else {
      // Handle CSV files
      const uint8Array = new Uint8Array(arrayBuffer);
      let text = '';
      
      // Check for BOM (Byte Order Mark) to detect UTF-8
      const hasBOM = uint8Array.length >= 3 && 
                     uint8Array[0] === 0xEF && 
                     uint8Array[1] === 0xBB && 
                     uint8Array[2] === 0xBF;
      
      if (hasBOM) {
        const utf8Decoder = new TextDecoder('utf-8');
        text = utf8Decoder.decode(arrayBuffer);
      } else {
        const encodings = ['utf-8', 'windows-1252', 'iso-8859-1', 'iso-8859-15'];
        
        for (const encoding of encodings) {
          try {
            const decoder = new TextDecoder(encoding);
            const decoded = decoder.decode(arrayBuffer);
            
            if (!decoded.includes('�') && !decoded.includes('\uFFFD')) {
              text = decoded;
              break;
            }
          } catch {
            continue;
          }
        }
        
        if (!text) {
          const decoder = new TextDecoder('utf-8');
          text = decoder.decode(arrayBuffer);
        }
      }
      
      const lines = text.split('\n').filter((line: string) => line.trim());
      
      if (lines.length < 1) {
        return c.json({ success: false, message: "Arquivo CSV vazio", imported: 0, errors: [] });
      }

      let startIndex = 0;

      // Check if first line looks like a header
      const firstLine = lines[0].toLowerCase();
      if (firstLine.includes('vencimento') || firstLine.includes('data') || firstLine.includes('descricao') || 
          firstLine.includes('valor') || firstLine.includes('pagar')) {
        startIndex = 1; // Skip header
      }

      // Process each data line
      for (let i = startIndex; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        // More robust CSV parsing - handle multiple separators
        let fields = [];
        let separator = ',';
        
        // Detect the most likely separator
        const commaCount = (line.match(/,/g) || []).length;
        const semicolonCount = (line.match(/;/g) || []).length;
        const tabCount = (line.match(/\t/g) || []).length;
        
        if (semicolonCount > commaCount && semicolonCount > tabCount) {
          separator = ';';
        } else if (tabCount > commaCount && tabCount > semicolonCount) {
          separator = '\t';
        }
        
        // Parse CSV with proper quote handling
        if (separator === ',') {
          const regex = /(?:^|,)("(?:[^"]+|"")*"|[^,]*)/g;
          let match;
          while ((match = regex.exec(line)) !== null) {
            let field = match[1];
            if (field.startsWith('"') && field.endsWith('"')) {
              field = field.slice(1, -1).replace(/""/g, '"');
            }
            fields.push(field.trim());
          }
        } else {
          fields = line.split(separator).map((f: string) => f.trim());
        }
        
        // Clean up fields
        fields = fields.map((field: string) => {
          if (!field) return '';
          
          if ((field.startsWith('"') && field.endsWith('"')) || 
              (field.startsWith("'") && field.endsWith("'"))) {
            field = field.slice(1, -1);
          }
          
          return field.trim();
        });

        console.log(`CSV row ${i}: fields = ${JSON.stringify(fields)}`);
        if (fields.length >= 5 && fields[0]) {
          data.push({
            vencimento: fields[0].trim(),
            descricao: fields[1].trim(),
            categoria: (fields[2] || '').trim(),
            centro_custo: (fields[3] || '').trim(),
            a_quem_pagar: fields[4].trim(),
            valor: (fields[5] || '').trim(),
            status: (fields[6] || '').trim()
          });
        } else {
          console.log(`Skipping CSV row ${i} - insufficient fields or empty first field`);
        }
      }
    }

    console.log(`Total variable account rows to process: ${data.length}`);

    // Get existing categories and cost centers for matching  
    const categoriesResult = await c.env.DB.prepare("SELECT * FROM categories WHERE user_id = ?").bind(user!.id).all();
    const costCentersResult = await c.env.DB.prepare("SELECT * FROM cost_centers WHERE user_id = ?").bind(user!.id).all();
    
    const categories = categoriesResult.results as any[];
    const costCenters = costCentersResult.results as any[];

    console.log(`Available categories: ${categories.length}, cost centers: ${costCenters.length}`);

    // Process the data
    let imported = 0;
    const errors: string[] = [];

    for (let i = 0; i < data.length; i++) {
      const item = data[i];
      
      try {
        // Parse fields: due_date, description, category, cost_center, payee, amount, status
        const dueDateStr = item.vencimento;
        const description = item.descricao;
        const categoryName = item.categoria || '';
        const costCenterName = item.centro_custo || '';
        const payee = item.a_quem_pagar;
        const amountStr = item.valor;
        const statusStr = item.status || '';

        // Parse due date - FORMATO BRASILEIRO DD/MM/YYYY
        let transactionDate = '';
        if (dueDateStr) {
          const cleanDateStr = dueDateStr.trim();
          console.log(`🔍 IMPORTAÇÃO Variable: Data original da planilha: "${cleanDateStr}"`);
          
          if (cleanDateStr.includes('/')) {
            const parts = cleanDateStr.split('/').map((p: string) => p.trim());
            if (parts.length === 3) {
              // FORMATO BRASILEIRO FORÇADO - SEMPRE DD/MM/YYYY
              // Parse dos valores
              const dayPart = parseInt(parts[0], 10);      // PRIMEIRA PARTE = SEMPRE DIA
              const monthPart = parseInt(parts[1], 10);    // SEGUNDA PARTE = SEMPRE MÊS
              let yearPart = parseInt(parts[2], 10);       // TERCEIRA PARTE = SEMPRE ANO
              
              console.log(`📊 PLANILHA Variable (BRASILEIRO): "${parts[0]}"="${dayPart}" (DIA), "${parts[1]}"="${monthPart}" (MÊS), "${parts[2]}"="${yearPart}" (ANO)`);
              
              // Validação de valores numéricos
              if (isNaN(dayPart) || isNaN(monthPart) || isNaN(yearPart)) {
                const errorMsg = `Valores não numéricos na data: "${cleanDateStr}"`;
                console.log(`❌ ${errorMsg}`);
                errors.push(`Linha ${i + 1}: ${errorMsg}`);
                continue;
              }
              
              // Expandir anos de 2 dígitos
              if (yearPart < 100) {
                yearPart = yearPart < 50 ? 2000 + yearPart : 1900 + yearPart;
                console.log(`📅 Variable: Ano expandido: ${parts[2]} → ${yearPart}`);
              }
              
              // ATRIBUIÇÃO FINAL BRASILEIRA
              const day = dayPart;      // Primeira parte é SEMPRE o dia
              const month = monthPart;  // Segunda parte é SEMPRE o mês
              const year = yearPart;    // Terceira parte é SEMPRE o ano
              
              console.log(`🇧🇷 FORMATO BRASILEIRO FINAL Variable: DIA=${day}, MÊS=${month}, ANO=${year}`);
              console.log(`📅 Data em português: ${day} de ${['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'][month-1]} de ${year}`);
              
              
              
              // Validação final dos valores
              if (day < 1 || day > 31) {
                const errorMsg = `Dia inválido: ${day} (deve estar entre 1 e 31)`;
                console.log(`❌ ${errorMsg}`);
                errors.push(`Linha ${i + 1}: ${errorMsg}`);
                continue;
              }
              
              if (month < 1 || month > 12) {
                const errorMsg = `Mês inválido: ${month} (deve estar entre 1 e 12)`;
                console.log(`❌ ${errorMsg}`);
                errors.push(`Linha ${i + 1}: ${errorMsg}`);
                continue;
              }
              
              if (year < 1900 || year > 2100) {
                const errorMsg = `Ano inválido: ${year} (deve estar entre 1900 e 2100)`;
                console.log(`❌ ${errorMsg}`);
                errors.push(`Linha ${i + 1}: ${errorMsg}`);
                continue;
              }
              
              // Validar se a data existe no calendário (ex: 31/02/2025 não existe)
              const daysInMonth = new Date(year, month, 0).getDate();
              
              if (day <= daysInMonth) {
                // Formato ISO para banco: YYYY-MM-DD (sem timezone issues)
                transactionDate = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
                console.log(`✅ SUCESSO Variable: "${cleanDateStr}" → "${transactionDate}"`);
                
              } else {
                const errorMsg = `Data não existe no calendário: ${day}/${month}/${year} (máximo ${daysInMonth} dias neste mês)`;
                console.log(`❌ ${errorMsg}`);
                errors.push(`Linha ${i + 1}: ${errorMsg}`);
                continue;
              }
            } else {
              console.log(`❌ Data deve ter 3 partes separadas por /: "${cleanDateStr}"`);
              errors.push(`Linha ${i + 1}: Formato de data inválido: ${cleanDateStr}. Use DD/MM/YYYY`);
              continue;
            }
          } else {
            console.log(`❌ Data deve conter barras "/": "${cleanDateStr}"`);
            errors.push(`Linha ${i + 1}: Formato de data inválido: ${cleanDateStr}. Use DD/MM/YYYY`);
            continue;
          }
        } else {
          errors.push(`Linha ${i + 1}: Data de vencimento é obrigatória`);
          continue;
        }

        // Validate description
        if (!description) {
          errors.push(`Linha ${i + 1}: Descrição é obrigatória`);
          continue;
        }

        // Validate payee
        if (!payee) {
          errors.push(`Linha ${i + 1}: A quem pagar é obrigatório`);
          continue;
        }

        // Parse amount
        let amount = 0;
        if (amountStr) {
          // Handle Brazilian number format (1.234,56) and international (1,234.56)
          let cleanAmount = amountStr.replace(/[^\d,.-]/g, ''); // Remove currency symbols
          
          // If it has both comma and dot, determine which is decimal separator
          if (cleanAmount.includes(',') && cleanAmount.includes('.')) {
            const lastCommaIndex = cleanAmount.lastIndexOf(',');
            const lastDotIndex = cleanAmount.lastIndexOf('.');
            
            if (lastCommaIndex > lastDotIndex) {
              // Brazilian format: 1.234,56
              cleanAmount = cleanAmount.replace(/\./g, '').replace(',', '.');
            } else {
              // International format: 1,234.56
              cleanAmount = cleanAmount.replace(/,/g, '');
            }
          } else if (cleanAmount.includes(',')) {
            // Check if comma is likely decimal separator (only if 2 digits after comma)
            const commaIndex = cleanAmount.lastIndexOf(',');
            const afterComma = cleanAmount.substring(commaIndex + 1);
            if (afterComma.length <= 2) {
              cleanAmount = cleanAmount.replace(',', '.');
            } else {
              cleanAmount = cleanAmount.replace(/,/g, '');
            }
          }
          
          amount = parseFloat(cleanAmount);
          if (isNaN(amount)) {
            errors.push(`Linha ${i + 1}: Valor inválido - ${amountStr}`);
            continue;
          }
        } else {
          errors.push(`Linha ${i + 1}: Valor é obrigatório`);
          continue;
        }

        // Find category by name (case-insensitive)
        let categoryId = null;
        if (categoryName) {
          const category = categories.find(c => 
            c.name.toLowerCase() === categoryName.toLowerCase()
          );
          if (category) {
            categoryId = category.id;
          }
        }

        // Find cost center by name (case-insensitive)
        let costCenterId = null;
        if (costCenterName) {
          const costCenter = costCenters.find(cc => 
            cc.name.toLowerCase() === costCenterName.toLowerCase()
          );
          if (costCenter) {
            costCenterId = costCenter.id;
          }
        }

        // Validate status
        let status = 'NÃO PAGO';
        if (statusStr) {
          const upperStatus = statusStr.toUpperCase().trim();
          if (upperStatus === 'PAGO' || upperStatus === 'NÃO PAGO') {
            status = upperStatus;
          }
        }

        console.log(`Processing variable account line ${i + 1}: due_date=${transactionDate}, desc=${description}, payee=${payee}, amount=${amount}, catId=${categoryId}, costId=${costCenterId}, status=${status}`);
        console.log(`🔧 IMPORT: Using user ID for variable account: ${user!.id}`);

        try {
          const result = await c.env.DB.prepare(`
            INSERT INTO variable_accounts (due_date, description, amount, category_id, cost_center_id, payee, status, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          `).bind(transactionDate, description, amount, categoryId, costCenterId, payee, status, user!.id).run();
          
          console.log(`🔧 IMPORT: Variable account insert result:`, result);

          if (result.success) {
            imported++;
            console.log(`Variable account line ${i + 1} imported successfully`);
          } else {
            console.log(`Variable account line ${i + 1} failed to import - DB result:`, result);
            errors.push(`Linha ${i + 1}: Erro ao inserir no banco de dados - ${result.error || 'erro desconhecido'}`);
          }
        } catch (dbError) {
          console.error(`Database error on line ${i + 1}:`, dbError);
          errors.push(`Linha ${i + 1}: Erro de banco de dados - ${dbError instanceof Error ? dbError.message : 'erro desconhecido'}`);
        }
      } catch (error) {
        errors.push(`Linha ${i + 1}: Erro ao processar dados - ${error}`);
      }
    }

    // Add final debugging info
    console.log(`🔧 IMPORT FINAL: Variable accounts import completed. Imported: ${imported}, Errors: ${errors.length}`);
    console.log(`🔧 IMPORT FINAL: User ID used for imports: ${user!.id}`);
    
    return c.json({
      success: imported > 0,
      message: imported > 0 ? `${imported} conta(s) não fixa(s) importada(s)` : "Nenhuma conta não fixa foi importada",
      imported,
      errors,
      debug: {
        userId: user!.id,
        totalProcessed: data.length,
        imported: imported
      }
    });
    
  } catch (error) {
    return c.json({ 
      success: false, 
      message: "Erro interno do servidor", 
      imported: 0, 
      errors: ["Erro ao processar arquivo"] 
    });
  }
});

// Variable Accounts endpoints

// Get all variable accounts with details
app.get("/api/variable-accounts", customAuthMiddleware, async (c) => {
  try {
    console.log("🔄 API: Fetching variable accounts...");
    
    const user = c.get("user");
    if (!user) {
      console.log('❌ API: No user found in variable accounts get');
      return c.json({ error: "User not authenticated" }, 401);
    }
    
    console.log('👤 API: Fetching variable accounts for user:', user.id);
    
    // First check what data exists in the database
    const allVariableAccounts = await c.env.DB.prepare("SELECT * FROM variable_accounts").all();
    console.log('🔍 DEBUG Variable: All variable accounts in database:', allVariableAccounts.results?.length || 0);
    
    const userVariableAccounts = await c.env.DB.prepare("SELECT * FROM variable_accounts WHERE user_id = ?").bind(user.id).all();
    console.log('🔍 DEBUG Variable: Variable accounts for current user:', userVariableAccounts.results?.length || 0);
    console.log('🔍 DEBUG Variable: Current user ID:', user.id);
    console.log('🔍 DEBUG Variable: Sample user IDs in DB:', allVariableAccounts.results?.slice(0, 5).map((va: any) => ({ id: va.id, user_id: va.user_id, description: va.description })));
    
    // Check if there are any variable accounts with null or empty user_id
    const orphanedVariableAccounts = await c.env.DB.prepare("SELECT * FROM variable_accounts WHERE user_id IS NULL OR user_id = ''").all();
    console.log('🔍 DEBUG Variable: Orphaned variable accounts (no user_id):', orphanedVariableAccounts.results?.length || 0);
    
    const variableAccounts = await c.env.DB.prepare(`
      SELECT 
        va.*,
        c.name as category_name,
        cc.name as cost_center_name
      FROM variable_accounts va
      LEFT JOIN categories c ON va.category_id = c.id AND c.user_id = ?
      LEFT JOIN cost_centers cc ON va.cost_center_id = cc.id AND cc.user_id = ?
      WHERE va.user_id = ?
      ORDER BY va.due_date ASC, va.id DESC
    `).bind(user.id, user.id, user.id).all();
    
    console.log("✅ API Variable Accounts: Found", variableAccounts.results?.length || 0, "variable accounts for user", user.id);
    
    return c.json(variableAccounts.results || []);
  } catch (error) {
    console.error("❌ API Variable Accounts Error:", error);
    return c.json({ error: "Failed to fetch variable accounts" }, 500);
  }
});

// Create new variable account
app.post("/api/variable-accounts", customAuthMiddleware, async (c) => {
  try {
    const user = c.get("user");
    const data = await c.req.json();
    
    // Check if it's an installment
    if (data.is_installment && data.installment_count && parseInt(data.installment_count) > 1) {
      const installmentCount = parseInt(data.installment_count);
      const installmentAmount = parseFloat(data.amount) / installmentCount;
      const baseDate = new Date(data.due_date + 'T00:00:00');
      
      // Calculate interval in days
      let intervalDays = 30; // default monthly
      switch (data.installment_interval) {
        case 'weekly': intervalDays = 7; break;
        case 'biweekly': intervalDays = 15; break;  
        case 'monthly': intervalDays = 30; break;
        case 'bimonthly': intervalDays = 60; break;
        case 'quarterly': intervalDays = 90; break;
      }
      
      const createdIds = [];
      
      // Create each installment
      for (let i = 0; i < installmentCount; i++) {
        const installmentDate = new Date(baseDate);
        installmentDate.setDate(baseDate.getDate() + (i * intervalDays));
        
        const installmentDescription = `${data.description} (${i + 1}/${installmentCount})`;
        const formattedDate = installmentDate.toISOString().split('T')[0]; // YYYY-MM-DD format
        
        // Ensure installment amount is negative for variable account expenses
        let finalInstallmentAmount = installmentAmount;
        if (finalInstallmentAmount > 0) {
          finalInstallmentAmount = -finalInstallmentAmount;
        }
        
        const result = await c.env.DB.prepare(`
          INSERT INTO variable_accounts (due_date, description, amount, category_id, cost_center_id, payee, status, user_id)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
          formattedDate,
          installmentDescription,
          finalInstallmentAmount,
          data.category_id || null,
          data.cost_center_id || null,
          data.payee,
          data.status || 'NÃO PAGO',
          user!.id
        ).run();
        
        if (result.success) {
          createdIds.push(result.meta.last_row_id);
        } else {
          // If any installment fails, we should probably rollback, but for simplicity we'll continue
          console.error(`Failed to create installment ${i + 1}`);
        }
      }
      
      return c.json({ 
        success: true, 
        message: `${installmentCount} parcelas criadas com sucesso`,
        installments_created: createdIds.length,
        ids: createdIds 
      });
      
    } else {
      // Single account creation (existing logic)
      // Ensure amount is negative for variable account expenses
      let amount = parseFloat(data.amount);
      if (amount > 0) {
        amount = -amount;
      }
      
      const result = await c.env.DB.prepare(`
        INSERT INTO variable_accounts (due_date, description, amount, category_id, cost_center_id, payee, status, user_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        data.due_date,
        data.description,
        amount,
        data.category_id || null,
        data.cost_center_id || null,
        data.payee,
        data.status || 'NÃO PAGO',
        user!.id
      ).run();
      
      if (result.success) {
        return c.json({ success: true, id: result.meta.last_row_id });
      } else {
        return c.json({ error: "Failed to create variable account" }, 500);
      }
    }
  } catch (error) {
    console.error("Error creating variable account:", error);
    return c.json({ error: "Failed to create variable account" }, 500);
  }
});

// Update variable account
app.put("/api/variable-accounts/:id", customAuthMiddleware, zValidator("json", UpdateVariableAccountSchema), async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  const data = c.req.valid("json");
  
  // Get current variable account to check status change
  const currentVariableAccount = await c.env.DB.prepare(
    "SELECT * FROM variable_accounts WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).first();
  
  if (!currentVariableAccount) {
    return c.json({ error: "Variable account not found" }, 404);
  }
  
  const updates: string[] = [];
  const binds: any[] = [];
  
  if (data.due_date !== undefined) {
    updates.push("due_date = ?");
    binds.push(data.due_date);
  }
  if (data.description !== undefined) {
    updates.push("description = ?");
    binds.push(data.description);
  }
  if (data.amount !== undefined) {
    // Ensure amount is negative for variable account expenses
    let amount = data.amount;
    if (amount > 0) {
      amount = -amount;
    }
    updates.push("amount = ?");
    binds.push(amount);
  }
  if (data.category_id !== undefined) {
    updates.push("category_id = ?");
    binds.push(data.category_id || null);
  }
  if (data.cost_center_id !== undefined) {
    updates.push("cost_center_id = ?");
    binds.push(data.cost_center_id || null);
  }
  if (data.payee !== undefined) {
    updates.push("payee = ?");
    binds.push(data.payee);
  }
  if (data.status !== undefined) {
    updates.push("status = ?");
    binds.push(data.status);
  }
  
  updates.push("updated_at = CURRENT_TIMESTAMP");
  binds.push(id, user!.id);
  
  const result = await c.env.DB.prepare(`
    UPDATE variable_accounts SET ${updates.join(", ")} WHERE id = ? AND user_id = ?
  `).bind(...binds).run();
  
  if (result.success) {
    // If status is being changed to PAGO, create a corresponding transaction
    if (data.status === 'PAGO' && currentVariableAccount.status !== 'PAGO') {
      const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
      
      // Use updated values if provided, otherwise use current values
      const finalDescription = data.description !== undefined ? data.description : currentVariableAccount.description;
      const finalAmount = data.amount !== undefined ? data.amount : currentVariableAccount.amount;
      const finalCategoryId = data.category_id !== undefined ? data.category_id : currentVariableAccount.category_id;
      const finalCostCenterId = data.cost_center_id !== undefined ? data.cost_center_id : currentVariableAccount.cost_center_id;
      
      await c.env.DB.prepare(`
        INSERT INTO transactions (date, description, amount, category_id, cost_center_id, is_recurring, status)
        VALUES (?, ?, ?, ?, ?, 0, ?)
      `).bind(
        today,
        finalDescription,
        finalAmount,
        finalCategoryId || null,
        finalCostCenterId || null,
        'PAGO'
      ).run();
    }
    
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to update variable account" }, 500);
  }
});

// Toggle variable account status
app.patch("/api/variable-accounts/:id/status", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  
  // First get current variable account with all details
  const variableAccount = await c.env.DB.prepare(
    "SELECT * FROM variable_accounts WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).first();
  
  if (!variableAccount) {
    return c.json({ error: "Variable account not found" }, 404);
  }
  
  // Toggle status
  const currentStatus = variableAccount.status || 'NÃO PAGO';
  const newStatus = currentStatus === 'PAGO' ? 'NÃO PAGO' : 'PAGO';
  
  const result = await c.env.DB.prepare(
    "UPDATE variable_accounts SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
  ).bind(newStatus, id, user!.id).run();
  
  if (result.success) {
    // If changing to PAGO, create a corresponding transaction
    if (newStatus === 'PAGO') {
      const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
      
      await c.env.DB.prepare(`
        INSERT INTO transactions (date, description, amount, category_id, cost_center_id, is_recurring, status, user_id)
        VALUES (?, ?, ?, ?, ?, 0, ?, ?)
      `).bind(
        today,
        variableAccount.description,
        variableAccount.amount,
        variableAccount.category_id,
        variableAccount.cost_center_id,
        'PAGO',
        user!.id
      ).run();
    }
    
    return c.json({ success: true, status: newStatus });
  } else {
    return c.json({ error: "Failed to update variable account status" }, 500);
  }
});

// Update variable account amount
app.patch("/api/variable-accounts/:id/amount", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  const body = await c.req.json();
  const amount = body.amount;
  
  if (amount === undefined || amount === null) {
    return c.json({ error: "Amount is required" }, 400);
  }
  
  if (isNaN(parseFloat(amount))) {
    return c.json({ error: "Invalid amount value" }, 400);
  }
  
  // Ensure amount is negative for variable account expenses
  let finalAmount = parseFloat(amount);
  if (finalAmount > 0) {
    finalAmount = -finalAmount;
  }
  
  const result = await c.env.DB.prepare(
    "UPDATE variable_accounts SET amount = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
  ).bind(finalAmount, id, user!.id).run();
  
  if (result.success) {
    return c.json({ success: true, amount: parseFloat(amount) });
  } else {
    return c.json({ error: "Failed to update variable account amount" }, 500);
  }
});

// Update variable account due date
app.patch("/api/variable-accounts/:id/due-date", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  const body = await c.req.json();
  const dueDate = body.due_date;
  
  if (!dueDate) {
    return c.json({ error: "Due date is required" }, 400);
  }
  
  // Validate date format (YYYY-MM-DD)
  const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateRegex.test(dueDate)) {
    return c.json({ error: "Invalid date format. Use YYYY-MM-DD" }, 400);
  }
  
  // Validate that it's a valid date
  const parsedDate = new Date(dueDate + 'T00:00:00');
  if (isNaN(parsedDate.getTime())) {
    return c.json({ error: "Invalid date" }, 400);
  }
  
  const result = await c.env.DB.prepare(
    "UPDATE variable_accounts SET due_date = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
  ).bind(dueDate, id, user!.id).run();
  
  if (result.success) {
    return c.json({ success: true, due_date: dueDate });
  } else {
    return c.json({ error: "Failed to update variable account due date" }, 500);
  }
});

// Mark variable account as paid (for bulk operations)
app.patch("/api/variable-accounts/:id/bulk-pay", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  
  // First get the variable account details
  const variableAccount = await c.env.DB.prepare(
    "SELECT * FROM variable_accounts WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).first();
  
  if (!variableAccount) {
    return c.json({ error: "Variable account not found" }, 404);
  }
  
  const result = await c.env.DB.prepare(
    "UPDATE variable_accounts SET status = 'PAGO', updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).run();
  
  if (result.success) {
    // Create a corresponding transaction
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
    
    await c.env.DB.prepare(`
      INSERT INTO transactions (date, description, amount, category_id, cost_center_id, is_recurring, status, user_id)
      VALUES (?, ?, ?, ?, ?, 0, ?, ?)
    `).bind(
      today,
      variableAccount.description,
      variableAccount.amount,
      variableAccount.category_id,
      variableAccount.cost_center_id,
      'PAGO',
      user!.id
    ).run();
    
    return c.json({ success: true, status: 'PAGO' });
  } else {
    return c.json({ error: "Failed to mark variable account as paid" }, 500);
  }
});

// Delete variable account
app.delete("/api/variable-accounts/:id", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  
  const result = await c.env.DB.prepare(
    "DELETE FROM variable_accounts WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).run();
  
  if (result.success) {
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to delete variable account" }, 500);
  }
});

// Import payroll from CSV/XLSX
app.post("/api/payroll/import", customAuthMiddleware, async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ success: false, message: "Nenhum arquivo enviado", imported: 0, errors: [] });
    }

    console.log(`Importing payroll file: ${file.name}, size: ${file.size} bytes`);

    const arrayBuffer = await file.arrayBuffer();
    let data: any[] = [];

    // Check if it's an Excel file
    if (file.name.toLowerCase().endsWith('.xlsx') || file.name.toLowerCase().endsWith('.xls')) {
      try {
        // Parse Excel file
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // Convert to JSON with header detection
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { 
          header: 1,
          defval: '',
          raw: false
        }) as any[][];
        
        if (jsonData.length === 0) {
          return c.json({ success: false, message: "Arquivo Excel vazio", imported: 0, errors: [] });
        }

        // Convert array format to object format
        let startIndex = 0;
        const firstRow = jsonData[0] || [];
        
        // Check if first row looks like a header
        const hasHeader = firstRow.some((cell: any) => 
          String(cell).toLowerCase().includes('descricao') ||
          String(cell).toLowerCase().includes('categoria') ||
          String(cell).toLowerCase().includes('centro') ||
          String(cell).toLowerCase().includes('valor') ||
          String(cell).toLowerCase().includes('status')
        );
        
        if (hasHeader) {
          startIndex = 1;
        }

        // Convert rows to objects
        for (let i = startIndex; i < jsonData.length; i++) {
          const row = jsonData[i];
          if (row && row.length >= 4 && String(row[0]).trim() !== '') {
            data.push({
              descricao: String(row[0] || '').trim(),
              categoria: String(row[1] || '').trim(),
              centro_custo: String(row[2] || '').trim(),
              valor: String(row[3] || '').trim(),
              status: String(row[4] || '').trim()
            });
          }
        }
      } catch (error) {
        return c.json({ 
          success: false, 
          message: "Erro ao processar arquivo Excel", 
          imported: 0, 
          errors: [`Erro de formato Excel: ${error}`] 
        });
      }
    } else {
      // Handle CSV files
      const uint8Array = new Uint8Array(arrayBuffer);
      let text = '';
      
      // Check for BOM (Byte Order Mark) to detect UTF-8
      const hasBOM = uint8Array.length >= 3 && 
                     uint8Array[0] === 0xEF && 
                     uint8Array[1] === 0xBB && 
                     uint8Array[2] === 0xBF;
      
      if (hasBOM) {
        const utf8Decoder = new TextDecoder('utf-8');
        text = utf8Decoder.decode(arrayBuffer);
      } else {
        const encodings = ['utf-8', 'windows-1252', 'iso-8859-1', 'iso-8859-15'];
        
        for (const encoding of encodings) {
          try {
            const decoder = new TextDecoder(encoding);
            const decoded = decoder.decode(arrayBuffer);
            
            if (!decoded.includes('�') && !decoded.includes('\uFFFD')) {
              text = decoded;
              break;
            }
          } catch {
            continue;
          }
        }
        
        if (!text) {
          const decoder = new TextDecoder('utf-8');
          text = decoder.decode(arrayBuffer);
        }
      }
      
      const lines = text.split('\n').filter((line: string) => line.trim());
      
      if (lines.length < 1) {
        return c.json({ success: false, message: "Arquivo CSV vazio", imported: 0, errors: [] });
      }

      let startIndex = 0;

      // Check if first line looks like a header
      const firstLine = lines[0].toLowerCase();
      if (firstLine.includes('descricao') || firstLine.includes('categoria') || 
          firstLine.includes('centro') || firstLine.includes('valor') || firstLine.includes('status')) {
        startIndex = 1; // Skip header
      }

      // Process each data line
      for (let i = startIndex; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        // More robust CSV parsing - handle multiple separators
        let fields = [];
        let separator = ',';
        
        // Detect the most likely separator
        const commaCount = (line.match(/,/g) || []).length;
        const semicolonCount = (line.match(/;/g) || []).length;
        const tabCount = (line.match(/\t/g) || []).length;
        
        if (semicolonCount > commaCount && semicolonCount > tabCount) {
          separator = ';';
        } else if (tabCount > commaCount && tabCount > semicolonCount) {
          separator = '\t';
        }
        
        // Parse CSV with proper quote handling
        if (separator === ',') {
          const regex = /(?:^|,)("(?:[^"]+|"")*"|[^,]*)/g;
          let match;
          while ((match = regex.exec(line)) !== null) {
            let field = match[1];
            if (field.startsWith('"') && field.endsWith('"')) {
              field = field.slice(1, -1).replace(/""/g, '"');
            }
            fields.push(field.trim());
          }
        } else {
          fields = line.split(separator).map((f: string) => f.trim());
        }
        
        // Clean up fields
        fields = fields.map((field: string) => {
          if (!field) return '';
          
          if ((field.startsWith('"') && field.endsWith('"')) || 
              (field.startsWith("'") && field.endsWith("'"))) {
            field = field.slice(1, -1);
          }
          
          return field.trim();
        });

        if (fields.length >= 4 && fields[0]) {
          data.push({
            descricao: fields[0].trim(),
            categoria: (fields[1] || '').trim(),
            centro_custo: (fields[2] || '').trim(),
            valor: fields[3].trim(),
            status: (fields[4] || '').trim()
          });
        }
      }
    }

    console.log(`Total payroll rows to process: ${data.length}`);

    // Get existing categories and cost centers for matching
    const user = c.get("user");
    const categoriesResult = await c.env.DB.prepare("SELECT * FROM categories WHERE user_id = ?").bind(user!.id).all();
    const costCentersResult = await c.env.DB.prepare("SELECT * FROM cost_centers WHERE user_id = ?").bind(user!.id).all();
    
    const categories = categoriesResult.results as any[];
    const costCenters = costCentersResult.results as any[];

    console.log(`Available categories: ${categories.length}, cost centers: ${costCenters.length}`);

    // Process the data
    let imported = 0;
    const errors: string[] = [];

    for (let i = 0; i < data.length; i++) {
      const item = data[i];
      
      try {
        // Parse fields: description, category, cost_center, amount, status
        const description = item.descricao;
        const categoryName = item.categoria || '';
        const costCenterName = item.centro_custo || '';
        const amountStr = item.valor;
        const statusStr = item.status || '';

        // Validate description
        if (!description) {
          errors.push(`Linha ${i + 1}: Descrição é obrigatória`);
          continue;
        }

        // Parse amount
        let amount = 0;
        if (amountStr) {
          // Handle Brazilian number format (1.234,56) and international (1,234.56)
          let cleanAmount = amountStr.replace(/[^\d,.-]/g, ''); // Remove currency symbols
          
          // If it has both comma and dot, determine which is decimal separator
          if (cleanAmount.includes(',') && cleanAmount.includes('.')) {
            const lastCommaIndex = cleanAmount.lastIndexOf(',');
            const lastDotIndex = cleanAmount.lastIndexOf('.');
            
            if (lastCommaIndex > lastDotIndex) {
              // Brazilian format: 1.234,56
              cleanAmount = cleanAmount.replace(/\./g, '').replace(',', '.');
            } else {
              // International format: 1,234.56
              cleanAmount = cleanAmount.replace(/,/g, '');
            }
          } else if (cleanAmount.includes(',')) {
            // Check if comma is likely decimal separator (only if 2 digits after comma)
            const commaIndex = cleanAmount.lastIndexOf(',');
            const afterComma = cleanAmount.substring(commaIndex + 1);
            if (afterComma.length <= 2) {
              cleanAmount = cleanAmount.replace(',', '.');
            } else {
              cleanAmount = cleanAmount.replace(/,/g, '');
            }
          }
          
          amount = parseFloat(cleanAmount);
          if (isNaN(amount)) {
            errors.push(`Linha ${i + 1}: Valor inválido - ${amountStr}`);
            continue;
          }
        } else {
          errors.push(`Linha ${i + 1}: Valor é obrigatório`);
          continue;
        }

        // Find category by name (case-insensitive)
        let categoryId = null;
        if (categoryName) {
          const category = categories.find(c => 
            c.name.toLowerCase() === categoryName.toLowerCase()
          );
          if (category) {
            categoryId = category.id;
          }
        }

        // Find cost center by name (case-insensitive)
        let costCenterId = null;
        if (costCenterName) {
          const costCenter = costCenters.find(cc => 
            cc.name.toLowerCase() === costCenterName.toLowerCase()
          );
          if (costCenter) {
            costCenterId = costCenter.id;
          }
        }

        // Validate status
        let status = 'NÃO PAGO';
        if (statusStr) {
          const upperStatus = statusStr.toUpperCase().trim();
          if (upperStatus === 'PAGO' || upperStatus === 'NÃO PAGO') {
            status = upperStatus;
          }
        }

        console.log(`Processing payroll line ${i + 1}: desc=${description}, amount=${amount}, catId=${categoryId}, costId=${costCenterId}, status=${status}`);

        console.log(`🔄 PAYROLL IMPORT: Processing line ${i + 1} with user_id: ${user!.id}`);
        const result = await c.env.DB.prepare(`
          INSERT INTO payroll (description, amount, category_id, cost_center_id, status, user_id)
          VALUES (?, ?, ?, ?, ?, ?)
        `).bind(description, amount, categoryId, costCenterId, status, user!.id).run();

        if (result.success) {
          imported++;
          console.log(`Payroll line ${i + 1} imported successfully`);
        } else {
          console.log(`Payroll line ${i + 1} failed to import`);
          errors.push(`Linha ${i + 1}: Erro ao inserir no banco de dados`);
        }
      } catch (error) {
        errors.push(`Linha ${i + 1}: Erro ao processar dados - ${error}`);
      }
    }

    return c.json({
      success: imported > 0,
      message: imported > 0 ? `${imported} item(ns) da folha de pagamento importado(s)` : "Nenhum item da folha de pagamento foi importado",
      imported,
      errors
    });
    
  } catch (error) {
    return c.json({ 
      success: false, 
      message: "Erro interno do servidor", 
      imported: 0, 
      errors: ["Erro ao processar arquivo"] 
    });
  }
});

// Payroll endpoints

// Get all payroll items with details
app.get("/api/payroll", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  
  const payrollItems = await c.env.DB.prepare(`
    SELECT 
      p.*,
      c.name as category_name,
      cc.name as cost_center_name
    FROM payroll p
    LEFT JOIN categories c ON p.category_id = c.id AND c.user_id = ?
    LEFT JOIN cost_centers cc ON p.cost_center_id = cc.id AND cc.user_id = ?
    WHERE p.user_id = ?
    ORDER BY p.id DESC
  `).bind(user!.id, user!.id, user!.id).all();
  
  return c.json(payrollItems.results);
});

// Create new payroll item
app.post("/api/payroll", customAuthMiddleware, zValidator("json", CreatePayrollSchema), async (c) => {
  const user = c.get("user");
  const data = c.req.valid("json");
  
  // Ensure amount is negative for payroll expenses
  let amount = data.amount;
  if (amount > 0) {
    amount = -amount;
  }
  
  const result = await c.env.DB.prepare(`
    INSERT INTO payroll (description, amount, category_id, cost_center_id, status, user_id)
    VALUES (?, ?, ?, ?, ?, ?)
  `).bind(
    data.description,
    amount,
    data.category_id || null,
    data.cost_center_id || null,
    data.status || 'NÃO PAGO',
    user!.id
  ).run();
  
  if (result.success) {
    return c.json({ success: true, id: result.meta.last_row_id });
  } else {
    return c.json({ error: "Failed to create payroll item" }, 500);
  }
});

// Update payroll item
app.put("/api/payroll/:id", customAuthMiddleware, zValidator("json", UpdatePayrollSchema), async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  const data = c.req.valid("json");
  
  // Get current payroll item to check status change
  const currentPayrollItem = await c.env.DB.prepare(
    "SELECT * FROM payroll WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).first();
  
  if (!currentPayrollItem) {
    return c.json({ error: "Payroll item not found" }, 404);
  }
  
  const updates: string[] = [];
  const binds: any[] = [];
  
  if (data.description !== undefined) {
    updates.push("description = ?");
    binds.push(data.description);
  }
  if (data.amount !== undefined) {
    updates.push("amount = ?");
    binds.push(data.amount);
  }
  if (data.category_id !== undefined) {
    updates.push("category_id = ?");
    binds.push(data.category_id || null);
  }
  if (data.cost_center_id !== undefined) {
    updates.push("cost_center_id = ?");
    binds.push(data.cost_center_id || null);
  }
  if (data.status !== undefined) {
    updates.push("status = ?");
    binds.push(data.status);
  }
  
  updates.push("updated_at = CURRENT_TIMESTAMP");
  binds.push(id, user!.id);
  
  const result = await c.env.DB.prepare(`
    UPDATE payroll SET ${updates.join(", ")} WHERE id = ? AND user_id = ?
  `).bind(...binds).run();
  
  if (result.success) {
    // If status is being changed to PAGO, create a corresponding transaction
    if (data.status === 'PAGO' && currentPayrollItem.status !== 'PAGO') {
      const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
      
      // Use updated values if provided, otherwise use current values
      const finalDescription = data.description !== undefined ? data.description : currentPayrollItem.description;
      const finalAmount = data.amount !== undefined ? data.amount : currentPayrollItem.amount;
      const finalCategoryId = data.category_id !== undefined ? data.category_id : currentPayrollItem.category_id;
      const finalCostCenterId = data.cost_center_id !== undefined ? data.cost_center_id : currentPayrollItem.cost_center_id;
      
      await c.env.DB.prepare(`
        INSERT INTO transactions (date, description, amount, category_id, cost_center_id, is_recurring, status, user_id)
        VALUES (?, ?, ?, ?, ?, 0, ?, ?)
      `).bind(
        today,
        finalDescription, // Colaborador -> Descrição
        finalAmount,
        finalCategoryId || null,
        finalCostCenterId || null,
        'PAGO',
        user!.id
      ).run();
    }
    
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to update payroll item" }, 500);
  }
});

// Toggle payroll item status
app.patch("/api/payroll/:id/status", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  
  // First get current payroll item with all details
  const payrollItem = await c.env.DB.prepare(
    "SELECT * FROM payroll WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).first();
  
  if (!payrollItem) {
    return c.json({ error: "Payroll item not found" }, 404);
  }
  
  // Toggle status
  const currentStatus = payrollItem.status || 'NÃO PAGO';
  const newStatus = currentStatus === 'PAGO' ? 'NÃO PAGO' : 'PAGO';
  
  const result = await c.env.DB.prepare(
    "UPDATE payroll SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
  ).bind(newStatus, id, user!.id).run();
  
  if (result.success) {
    // If changing to PAGO, create a corresponding transaction
    if (newStatus === 'PAGO') {
      const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
      
      await c.env.DB.prepare(`
        INSERT INTO transactions (date, description, amount, category_id, cost_center_id, is_recurring, status, user_id)
        VALUES (?, ?, ?, ?, ?, 0, ?, ?)
      `).bind(
        today,
        payrollItem.description, // Colaborador -> Descrição
        payrollItem.amount,
        payrollItem.category_id,
        payrollItem.cost_center_id,
        'PAGO',
        user!.id
      ).run();
    }
    
    return c.json({ success: true, status: newStatus });
  } else {
    return c.json({ error: "Failed to update payroll item status" }, 500);
  }
});

// Mark payroll item as paid (for bulk operations)
app.patch("/api/payroll/:id/bulk-pay", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  
  // First get the payroll item details
  const payrollItem = await c.env.DB.prepare(
    "SELECT * FROM payroll WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).first();
  
  if (!payrollItem) {
    return c.json({ error: "Payroll item not found" }, 404);
  }
  
  const result = await c.env.DB.prepare(
    "UPDATE payroll SET status = 'PAGO', updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).run();
  
  if (result.success) {
    // Create a corresponding transaction
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
    
    await c.env.DB.prepare(`
      INSERT INTO transactions (date, description, amount, category_id, cost_center_id, is_recurring, status, user_id)
      VALUES (?, ?, ?, ?, ?, 0, ?, ?)
    `).bind(
      today,
      payrollItem.description, // Colaborador -> Descrição
      payrollItem.amount,
      payrollItem.category_id,
      payrollItem.cost_center_id,
      'PAGO',
      user!.id
    ).run();
    
    return c.json({ success: true, status: 'PAGO' });
  } else {
    return c.json({ error: "Failed to mark payroll item as paid" }, 500);
  }
});

// Update payroll item amount
app.patch("/api/payroll/:id/amount", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  const body = await c.req.json();
  const amount = body.amount;
  
  if (amount === undefined || amount === null) {
    return c.json({ error: "Amount is required" }, 400);
  }
  
  if (isNaN(parseFloat(amount))) {
    return c.json({ error: "Invalid amount value" }, 400);
  }
  
  // Ensure amount is negative for payroll expenses
  let finalAmount = parseFloat(amount);
  if (finalAmount > 0) {
    finalAmount = -finalAmount;
  }
  
  const result = await c.env.DB.prepare(
    "UPDATE payroll SET amount = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
  ).bind(finalAmount, id, user!.id).run();
  
  if (result.success) {
    return c.json({ success: true, amount: parseFloat(amount) });
  } else {
    return c.json({ error: "Failed to update payroll item amount" }, 500);
  }
});

// Delete payroll item
app.delete("/api/payroll/:id", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  
  const result = await c.env.DB.prepare(
    "DELETE FROM payroll WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).run();
  
  if (result.success) {
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to delete payroll item" }, 500);
  }
});

// Payroll Descriptions endpoints

// Get all payroll descriptions
app.get("/api/payroll-descriptions", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  
  const descriptions = await c.env.DB.prepare(
    "SELECT * FROM payroll_descriptions WHERE user_id = ? ORDER BY name ASC"
  ).bind(user!.id).all();
  
  return c.json(descriptions.results);
});

// Import payroll descriptions from CSV/XLSX
app.post("/api/payroll-descriptions/import", customAuthMiddleware, async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ success: false, message: "Nenhum arquivo enviado", imported: 0, errors: [] });
    }

    const arrayBuffer = await file.arrayBuffer();
    let data: any[] = [];

    // Check if it's an Excel file
    if (file.name.toLowerCase().endsWith('.xlsx') || file.name.toLowerCase().endsWith('.xls')) {
      try {
        // Parse Excel file
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // Convert to JSON with header detection
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { 
          header: 1,
          defval: '',
          raw: false
        }) as any[][];
        
        if (jsonData.length === 0) {
          return c.json({ success: false, message: "Arquivo Excel vazio", imported: 0, errors: [] });
        }

        // Convert array format to object format
        let startIndex = 0;
        const firstRow = jsonData[0] || [];
        
        // Check if first row looks like a header
        const hasHeader = firstRow.some((cell: any) => 
          String(cell).toLowerCase().includes('nome') || 
          String(cell).toLowerCase().includes('name') || 
          String(cell).toLowerCase().includes('descricao') ||
          String(cell).toLowerCase().includes('tipo')
        );
        
        if (hasHeader) {
          startIndex = 1;
        }

        // Convert rows to objects
        for (let i = startIndex; i < jsonData.length; i++) {
          const row = jsonData[i];
          if (row && row.length > 0 && String(row[0]).trim() !== '') {
            data.push({
              nome: String(row[0] || '').trim(),
              tipo: String(row[1] || '').trim(),
              descricao: String(row[2] || '').trim()
            });
          }
        }
      } catch (error) {
        return c.json({ 
          success: false, 
          message: "Erro ao processar arquivo Excel", 
          imported: 0, 
          errors: [`Erro de formato Excel: ${error}`] 
        });
      }
    } else {
      // Handle CSV files (similar to categories import)
      const uint8Array = new Uint8Array(arrayBuffer);
      let text = '';
      
      const hasBOM = uint8Array.length >= 3 && 
                     uint8Array[0] === 0xEF && 
                     uint8Array[1] === 0xBB && 
                     uint8Array[2] === 0xBF;
      
      if (hasBOM) {
        const utf8Decoder = new TextDecoder('utf-8');
        text = utf8Decoder.decode(arrayBuffer);
      } else {
        const encodings = ['utf-8', 'windows-1252', 'iso-8859-1', 'iso-8859-15'];
        
        for (const encoding of encodings) {
          try {
            const decoder = new TextDecoder(encoding);
            const decoded = decoder.decode(arrayBuffer);
            
            if (!decoded.includes('�') && !decoded.includes('\uFFFD')) {
              text = decoded;
              break;
            }
          } catch {
            continue;
          }
        }
        
        if (!text) {
          const decoder = new TextDecoder('utf-8');
          text = decoder.decode(arrayBuffer);
        }
      }
      
      const lines = text.split('\n').filter((line: string) => line.trim());
      
      if (lines.length < 1) {
        return c.json({ success: false, message: "Arquivo CSV vazio", imported: 0, errors: [] });
      }

      let startIndex = 0;
      const firstLine = lines[0].toLowerCase();
      if (firstLine.includes('nome') || firstLine.includes('name') || firstLine.includes('descricao') || firstLine.includes('tipo')) {
        startIndex = 1;
      }

      for (let i = startIndex; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        let fields = [];
        let separator = ',';
        
        const commaCount = (line.match(/,/g) || []).length;
        const semicolonCount = (line.match(/;/g) || []).length;
        const tabCount = (line.match(/\t/g) || []).length;
        
        if (semicolonCount > commaCount && semicolonCount > tabCount) {
          separator = ';';
        } else if (tabCount > commaCount && tabCount > semicolonCount) {
          separator = '\t';
        }
        
        if (separator === ',') {
          const regex = /(?:^|,)("(?:[^"]+|"")*"|[^,]*)/g;
          let match;
          while ((match = regex.exec(line)) !== null) {
            let field = match[1];
            if (field.startsWith('"') && field.endsWith('"')) {
              field = field.slice(1, -1).replace(/""/g, '"');
            }
            fields.push(field.trim());
          }
        } else {
          fields = line.split(separator).map((f: string) => f.trim());
        }
        
        fields = fields.map((field: string) => {
          if (!field) return '';
          
          if ((field.startsWith('"') && field.endsWith('"')) || 
              (field.startsWith("'") && field.endsWith("'"))) {
            field = field.slice(1, -1);
          }
          
          return field.trim();
        });

        if (fields.length > 0 && fields[0]) {
          data.push({
            nome: fields[0].trim(),
            tipo: (fields[1] || '').trim(),
            descricao: (fields[2] || '').trim()
          });
        }
      }
    }

    // Process the data
    let imported = 0;
    const errors: string[] = [];

    for (let i = 0; i < data.length; i++) {
      const item = data[i];
      
      try {
        const name = item.nome;
        if (!name) {
          errors.push(`Linha ${i + 1}: Nome é obrigatório`);
          continue;
        }

        let cleanDescription = null;
        if (item.descricao) {
          const potentialDesc = item.descricao.trim();
          if (potentialDesc.length > 0 && 
              !potentialDesc.match(/^[0-9.,]+$/) && 
              !potentialDesc.match(/^[A-Z][a-z]*$/) && 
              potentialDesc.length > 3 && 
              (potentialDesc.includes(' ') || potentialDesc.length > 10)) {
            cleanDescription = potentialDesc;
          }
        }

        let cleanTipo = null;
        if (item.tipo) {
          const potentialTipo = item.tipo.trim();
          if (potentialTipo.length > 0) {
            cleanTipo = potentialTipo;
          }
        }

        const user = c.get("user");
        const result = await c.env.DB.prepare(`
          INSERT INTO payroll_descriptions (name, tipo, description, user_id)
          VALUES (?, ?, ?, ?)
        `).bind(name, cleanTipo, cleanDescription, user!.id).run();

        if (result.success) {
          imported++;
        } else {
          errors.push(`Linha ${i + 1}: Erro ao inserir no banco de dados`);
        }
      } catch (error) {
        errors.push(`Linha ${i + 1}: Erro ao processar dados - ${error}`);
      }
    }

    return c.json({
      success: imported > 0,
      message: imported > 0 ? `${imported} descrição(ões) da folha de pagamento importada(s)` : "Nenhuma descrição da folha de pagamento foi importada",
      imported,
      errors
    });
    
  } catch (error) {
    return c.json({ 
      success: false, 
      message: "Erro interno do servidor", 
      imported: 0, 
      errors: ["Erro ao processar arquivo"] 
    });
  }
});

// Create new payroll description
app.post("/api/payroll-descriptions", customAuthMiddleware, zValidator("json", CreatePayrollDescriptionSchema), async (c) => {
  const user = c.get("user");
  const data = c.req.valid("json");
  
  const result = await c.env.DB.prepare(`
    INSERT INTO payroll_descriptions (name, description, tipo, user_id)
    VALUES (?, ?, ?, ?)
  `).bind(
    data.name,
    data.description && data.description.trim() !== '' ? data.description : null,
    data.tipo && data.tipo.trim() !== '' ? data.tipo : null,
    user!.id
  ).run();
  
  if (result.success) {
    return c.json({ success: true, id: result.meta.last_row_id });
  } else {
    return c.json({ error: "Failed to create payroll description" }, 500);
  }
});

// Update payroll description
app.put("/api/payroll-descriptions/:id", customAuthMiddleware, zValidator("json", UpdatePayrollDescriptionSchema), async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  const data = c.req.valid("json");
  
  const updates: string[] = [];
  const binds: any[] = [];
  
  if (data.name !== undefined) {
    updates.push("name = ?");
    binds.push(data.name);
  }
  if (data.description !== undefined) {
    updates.push("description = ?");
    binds.push(data.description && data.description.trim() !== '' ? data.description : null);
  }
  
  updates.push("updated_at = CURRENT_TIMESTAMP");
  binds.push(id, user!.id);
  
  const result = await c.env.DB.prepare(`
    UPDATE payroll_descriptions SET ${updates.join(", ")} WHERE id = ? AND user_id = ?
  `).bind(...binds).run();
  
  if (result.success) {
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to update payroll description" }, 500);
  }
});

// Delete payroll description
app.delete("/api/payroll-descriptions/:id", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  
  const result = await c.env.DB.prepare(
    "DELETE FROM payroll_descriptions WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).run();
  
  if (result.success) {
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to delete payroll description" }, 500);
  }
});

// Import accounts receivable from CSV/XLSX
app.post("/api/accounts-receivable/import", customAuthMiddleware, async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ success: false, message: "Nenhum arquivo enviado", imported: 0, errors: [] });
    }

    const arrayBuffer = await file.arrayBuffer();
    let data: any[] = [];

    // Check if it's an Excel file
    if (file.name.toLowerCase().endsWith('.xlsx') || file.name.toLowerCase().endsWith('.xls')) {
      try {
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { 
          header: 1,
          defval: '',
          raw: false
        }) as any[][];
        
        if (jsonData.length === 0) {
          return c.json({ success: false, message: "Arquivo Excel vazio", imported: 0, errors: [] });
        }

        let startIndex = 0;
        const firstRow = jsonData[0] || [];
        
        const hasHeader = firstRow.some((cell: any) => 
          String(cell).toLowerCase().includes('vencimento') || 
          String(cell).toLowerCase().includes('descricao') ||
          String(cell).toLowerCase().includes('valor') ||
          String(cell).toLowerCase().includes('pagador')
        );
        
        if (hasHeader) {
          startIndex = 1;
        }

        for (let i = startIndex; i < jsonData.length; i++) {
          const row = jsonData[i];
          if (row && row.length >= 4 && String(row[0]).trim() !== '') {
            let dateValue = String(row[0] || '').trim();
            console.log(`🔍 EXCEL AR: Processando data da planilha: "${dateValue}" (original: "${row[0]}")`);
            
            // Handle Excel date serial numbers
            const numericValue = Number(dateValue);
            if (!isNaN(numericValue) && numericValue > 1 && numericValue < 100000) {
              try {
                console.log(`🔢 EXCEL AR: Convertendo número serial: ${numericValue}`);
                let excelDate: Date;
                if (numericValue <= 60) {
                  excelDate = new Date(1900, 0, numericValue);
                } else {
                  excelDate = new Date(1900, 0, numericValue - 1);
                }
                
                const year = excelDate.getFullYear();
                const month = excelDate.getMonth() + 1;
                const day = excelDate.getDate();
                
                if (year >= 1900 && year <= 2100 && month >= 1 && month <= 12 && day >= 1 && day <= 31) {
                  dateValue = `${day.toString().padStart(2, '0')}/${month.toString().padStart(2, '0')}/${year}`;
                  console.log(`✅ EXCEL AR: Serial convertido: ${numericValue} → ${dateValue}`);
                } else {
                  console.log(`❌ EXCEL AR: Data inválida após conversão serial: ${day}/${month}/${year}`);
                  continue;
                }
              } catch (error) {
                console.log(`❌ EXCEL AR: Erro na conversão do serial: ${error}`);
                continue;
              }
            }
            // Formato com texto de mês inglês (ex: "30-Jan-25", "14-Feb-25", etc.)
            else if (dateValue.match(/\d{1,2}[-\s](Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[-\s]\d{2,4}/i)) {
              console.log(`📅 EXCEL AR: Detectado formato com mês inglês: "${dateValue}"`);
              const monthsEn: { [key: string]: string } = {
                'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04', 'may': '05', 'jun': '06',
                'jul': '07', 'aug': '08', 'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12'
              };
              
              const match = dateValue.match(/(\d{1,2})[-\s]([A-Za-z]{3})[-\s](\d{2,4})/i);
              if (match) {
                const day = match[1].padStart(2, '0');
                const monthAbbr = match[2].toLowerCase();
                let year = parseInt(match[3], 10);
                
                // Expandir ano de 2 dígitos
                if (year < 100) {
                  year = year < 50 ? 2000 + year : 1900 + year;
                }
                
                const month = monthsEn[monthAbbr];
                if (month) {
                  dateValue = `${day}/${month}/${year}`;
                  console.log(`✅ EXCEL AR: Mês inglês convertido: "${row[0]}" → "${dateValue}"`);
                } else {
                  console.log(`❌ EXCEL AR: Mês não reconhecido: ${monthAbbr}`);
                  continue;
                }
              } else {
                console.log(`❌ EXCEL AR: Pattern não capturou grupos na data: ${dateValue}`);
                continue;
              }
            }
            // Formato com texto de mês português (ex: "30-jan-25", "14-fev-25")
            else if (dateValue.match(/\d{1,2}[-\s](jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)[-\s]\d{2,4}/i)) {
              console.log(`📅 EXCEL AR: Detectado formato com mês português: "${dateValue}"`);
              const monthsPt: { [key: string]: string } = {
                'jan': '01', 'fev': '02', 'mar': '03', 'abr': '04', 'mai': '05', 'jun': '06',
                'jul': '07', 'ago': '08', 'set': '09', 'out': '10', 'nov': '11', 'dez': '12'
              };
              
              const match = dateValue.match(/(\d{1,2})[-\s]([a-zA-Z]{3})[-\s](\d{2,4})/i);
              if (match) {
                const day = match[1].padStart(2, '0');
                const monthAbbr = match[2].toLowerCase();
                let year = parseInt(match[3], 10);
                
                if (year < 100) {
                  year = year < 50 ? 2000 + year : 1900 + year;
                }
                
                const month = monthsPt[monthAbbr];
                if (month) {
                  dateValue = `${day}/${month}/${year}`;
                  console.log(`✅ EXCEL AR: Mês português convertido: "${row[0]}" → "${dateValue}"`);
                } else {
                  console.log(`❌ EXCEL AR: Mês português não reconhecido: ${monthAbbr}`);
                  continue;
                }
              }
            }
            // Formato ISO YYYY-MM-DD
            else if (dateValue.match(/^\d{4}-\d{1,2}-\d{1,2}$/)) {
              console.log(`📅 EXCEL AR: Detectado formato ISO: "${dateValue}"`);
              const [year, month, day] = dateValue.split('-');
              dateValue = `${day.padStart(2, '0')}/${month.padStart(2, '0')}/${year}`;
              console.log(`✅ EXCEL AR: ISO convertido: "${row[0]}" → "${dateValue}"`);
            }
            // Formato com hífen DD-MM-YY ou DD-MM-YYYY
            else if (dateValue.match(/^\d{1,2}-\d{1,2}-\d{2,4}$/)) {
              console.log(`📅 EXCEL AR: Detectado formato com hífen DD-MM: "${dateValue}"`);
              const parts = dateValue.split('-');
              let day = parts[0].padStart(2, '0');
              let month = parts[1].padStart(2, '0');
              let year = parseInt(parts[2], 10);
              
              if (year < 100) {
                year = year < 50 ? 2000 + year : 1900 + year;
              }
              
              dateValue = `${day}/${month}/${year}`;
              console.log(`✅ EXCEL AR: Hífen DD-MM convertido: "${row[0]}" → "${dateValue}"`);
            }
            // Formato com pontos DD.MM.YY ou DD.MM.YYYY
            else if (dateValue.match(/^\d{1,2}\.\d{1,2}\.\d{2,4}$/)) {
              console.log(`📅 EXCEL AR: Detectado formato com pontos: "${dateValue}"`);
              const parts = dateValue.split('.');
              let day = parts[0].padStart(2, '0');
              let month = parts[1].padStart(2, '0');
              let year = parseInt(parts[2], 10);
              
              if (year < 100) {
                year = year < 50 ? 2000 + year : 1900 + year;
              }
              
              dateValue = `${day}/${month}/${year}`;
              console.log(`✅ EXCEL AR: Pontos convertido: "${row[0]}" → "${dateValue}"`);
            }
            // Formato brasileiro DD/MM/YY ou DD/MM/YYYY
            else if (dateValue.match(/^\d{1,2}\/\d{1,2}\/\d{2,4}$/)) {
              console.log(`📅 EXCEL AR: Detectado formato brasileiro com barras: "${dateValue}"`);
              const parts = dateValue.split('/');
              const dayPart = parseInt(parts[0], 10);
              const monthPart = parseInt(parts[1], 10);
              let yearPart = parseInt(parts[2], 10);
              
              if (yearPart < 100) {
                yearPart = yearPart < 50 ? 2000 + yearPart : 1900 + yearPart;
              }
              
              dateValue = `${dayPart.toString().padStart(2, '0')}/${monthPart.toString().padStart(2, '0')}/${yearPart}`;
              console.log(`✅ EXCEL AR: Formato brasileiro mantido: "${row[0]}" → "${dateValue}"`);
            }
            
            data.push({
              vencimento: dateValue,
              descricao: String(row[1] || '').trim(),
              categoria: String(row[2] || '').trim(),
              centro_custo: String(row[3] || '').trim(),
              pagador: String(row[4] || '').trim(),
              valor: String(row[5] || '').trim(),
              status: String(row[6] || '').trim()
            });
          }
        }
      } catch (error) {
        return c.json({ 
          success: false, 
          message: "Erro ao processar arquivo Excel", 
          imported: 0, 
          errors: [`Erro de formato Excel: ${error}`] 
        });
      }
    } else {
      // Handle CSV files
      const uint8Array = new Uint8Array(arrayBuffer);
      let text = '';
      
      const hasBOM = uint8Array.length >= 3 && 
                     uint8Array[0] === 0xEF && 
                     uint8Array[1] === 0xBB && 
                     uint8Array[2] === 0xBF;
      
      if (hasBOM) {
        const utf8Decoder = new TextDecoder('utf-8');
        text = utf8Decoder.decode(arrayBuffer);
      } else {
        const encodings = ['utf-8', 'windows-1252', 'iso-8859-1', 'iso-8859-15'];
        
        for (const encoding of encodings) {
          try {
            const decoder = new TextDecoder(encoding);
            const decoded = decoder.decode(arrayBuffer);
            
            if (!decoded.includes('�') && !decoded.includes('\uFFFD')) {
              text = decoded;
              break;
            }
          } catch {
            continue;
          }
        }
        
        if (!text) {
          const decoder = new TextDecoder('utf-8');
          text = decoder.decode(arrayBuffer);
        }
      }
      
      const lines = text.split('\n').filter((line: string) => line.trim());
      
      if (lines.length < 1) {
        return c.json({ success: false, message: "Arquivo CSV vazio", imported: 0, errors: [] });
      }

      let startIndex = 0;
      const firstLine = lines[0].toLowerCase();
      if (firstLine.includes('vencimento') || firstLine.includes('descricao') || 
          firstLine.includes('valor') || firstLine.includes('pagador')) {
        startIndex = 1;
      }

      for (let i = startIndex; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        let fields = [];
        let separator = ',';
        
        const commaCount = (line.match(/,/g) || []).length;
        const semicolonCount = (line.match(/;/g) || []).length;
        const tabCount = (line.match(/\t/g) || []).length;
        
        if (semicolonCount > commaCount && semicolonCount > tabCount) {
          separator = ';';
        } else if (tabCount > commaCount && tabCount > semicolonCount) {
          separator = '\t';
        }
        
        if (separator === ',') {
          const regex = /(?:^|,)("(?:[^"]+|"")*"|[^,]*)/g;
          let match;
          while ((match = regex.exec(line)) !== null) {
            let field = match[1];
            if (field.startsWith('"') && field.endsWith('"')) {
              field = field.slice(1, -1).replace(/""/g, '"');
            }
            fields.push(field.trim());
          }
        } else {
          fields = line.split(separator).map((f: string) => f.trim());
        }
        
        fields = fields.map((field: string) => {
          if (!field) return '';
          
          if ((field.startsWith('"') && field.endsWith('"')) || 
              (field.startsWith("'") && field.endsWith("'"))) {
            field = field.slice(1, -1);
          }
          
          return field.trim();
        });

        if (fields.length >= 4 && fields[0]) {
          data.push({
            vencimento: fields[0].trim(),
            descricao: fields[1].trim(),
            categoria: (fields[2] || '').trim(),
            centro_custo: (fields[3] || '').trim(),
            pagador: fields[4].trim(),
            valor: (fields[5] || '').trim(),
            status: (fields[6] || '').trim()
          });
        }
      }
    }

    // Get existing categories and cost centers for matching
    const user = c.get("user");
    const categoriesResult = await c.env.DB.prepare("SELECT * FROM categories WHERE user_id = ?").bind(user!.id).all();
    const costCentersResult = await c.env.DB.prepare("SELECT * FROM cost_centers WHERE user_id = ?").bind(user!.id).all();
    
    const categories = categoriesResult.results as any[];
    const costCenters = costCentersResult.results as any[];

    // Process the data
    let imported = 0;
    const errors: string[] = [];

    for (let i = 0; i < data.length; i++) {
      const item = data[i];
      
      try {
        const dueDateStr = item.vencimento;
        const description = item.descricao;
        const categoryName = item.categoria || '';
        const costCenterName = item.centro_custo || '';
        const payer = item.pagador;
        const amountStr = item.valor;
        const statusStr = item.status || '';

        // Parse due date - suporte para múltiplos formatos
        let transactionDate = '';
        if (dueDateStr) {
          const cleanDateStr = dueDateStr.trim();
          console.log(`🔍 IMPORTAÇÃO AR: Data original da planilha: "${cleanDateStr}"`);
          
          // Formato com texto de mês inglês (ex: "30-Jan-25", "14-Feb-25")
          if (cleanDateStr.match(/\d{1,2}[-\s](Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[-\s]\d{2,4}/i)) {
            console.log(`📅 AR: Detectado formato com mês inglês: "${cleanDateStr}"`);
            const monthsEn: { [key: string]: string } = {
              'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04', 'may': '05', 'jun': '06',
              'jul': '07', 'aug': '08', 'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12'
            };
            
            const match = cleanDateStr.match(/(\d{1,2})[-\s]([A-Za-z]{3})[-\s](\d{2,4})/i);
            if (match) {
              const day = parseInt(match[1], 10);
              const monthAbbr = match[2].toLowerCase();
              let year = parseInt(match[3], 10);
              
              // Expandir ano de 2 dígitos
              if (year < 100) {
                year = year < 50 ? 2000 + year : 1900 + year;
              }
              
              const monthNum = monthsEn[monthAbbr];
              if (monthNum) {
                // Validações
                if (day < 1 || day > 31) {
                  errors.push(`Linha ${i + 1}: Dia inválido: ${day} (deve estar entre 1 e 31)`);
                  continue;
                }
                
                if (year < 1900 || year > 2100) {
                  errors.push(`Linha ${i + 1}: Ano inválido: ${year} (deve estar entre 1900 e 2100)`);
                  continue;
                }
                
                const month = parseInt(monthNum, 10);
                const testDate = new Date(year, month - 1, day);
                if (testDate.getDate() !== day || testDate.getMonth() !== month - 1 || testDate.getFullYear() !== year) {
                  errors.push(`Linha ${i + 1}: Data não existe no calendário: ${day}/${month}/${year}`);
                  continue;
                }
                
                transactionDate = `${year}-${monthNum}-${day.toString().padStart(2, '0')}`;
                console.log(`✅ AR: Mês inglês convertido: "${cleanDateStr}" → ISO: "${transactionDate}"`);
              } else {
                errors.push(`Linha ${i + 1}: Mês não reconhecido: ${monthAbbr}`);
                continue;
              }
            } else {
              errors.push(`Linha ${i + 1}: Formato de data com mês inválido: ${cleanDateStr}`);
              continue;
            }
          }
          // Formato com texto de mês português (ex: "30-jan-25", "14-fev-25")
          else if (cleanDateStr.match(/\d{1,2}[-\s](jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)[-\s]\d{2,4}/i)) {
            console.log(`📅 AR: Detectado formato com mês português: "${cleanDateStr}"`);
            const monthsPt: { [key: string]: string } = {
              'jan': '01', 'fev': '02', 'mar': '03', 'abr': '04', 'mai': '05', 'jun': '06',
              'jul': '07', 'ago': '08', 'set': '09', 'out': '10', 'nov': '11', 'dez': '12'
            };
            
            const match = cleanDateStr.match(/(\d{1,2})[-\s]([a-zA-Z]{3})[-\s](\d{2,4})/i);
            if (match) {
              const day = parseInt(match[1], 10);
              const monthAbbr = match[2].toLowerCase();
              let year = parseInt(match[3], 10);
              
              if (year < 100) {
                year = year < 50 ? 2000 + year : 1900 + year;
              }
              
              const monthNum = monthsPt[monthAbbr];
              if (monthNum) {
                if (day < 1 || day > 31) {
                  errors.push(`Linha ${i + 1}: Dia inválido: ${day} (deve estar entre 1 e 31)`);
                  continue;
                }
                
                if (year < 1900 || year > 2100) {
                  errors.push(`Linha ${i + 1}: Ano inválido: ${year} (deve estar entre 1900 e 2100)`);
                  continue;
                }
                
                const month = parseInt(monthNum, 10);
                const testDate = new Date(year, month - 1, day);
                if (testDate.getDate() !== day || testDate.getMonth() !== month - 1 || testDate.getFullYear() !== year) {
                  errors.push(`Linha ${i + 1}: Data não existe no calendário: ${day}/${month}/${year}`);
                  continue;
                }
                
                transactionDate = `${year}-${monthNum}-${day.toString().padStart(2, '0')}`;
                console.log(`✅ AR: Mês português convertido: "${cleanDateStr}" → ISO: "${transactionDate}"`);
              } else {
                errors.push(`Linha ${i + 1}: Mês português não reconhecido: ${monthAbbr}`);
                continue;
              }
            } else {
              errors.push(`Linha ${i + 1}: Formato de data com mês português inválido: ${cleanDateStr}`);
              continue;
            }
          }
          // Formato brasileiro DD/MM/YYYY
          else if (cleanDateStr.includes('/')) {
            const parts = cleanDateStr.split('/').map((p: string) => p.trim());
            if (parts.length === 3) {
              const dayPart = parseInt(parts[0], 10);
              const monthPart = parseInt(parts[1], 10);
              let yearPart = parseInt(parts[2], 10);
              
              if (isNaN(dayPart) || isNaN(monthPart) || isNaN(yearPart)) {
                errors.push(`Linha ${i + 1}: Valores não numéricos na data: "${cleanDateStr}"`);
                continue;
              }
              
              if (yearPart < 100) {
                yearPart = yearPart < 50 ? 2000 + yearPart : 1900 + yearPart;
              }
              
              const day = dayPart;
              const month = monthPart;
              const year = yearPart;
              
              if (day < 1 || day > 31) {
                errors.push(`Linha ${i + 1}: Dia inválido: ${day} (deve estar entre 1 e 31)`);
                continue;
              }
              
              if (month < 1 || month > 12) {
                errors.push(`Linha ${i + 1}: Mês inválido: ${month} (deve estar entre 1 e 12)`);
                continue;
              }
              
              if (year < 1900 || year > 2100) {
                errors.push(`Linha ${i + 1}: Ano inválido: ${year} (deve estar entre 1900 e 2100)`);
                continue;
              }
              
              const testDate = new Date(year, month - 1, day);
              if (testDate.getDate() !== day || testDate.getMonth() !== month - 1 || testDate.getFullYear() !== year) {
                errors.push(`Linha ${i + 1}: Data não existe no calendário: ${day}/${month}/${year}`);
                continue;
              }
              
              transactionDate = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
              console.log(`✅ AR: Formato brasileiro: "${cleanDateStr}" → ISO: "${transactionDate}"`);
            } else {
              errors.push(`Linha ${i + 1}: Formato de data inválido: ${cleanDateStr}. Use DD/MM/YYYY`);
              continue;
            }
          }
          // Formato ISO YYYY-MM-DD
          else if (cleanDateStr.match(/^\d{4}-\d{1,2}-\d{1,2}$/)) {
            console.log(`📅 AR: Detectado formato ISO: "${cleanDateStr}"`);
            const [year, month, day] = cleanDateStr.split('-');
            const yearNum = parseInt(year, 10);
            const monthNum = parseInt(month, 10);
            const dayNum = parseInt(day, 10);
            
            if (dayNum < 1 || dayNum > 31 || monthNum < 1 || monthNum > 12 || yearNum < 1900 || yearNum > 2100) {
              errors.push(`Linha ${i + 1}: Data ISO inválida: ${cleanDateStr}`);
              continue;
            }
            
            const testDate = new Date(yearNum, monthNum - 1, dayNum);
            if (testDate.getDate() !== dayNum || testDate.getMonth() !== monthNum - 1 || testDate.getFullYear() !== yearNum) {
              errors.push(`Linha ${i + 1}: Data ISO não existe no calendário: ${cleanDateStr}`);
              continue;
            }
            
            transactionDate = cleanDateStr;
            console.log(`✅ AR: Formato ISO mantido: "${cleanDateStr}"`);
          }
          else {
            errors.push(`Linha ${i + 1}: Formato de data não suportado: ${cleanDateStr}. Use DD/MM/YYYY ou 30-Jan-25`);
            continue;
          }
        } else {
          errors.push(`Linha ${i + 1}: Data é obrigatória`);
          continue;
        }

        if (!description) {
          errors.push(`Linha ${i + 1}: Descrição é obrigatória`);
          continue;
        }

        if (!payer) {
          errors.push(`Linha ${i + 1}: Pagador é obrigatório`);
          continue;
        }

        // Parse amount - must be positive for accounts receivable
        let amount = 0;
        if (amountStr) {
          let cleanAmount = amountStr.replace(/[^\d,.-]/g, '');
          
          if (cleanAmount.includes(',') && cleanAmount.includes('.')) {
            const lastCommaIndex = cleanAmount.lastIndexOf(',');
            const lastDotIndex = cleanAmount.lastIndexOf('.');
            
            if (lastCommaIndex > lastDotIndex) {
              cleanAmount = cleanAmount.replace(/\./g, '').replace(',', '.');
            } else {
              cleanAmount = cleanAmount.replace(/,/g, '');
            }
          } else if (cleanAmount.includes(',')) {
            const commaIndex = cleanAmount.lastIndexOf(',');
            const afterComma = cleanAmount.substring(commaIndex + 1);
            if (afterComma.length <= 2) {
              cleanAmount = cleanAmount.replace(',', '.');
            } else {
              cleanAmount = cleanAmount.replace(/,/g, '');
            }
          }
          
          amount = parseFloat(cleanAmount);
          if (isNaN(amount)) {
            errors.push(`Linha ${i + 1}: Valor inválido - ${amountStr}`);
            continue;
          }
          
          // Ensure positive amount for accounts receivable
          if (amount <= 0) {
            errors.push(`Linha ${i + 1}: O valor deve ser positivo para contas a receber - ${amountStr}`);
            continue;
          }
        } else {
          errors.push(`Linha ${i + 1}: Valor é obrigatório`);
          continue;
        }

        // Find category by name
        let categoryId = null;
        if (categoryName) {
          const category = categories.find(c => 
            c.name.toLowerCase() === categoryName.toLowerCase()
          );
          if (category) {
            categoryId = category.id;
          }
        }

        // Find cost center by name
        let costCenterId = null;
        if (costCenterName) {
          const costCenter = costCenters.find(cc => 
            cc.name.toLowerCase() === costCenterName.toLowerCase()
          );
          if (costCenter) {
            costCenterId = costCenter.id;
          }
        }

        // Validate status
        let status = 'NÃO RECEBIDO';
        if (statusStr) {
          const upperStatus = statusStr.toUpperCase().trim();
          if (upperStatus === 'RECEBIDO' || upperStatus === 'NÃO RECEBIDO') {
            status = upperStatus;
          }
        }

        const result = await c.env.DB.prepare(`
          INSERT INTO accounts_receivable (due_date, description, amount, category_id, cost_center_id, payer, status, user_id)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(transactionDate, description, amount, categoryId, costCenterId, payer, status, user!.id).run();

        if (result.success) {
          imported++;
        } else {
          errors.push(`Linha ${i + 1}: Erro ao inserir no banco de dados`);
        }
      } catch (error) {
        errors.push(`Linha ${i + 1}: Erro ao processar dados - ${error}`);
      }
    }

    return c.json({
      success: imported > 0,
      message: imported > 0 ? `${imported} conta(s) a receber importada(s)` : "Nenhuma conta a receber foi importada",
      imported,
      errors
    });
    
  } catch (error) {
    return c.json({ 
      success: false, 
      message: "Erro interno do servidor", 
      imported: 0, 
      errors: ["Erro ao processar arquivo"] 
    });
  }
});

// Get all accounts receivable with details
app.get("/api/accounts-receivable", customAuthMiddleware, async (c) => {
  try {
    const user = c.get("user");
    console.log("📊 API: Fetching accounts receivable for user:", user!.id);
    
    const accountsReceivable = await c.env.DB.prepare(`
      SELECT 
        ar.*,
        c.name as category_name,
        cc.name as cost_center_name
      FROM accounts_receivable ar
      LEFT JOIN categories c ON ar.category_id = c.id AND c.user_id = ?
      LEFT JOIN cost_centers cc ON ar.cost_center_id = cc.id AND cc.user_id = ?
      WHERE ar.user_id = ?
      ORDER BY ar.due_date ASC, ar.id DESC
    `).bind(user!.id, user!.id, user!.id).all();
    
    console.log(`📊 API: Found ${accountsReceivable.results?.length || 0} accounts receivable`);
    
    // Ensure we always return an array, even if results is undefined
    const results = accountsReceivable.results || [];
    
    return c.json(results);
  } catch (error) {
    console.error("❌ API: Error fetching accounts receivable:", error);
    return c.json({ error: "Failed to fetch accounts receivable", details: error instanceof Error ? error.message : 'Unknown error' }, 500);
  }
});

// Create new account receivable
app.post("/api/accounts-receivable", customAuthMiddleware, zValidator("json", CreateAccountsReceivableSchema), async (c) => {
  const user = c.get("user");
  const data = c.req.valid("json");
  
  const result = await c.env.DB.prepare(`
    INSERT INTO accounts_receivable (due_date, description, amount, category_id, cost_center_id, payer, status, user_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    data.due_date,
    data.description,
    data.amount,
    data.category_id || null,
    data.cost_center_id || null,
    data.payer,
    data.status || 'NÃO RECEBIDO',
    user!.id
  ).run();
  
  if (result.success) {
    return c.json({ success: true, id: result.meta.last_row_id });
  } else {
    return c.json({ error: "Failed to create account receivable" }, 500);
  }
});

// Update account receivable
app.put("/api/accounts-receivable/:id", customAuthMiddleware, zValidator("json", UpdateAccountsReceivableSchema), async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  const data = c.req.valid("json");
  
  // Get current account receivable to check status change
  const currentAccountReceivable = await c.env.DB.prepare(
    "SELECT * FROM accounts_receivable WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).first();
  
  if (!currentAccountReceivable) {
    return c.json({ error: "Account receivable not found" }, 404);
  }
  
  const updates: string[] = [];
  const binds: any[] = [];
  
  if (data.due_date !== undefined) {
    updates.push("due_date = ?");
    binds.push(data.due_date);
  }
  if (data.description !== undefined) {
    updates.push("description = ?");
    binds.push(data.description);
  }
  if (data.amount !== undefined) {
    updates.push("amount = ?");
    binds.push(data.amount);
  }
  if (data.category_id !== undefined) {  
    updates.push("category_id = ?");
    binds.push(data.category_id || null);
  }
  if (data.cost_center_id !== undefined) {
    updates.push("cost_center_id = ?");
    binds.push(data.cost_center_id || null);
  }
  if (data.payer !== undefined) {
    updates.push("payer = ?");
    binds.push(data.payer);
  }
  if (data.status !== undefined) {
    updates.push("status = ?");
    binds.push(data.status);
  }
  
  updates.push("updated_at = CURRENT_TIMESTAMP");
  binds.push(id, user!.id);
  
  const result = await c.env.DB.prepare(`
    UPDATE accounts_receivable SET ${updates.join(", ")} WHERE id = ? AND user_id = ?
  `).bind(...binds).run();
  
  if (result.success) {
    // If status is being changed to RECEBIDO, create a corresponding transaction
    if (data.status === 'RECEBIDO' && currentAccountReceivable.status !== 'RECEBIDO') {
      const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
      
      // Use updated values if provided, otherwise use current values
      const finalDescription = data.description !== undefined ? data.description : currentAccountReceivable.description;
      const finalAmount = data.amount !== undefined ? data.amount : currentAccountReceivable.amount;
      const finalCategoryId = data.category_id !== undefined ? data.category_id : currentAccountReceivable.category_id;
      const finalCostCenterId = data.cost_center_id !== undefined ? data.cost_center_id : currentAccountReceivable.cost_center_id;
      
      await c.env.DB.prepare(`
        INSERT INTO transactions (date, description, amount, category_id, cost_center_id, is_recurring, status, user_id)
        VALUES (?, ?, ?, ?, ?, 0, ?, ?)
      `).bind(
        today,
        finalDescription,
        finalAmount,
        finalCategoryId || null,
        finalCostCenterId || null,
        'RECEBIDO',
        user!.id
      ).run();
    }
    
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to update account receivable" }, 500);
  }
});

// Toggle account receivable status
app.patch("/api/accounts-receivable/:id/status", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  
  // Get full account receivable details
  const accountReceivable = await c.env.DB.prepare(
    "SELECT * FROM accounts_receivable WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).first();
  
  if (!accountReceivable) {
    return c.json({ error: "Account receivable not found" }, 404);
  }
  
  const currentStatus = accountReceivable.status || 'NÃO RECEBIDO';
  const newStatus = currentStatus === 'RECEBIDO' ? 'NÃO RECEBIDO' : 'RECEBIDO';
  
  const result = await c.env.DB.prepare(
    "UPDATE accounts_receivable SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
  ).bind(newStatus, id, user!.id).run();
  
  if (result.success) {
    // If changing to RECEBIDO, create a corresponding transaction
    if (newStatus === 'RECEBIDO') {
      const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
      
      await c.env.DB.prepare(`
        INSERT INTO transactions (date, description, amount, category_id, cost_center_id, is_recurring, status, user_id)
        VALUES (?, ?, ?, ?, ?, 0, ?, ?)
      `).bind(
        today,
        accountReceivable.description,
        accountReceivable.amount,
        accountReceivable.category_id,
        accountReceivable.cost_center_id,
        'RECEBIDO',
        user!.id
      ).run();
    }
    
    return c.json({ success: true, status: newStatus });
  } else {
    return c.json({ error: "Failed to update account receivable status" }, 500);
  }
});

// Update account receivable amount
app.patch("/api/accounts-receivable/:id/amount", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  const body = await c.req.json();
  const amount = body.amount;
  
  if (amount === undefined || amount === null) {
    return c.json({ error: "Amount is required" }, 400);
  }
  
  if (isNaN(parseFloat(amount))) {
    return c.json({ error: "Invalid amount value" }, 400);
  }
  
  const finalAmount = parseFloat(amount);
  if (finalAmount <= 0) {
    return c.json({ error: "O valor deve ser positivo para contas a receber" }, 400);
  }
  
  const result = await c.env.DB.prepare(
    "UPDATE accounts_receivable SET amount = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
  ).bind(finalAmount, id, user!.id).run();
  
  if (result.success) {
    return c.json({ success: true, amount: finalAmount });
  } else {
    return c.json({ error: "Failed to update account receivable amount" }, 500);
  }
});

// Update account receivable due date
app.patch("/api/accounts-receivable/:id/due-date", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  const body = await c.req.json();
  const dueDate = body.due_date;
  
  if (!dueDate) {
    return c.json({ error: "Due date is required" }, 400);
  }
  
  const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateRegex.test(dueDate)) {
    return c.json({ error: "Invalid date format. Use YYYY-MM-DD" }, 400);
  }
  
  const parsedDate = new Date(dueDate + 'T00:00:00');
  if (isNaN(parsedDate.getTime())) {
    return c.json({ error: "Invalid date" }, 400);
  }
  
  const result = await c.env.DB.prepare(
    "UPDATE accounts_receivable SET due_date = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
  ).bind(dueDate, id, user!.id).run();
  
  if (result.success) {
    return c.json({ success: true, due_date: dueDate });
  } else {
    return c.json({ error: "Failed to update account receivable due date" }, 500);
  }
});

// Delete account receivable
app.delete("/api/accounts-receivable/:id", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  const id = c.req.param("id");
  
  const result = await c.env.DB.prepare(
    "DELETE FROM accounts_receivable WHERE id = ? AND user_id = ?"
  ).bind(id, user!.id).run();
  
  if (result.success) {
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to delete account receivable" }, 500);
  }
});

// License Management Endpoints

// Get all licenses
app.get("/api/licenses", async (c) => {
  const licenses = await c.env.DB.prepare(`
    SELECT * FROM licencas 
    ORDER BY created_at DESC
  `).all();
  
  return c.json(licenses.results);
});

// Get license by user ID
app.get("/api/licenses/user/:userId", async (c) => {
  const userId = c.req.param("userId");
  
  const license = await c.env.DB.prepare(`
    SELECT * FROM licencas 
    WHERE usuario_id = ? AND status = 'ativa' AND (data_fim >= date('now') OR plano = 'Vitalício')
    ORDER BY data_fim DESC
    LIMIT 1
  `).bind(userId).first();
  
  return c.json(license);
});

// Check license validity
app.get("/api/licenses/check/:userId", async (c) => {
  const userId = c.req.param("userId");
  console.log('🔍 LICENSE: Checking license for user:', userId);
  
  const license = await c.env.DB.prepare(`
    SELECT * FROM licencas 
    WHERE usuario_id = ? AND status = 'ativa' AND (data_fim >= date('now') OR plano = 'Vitalício')
    ORDER BY data_fim DESC
    LIMIT 1
  `).bind(userId).first();
  
  console.log('🔍 LICENSE: Found license:', license ? 'Yes' : 'No');
  
  // FOR DEVELOPMENT: If no license found, create a development license for any user
  if (!license) {
    console.log('🔧 LICENSE: Creating development license for user:', userId);
    
    // Create a development license valid for 1 year
    const today = new Date().toISOString().split('T')[0];
    const oneYearFromNow = new Date();
    oneYearFromNow.setFullYear(oneYearFromNow.getFullYear() + 1);
    const futureDate = oneYearFromNow.toISOString().split('T')[0];
    
    const createResult = await c.env.DB.prepare(`
      INSERT INTO licencas (usuario_id, plano, data_inicio, data_fim, status, observacoes)
      VALUES (?, ?, ?, ?, ?, ?)
    `).bind(
      userId,
      'Vitalício',
      today,
      futureDate,
      'ativa',
      'Licença automática criada para acesso ao sistema'
    ).run();
    
    if (createResult.success) {
      console.log('✅ LICENSE: Development license created successfully');
      // Fetch the newly created license
      const newLicense = await c.env.DB.prepare(`
        SELECT * FROM licencas 
        WHERE usuario_id = ? AND status = 'ativa'
        ORDER BY created_at DESC
        LIMIT 1
      `).bind(userId).first();
      
      if (newLicense) {
        console.log('✅ LICENSE: Using newly created development license');
        return c.json({
          isValid: true,
          license: newLicense,
          daysUntilExpiry: 999999,
          message: 'Licença de desenvolvimento ativa'
        });
      }
    } else {
      console.log('❌ LICENSE: Failed to create development license');
    }
  }
  
  const isValid = !!license;
  
  // Para licenças vitalícias, não calcular dias até expiração
  let daysUntilExpiry = 0;
  let message = '';
  
  if (license) {
    if (license.plano === 'Vitalício') {
      daysUntilExpiry = 999999; // Valor muito alto para representar "sem expiração"
      message = 'Licença vitalícia ativa';
    } else {
      daysUntilExpiry = Math.ceil((new Date(license.data_fim as string).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
      message = daysUntilExpiry <= 7 ? `Sua licença expira em ${daysUntilExpiry} dia(s)` : 'Licença válida';
    }
  } else {
    message = 'Sua licença expirou. Entre em contato com o suporte.';
  }
  
  console.log('📊 LICENSE: Final result - isValid:', isValid, 'message:', message);
  
  return c.json({
    isValid,
    license,
    daysUntilExpiry,
    message
  });
});

// Create new license
app.post("/api/licenses", zValidator("json", CreateLicenseSchema), async (c) => {
  const data = c.req.valid("json");
  
  const result = await c.env.DB.prepare(`
    INSERT INTO licencas (usuario_id, plano, data_inicio, data_fim, status, observacoes)
    VALUES (?, ?, ?, ?, ?, ?)
  `).bind(
    data.usuario_id,
    data.plano,
    data.data_inicio,
    data.data_fim,
    data.status || 'ativa',
    data.observacoes || null
  ).run();
  
  if (result.success) {
    return c.json({ success: true, id: result.meta.last_row_id });
  } else {
    return c.json({ error: "Failed to create license" }, 500);
  }
});

// Update license
app.put("/api/licenses/:id", zValidator("json", UpdateLicenseSchema), async (c) => {
  const id = c.req.param("id");
  const data = c.req.valid("json");
  
  const updates: string[] = [];
  const binds: any[] = [];
  
  if (data.usuario_id !== undefined) {
    updates.push("usuario_id = ?");
    binds.push(data.usuario_id);
  }
  if (data.plano !== undefined) {
    updates.push("plano = ?");
    binds.push(data.plano);
  }
  if (data.data_inicio !== undefined) {
    updates.push("data_inicio = ?");
    binds.push(data.data_inicio);
  }
  if (data.data_fim !== undefined) {
    updates.push("data_fim = ?");
    binds.push(data.data_fim);
  }
  if (data.status !== undefined) {
    updates.push("status = ?");
    binds.push(data.status);
  }
  if (data.observacoes !== undefined) {
    updates.push("observacoes = ?");
    binds.push(data.observacoes || null);
  }
  
  updates.push("updated_at = CURRENT_TIMESTAMP");
  binds.push(id);
  
  const result = await c.env.DB.prepare(`
    UPDATE licencas SET ${updates.join(", ")} WHERE id = ?
  `).bind(...binds).run();
  
  if (result.success) {
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to update license" }, 500);
  }
});

// Delete license
app.delete("/api/licenses/:id", async (c) => {
  const id = c.req.param("id");
  
  const result = await c.env.DB.prepare(
    "DELETE FROM licencas WHERE id = ?"
  ).bind(id).run();
  
  if (result.success) {
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to delete license" }, 500);
  }
});

// Get license statistics
app.get("/api/licenses/stats", async (c) => {
  const totalLicenses = await c.env.DB.prepare("SELECT COUNT(*) as count FROM licencas").first();
  const activeLicenses = await c.env.DB.prepare("SELECT COUNT(*) as count FROM licencas WHERE status = 'ativa'").first();
  const expiredLicenses = await c.env.DB.prepare("SELECT COUNT(*) as count FROM licencas WHERE status = 'expirada' OR data_fim < date('now')").first();
  const suspendedLicenses = await c.env.DB.prepare("SELECT COUNT(*) as count FROM licencas WHERE status = 'suspensa'").first();
  
  const expiringLicenses = await c.env.DB.prepare(`
    SELECT COUNT(*) as count FROM licencas 
    WHERE status = 'ativa' AND data_fim BETWEEN date('now') AND date('now', '+7 days')
  `).first();
  
  return c.json({
    total: totalLicenses?.count || 0,
    active: activeLicenses?.count || 0,
    expired: expiredLicenses?.count || 0,
    suspended: suspendedLicenses?.count || 0,
    expiringSoon: expiringLicenses?.count || 0
  });
});

// User Management Endpoints

// Get all users
app.get("/api/usuarios", async (c) => {
  const users = await c.env.DB.prepare(`
    SELECT id, nome, email, tipo, ativo, created_at, updated_at
    FROM usuarios 
    ORDER BY created_at DESC
  `).all();
  
  return c.json(users.results);
});

// Get user statistics
app.get("/api/usuarios/stats", async (c) => {
  const totalUsers = await c.env.DB.prepare("SELECT COUNT(*) as count FROM usuarios").first();
  const activeUsers = await c.env.DB.prepare("SELECT COUNT(*) as count FROM usuarios WHERE ativo = 1").first();
  const inactiveUsers = await c.env.DB.prepare("SELECT COUNT(*) as count FROM usuarios WHERE ativo = 0").first();
  const adminUsers = await c.env.DB.prepare("SELECT COUNT(*) as count FROM usuarios WHERE tipo = 'admin'").first();
  
  return c.json({
    total: totalUsers?.count || 0,
    ativos: activeUsers?.count || 0,
    inativos: inactiveUsers?.count || 0,
    admins: adminUsers?.count || 0
  });
});

// Get user by ID
app.get("/api/usuarios/:id", async (c) => {
  const id = c.req.param("id");
  
  const user = await c.env.DB.prepare(`
    SELECT id, nome, email, tipo, ativo, created_at, updated_at
    FROM usuarios 
    WHERE id = ?
  `).bind(id).first();
  
  if (!user) {
    return c.json({ error: "User not found" }, 404);
  }
  
  return c.json(user);
});

// Create new user
app.post("/api/usuarios", async (c) => {
  try {
    const data = await c.req.json();
    
    // Validate required fields
    if (!data.nome || !data.email || !data.senha) {
      return c.json({ error: "Nome, email e senha são obrigatórios" }, 400);
    }
    
    // Generate user ID
    const userId = data.email.split('@')[0] + '-' + Math.random().toString(36).substr(2, 9);
    
    const result = await c.env.DB.prepare(`
      INSERT INTO usuarios (id, nome, email, senha_hash, tipo, ativo)
      VALUES (?, ?, ?, ?, ?, ?)
    `).bind(
      userId,
      data.nome,
      data.email,
      data.senha, // In production, you should hash this password
      data.tipo || 'usuario',
      data.ativo !== false ? 1 : 0
    ).run();
    
    if (result.success) {
      return c.json({ success: true, id: userId });
    } else {
      return c.json({ error: "Failed to create user" }, 500);
    }
  } catch (error) {
    console.error("Error creating user:", error);
    return c.json({ error: "Failed to create user" }, 500);
  }
});

// Update user
app.put("/api/usuarios/:id", async (c) => {
  const id = c.req.param("id");
  const data = await c.req.json();
  
  const updates: string[] = [];
  const binds: any[] = [];
  
  if (data.nome !== undefined) {
    updates.push("nome = ?");
    binds.push(data.nome);
  }
  if (data.email !== undefined) {
    updates.push("email = ?");
    binds.push(data.email);
  }
  if (data.senha !== undefined && data.senha.trim() !== '') {
    updates.push("senha_hash = ?");
    binds.push(data.senha); // In production, hash this password
  }
  if (data.tipo !== undefined) {
    updates.push("tipo = ?");
    binds.push(data.tipo);
  }
  if (data.ativo !== undefined) {
    updates.push("ativo = ?");
    binds.push(data.ativo ? 1 : 0);
  }
  
  updates.push("updated_at = CURRENT_TIMESTAMP");
  binds.push(id);
  
  const result = await c.env.DB.prepare(`
    UPDATE usuarios SET ${updates.join(", ")} WHERE id = ?
  `).bind(...binds).run();
  
  if (result.success) {
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to update user" }, 500);
  }
});

// Delete user
app.delete("/api/usuarios/:id", async (c) => {
  const id = c.req.param("id");
  
  // Check if user has active licenses
  const activeLicenses = await c.env.DB.prepare(
    "SELECT COUNT(*) as count FROM licencas WHERE usuario_id = ? AND status = 'ativa'"
  ).bind(id).first();
  
  if (activeLicenses && (activeLicenses.count as number) > 0) {
    return c.json({ 
      error: "Não é possível excluir usuário com licenças ativas. Desative as licenças primeiro." 
    }, 400);
  }
  
  const result = await c.env.DB.prepare(
    "DELETE FROM usuarios WHERE id = ?"
  ).bind(id).run();
  
  if (result.success) {
    return c.json({ success: true });
  } else {
    return c.json({ error: "Failed to delete user" }, 500);
  }
});

// Authenticate user (for login)
app.post("/api/usuarios/auth", async (c) => {
  try {
    console.log('🔑 LOGIN: Starting authentication process...');
    const { email, senha } = await c.req.json();
    console.log('🔑 LOGIN: Received credentials for:', email);
    
    if (!email || !senha) {
      console.log('🔑 LOGIN: Missing email or password');
      return c.json({ error: "Email e senha são obrigatórios" }, 400);
    }
    
    const user = await c.env.DB.prepare(`
      SELECT id, nome, email, tipo, ativo
      FROM usuarios 
      WHERE email = ? AND senha_hash = ? AND ativo = 1
    `).bind(email, senha).first(); // In production, compare hashed passwords
    
    console.log('🔑 LOGIN: Database query result:', user ? 'User found' : 'User not found');
    
    if (user) {
      const userData = {
        id: user.id,
        name: user.nome,
        email: user.email,
        tipo: user.tipo
      };
      
      console.log('🔑 LOGIN: Creating session for user:', userData.id);
      
      // Ensure user has a valid license
      const existingLicense = await c.env.DB.prepare(`
        SELECT * FROM licencas 
        WHERE usuario_id = ? AND status = 'ativa' AND (data_fim >= date('now') OR plano = 'Vitalício')
        ORDER BY data_fim DESC
        LIMIT 1
      `).bind(user.id).first();
      
      if (!existingLicense) {
        console.log('🔧 LOGIN: Creating license for user during login:', user.id);
        const today = new Date().toISOString().split('T')[0];
        const oneYearFromNow = new Date();
        oneYearFromNow.setFullYear(oneYearFromNow.getFullYear() + 1);
        const futureDate = oneYearFromNow.toISOString().split('T')[0];
        
        await c.env.DB.prepare(`
          INSERT INTO licencas (usuario_id, plano, data_inicio, data_fim, status, observacoes)
          VALUES (?, ?, ?, ?, ?, ?)
        `).bind(
          user.id,
          'Vitalício',
          today,
          futureDate,
          'ativa',
          'Licença criada automaticamente no login'
        ).run();
        
        console.log('✅ LOGIN: License created for user:', user.id);
      }
      
      // Set cookies for authentication
      const sessionData = JSON.stringify(userData);
      const encodedUserData = encodeURIComponent(sessionData);
      
      console.log('🔑 LOGIN: Encoded user data length:', encodedUserData.length);
      
      // Create response
      const response = c.json({ 
        success: true, 
        user: userData
      });
      
      // Set multiple cookie headers
      const cookieOptions = `Path=/; Max-Age=${7 * 24 * 60 * 60}; SameSite=Lax`;
      
      // Try setting both cookies in different ways
      c.header('Set-Cookie', `user_session=${encodedUserData}; ${cookieOptions}`);
      
      // Add second cookie header (some implementations support multiple Set-Cookie headers)
      if (c.req.raw.headers.get('Set-Cookie')) {
        c.req.raw.headers.append('Set-Cookie', `maxifinancas_user=${encodedUserData}; ${cookieOptions}`);
      } else {
        c.header('Set-Cookie', `maxifinancas_user=${encodedUserData}; ${cookieOptions}`);
      }
      
      console.log('🍪 LOGIN: Set cookies with options:', cookieOptions);
      console.log('🍪 LOGIN: Session established for user:', user.id);
      
      return response;
    } else {
      console.log('🔑 LOGIN: Invalid credentials for:', email);
      return c.json({ error: "Credenciais inválidas" }, 401);
    }
  } catch (error) {
    console.error("🔑 LOGIN: Error authenticating user:", error);
    return c.json({ error: "Erro interno do servidor" }, 500);
  }
});

// Repair orphaned records endpoint
app.post("/api/repair-orphaned-records", customAuthMiddleware, async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ error: "User not authenticated" }, 401);
    }

    console.log(`🔧 REPAIR: Starting orphaned records repair for user: ${user.id}`);

    // Find and fix orphaned fixed accounts
    const orphanedFixedAccounts = await c.env.DB.prepare(
      "SELECT COUNT(*) as count FROM fixed_accounts WHERE user_id IS NULL OR user_id = ''"
    ).first();

    let fixedAccountsRepaired = 0;
    if (orphanedFixedAccounts && (orphanedFixedAccounts.count as number) > 0) {
      console.log(`🔧 REPAIR: Found ${orphanedFixedAccounts.count} orphaned fixed accounts`);
      
      const fixResult = await c.env.DB.prepare(
        "UPDATE fixed_accounts SET user_id = ? WHERE user_id IS NULL OR user_id = ''"
      ).bind(user.id).run();
      
      fixedAccountsRepaired = fixResult.meta?.changes || 0;
      console.log(`🔧 REPAIR: Fixed ${fixedAccountsRepaired} fixed accounts`);
    }

    // Find and fix orphaned variable accounts
    const orphanedVariableAccounts = await c.env.DB.prepare(
      "SELECT COUNT(*) as count FROM variable_accounts WHERE user_id IS NULL OR user_id = ''"
    ).first();

    let variableAccountsRepaired = 0;
    if (orphanedVariableAccounts && (orphanedVariableAccounts.count as number) > 0) {
      console.log(`🔧 REPAIR: Found ${orphanedVariableAccounts.count} orphaned variable accounts`);
      
      const fixResult = await c.env.DB.prepare(
        "UPDATE variable_accounts SET user_id = ? WHERE user_id IS NULL OR user_id = ''"
      ).bind(user.id).run();
      
      variableAccountsRepaired = fixResult.meta?.changes || 0;
      console.log(`🔧 REPAIR: Fixed ${variableAccountsRepaired} variable accounts`);
    }

    // Fix other types as well
    const tables = ['transactions', 'payroll', 'accounts_receivable', 'categories', 'cost_centers'];
    const results: any = {};

    for (const table of tables) {
      const orphanedCount = await c.env.DB.prepare(
        `SELECT COUNT(*) as count FROM ${table} WHERE user_id IS NULL OR user_id = ''`
      ).first();

      if (orphanedCount && (orphanedCount.count as number) > 0) {
        console.log(`🔧 REPAIR: Found ${orphanedCount.count} orphaned records in ${table}`);
        
        const fixResult = await c.env.DB.prepare(
          `UPDATE ${table} SET user_id = ? WHERE user_id IS NULL OR user_id = ''`
        ).bind(user.id).run();
        
        results[table] = fixResult.meta?.changes || 0;
        console.log(`🔧 REPAIR: Fixed ${results[table]} records in ${table}`);
      } else {
        results[table] = 0;
      }
    }

    return c.json({
      success: true,
      message: "Registros órfãos reparados com sucesso",
      repaired: {
        fixed_accounts: fixedAccountsRepaired,
        variable_accounts: variableAccountsRepaired,
        ...results
      },
      userId: user.id
    });

  } catch (error) {
    console.error("🔧 REPAIR: Error repairing orphaned records:", error);
    return c.json({ 
      success: false, 
      error: "Erro ao reparar registros órfãos",
      details: error instanceof Error ? error.message : 'Unknown error'
    }, 500);
  }
});

// Get dashboard summary
app.get("/api/dashboard", customAuthMiddleware, async (c) => {
  const user = c.get("user");
  
  const totalBalance = await c.env.DB.prepare(
    "SELECT COALESCE(SUM(amount), 0) as balance FROM transactions WHERE (status = 'PAGO' OR status = 'RECEBIDO') AND user_id = ?"
  ).bind(user!.id).first();
  
  const fixedAccountsPending = await c.env.DB.prepare(`
    SELECT COALESCE(SUM(ABS(amount)), 0) as total
    FROM fixed_accounts 
    WHERE (status = 'NÃO PAGO' OR status IS NULL) AND user_id = ?
  `).bind(user!.id).first();
  
  // Variable accounts pending - Only current month with status "NÃO PAGO"
  const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM format
  console.log(`🔍 DASHBOARD: Calculando contas não fixas do mês vigente (${currentMonth}) com status NÃO PAGO`);
  
  const variableAccountsPending = await c.env.DB.prepare(`
    SELECT COALESCE(SUM(ABS(amount)), 0) as total
    FROM variable_accounts 
    WHERE status = 'NÃO PAGO' AND strftime('%Y-%m', due_date) = ? AND user_id = ?
  `).bind(currentMonth, user!.id).first();
  
  console.log(`💰 DASHBOARD: Valor calculado das contas não fixas em aberto do mês vigente: ${variableAccountsPending?.total || 0}`);
  
  const payrollPending = await c.env.DB.prepare(`
    SELECT COALESCE(SUM(ABS(amount)), 0) as total
    FROM payroll 
    WHERE (status = 'NÃO PAGO' OR status IS NULL) AND user_id = ?
  `).bind(user!.id).first();

  // Next month data - Fixed accounts for next month (based on due_day)
  const nextMonth = new Date();
  nextMonth.setMonth(nextMonth.getMonth() + 1);
  const nextMonthStr = nextMonth.toISOString().slice(0, 7); // YYYY-MM format
  
  // Fixed accounts for next month - considering all active accounts regardless of status
  const fixedAccountsNextMonth = await c.env.DB.prepare(`
    SELECT COALESCE(SUM(ABS(amount)), 0) as total
    FROM fixed_accounts 
    WHERE is_active = 1 AND user_id = ?
  `).bind(user!.id).first();
  
  // Variable accounts for next month - considering all accounts regardless of status
  const variableAccountsNextMonth = await c.env.DB.prepare(`
    SELECT COALESCE(SUM(ABS(amount)), 0) as total
    FROM variable_accounts 
    WHERE strftime('%Y-%m', due_date) = ? AND user_id = ?
  `).bind(nextMonthStr, user!.id).first();
  
  // Payroll for next month - considering all items regardless of status
  const payrollNextMonth = await c.env.DB.prepare(`
    SELECT COALESCE(SUM(ABS(amount)), 0) as total
    FROM payroll
    WHERE user_id = ?
  `).bind(user!.id).first();
  
  // Company cost next month (sum of all next month expenses)
  const companyCostNextMonth = (fixedAccountsNextMonth?.total as number || 0) + 
                               (variableAccountsNextMonth?.total as number || 0) + 
                               (payrollNextMonth?.total as number || 0);
  
  const categoryBreakdown = await c.env.DB.prepare(`
    SELECT 
      c.name,
      COALESCE(SUM(t.amount), 0) as total,
      COUNT(t.id) as count
    FROM categories c
    LEFT JOIN transactions t ON c.id = t.category_id 
      AND t.date >= date('now', 'start of month')
      AND t.user_id = ?
    WHERE c.user_id = ?
    GROUP BY c.id, c.name
    ORDER BY total ASC
  `).bind(user!.id, user!.id).all();

  // Monthly income vs expenses for chart (last 6 months)
  const monthlyData = await c.env.DB.prepare(`
    SELECT 
      strftime('%Y-%m', date) as month,
      COALESCE(SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END), 0) as receitas,
      COALESCE(SUM(CASE WHEN amount < 0 THEN ABS(amount) ELSE 0 END), 0) as despesas
    FROM transactions 
    WHERE date >= date('now', '-6 months', 'start of month')
      AND (status = 'PAGO' OR status = 'RECEBIDO')
      AND user_id = ?
    GROUP BY strftime('%Y-%m', date)
    ORDER BY month ASC
  `).bind(user!.id).all();
  
  return c.json({
    balance: totalBalance?.balance || 0,
    fixed_accounts_pending: fixedAccountsPending?.total || 0,
    variable_accounts_pending: variableAccountsPending?.total || 0,
    payroll_pending: payrollPending?.total || 0,
    fixed_accounts_next_month: fixedAccountsNextMonth?.total || 0,
    variable_accounts_next_month: variableAccountsNextMonth?.total || 0,
    payroll_next_month: payrollNextMonth?.total || 0,
    company_cost_next_month: companyCostNextMonth,
    category_breakdown: categoryBreakdown.results || [],
    monthly_data: monthlyData.results || []
  });
});

// Serve static files or handle all requests
app.get("*", async (c) => {
  return c.text("Maxi Finanças API", 200);
});

// Export handler for Cloudflare Workers
export default app;
