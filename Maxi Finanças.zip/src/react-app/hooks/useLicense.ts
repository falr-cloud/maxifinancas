import { useState, useEffect } from 'react';

interface LicenseInfo {
  isValid: boolean;
  license: any;
  daysUntilExpiry: number;
  message: string;
}

interface UseLicenseReturn {
  licenseInfo: LicenseInfo | null;
  loading: boolean;
  checkLicense: () => void;
}

export const useLicense = (userId?: string): UseLicenseReturn => {
  const [licenseInfo, setLicenseInfo] = useState<LicenseInfo | null>(null);
  const [loading, setLoading] = useState(true);

  const checkLicense = async () => {
    // Get user from localStorage if userId not provided
    const currentUserId = userId || (() => {
      try {
        const userSession = localStorage.getItem('user_session');
        if (userSession) {
          const user = JSON.parse(userSession);
          return user.id;
        }
        return 'default-user';
      } catch {
        return 'default-user';
      }
    })();
    
    if (!currentUserId) return;
    
    setLoading(true);
    try {
      const response = await fetch(`/api/licenses/check/${currentUserId}`);
      const data = await response.json();
      setLicenseInfo(data);
    } catch (error) {
      console.error('Error checking license:', error);
      setLicenseInfo({
        isValid: false,
        license: null,
        daysUntilExpiry: 0,
        message: 'Erro ao verificar licença. Entre em contato com o suporte.'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    checkLicense();
  }, [userId]);

  return {
    licenseInfo,
    loading,
    checkLicense
  };
};

// Hook para verificar se um plano tem acesso a uma funcionalidade específica
export const usePlanAccess = (requiredPlan: string = 'Básico', userId?: string) => {
  const { licenseInfo } = useLicense(userId);
  
  const planHierarchy = ['Básico', 'Pro', 'Premium', 'Vitalício'];
  const userPlanIndex = licenseInfo?.license ? planHierarchy.indexOf(licenseInfo.license.plano) : -1;
  const requiredPlanIndex = planHierarchy.indexOf(requiredPlan);
  
  // Licenças vitalícias têm acesso a tudo
  const hasAccess = licenseInfo?.isValid && (
    licenseInfo.license?.plano === 'Vitalício' || userPlanIndex >= requiredPlanIndex
  );
  
  return {
    hasAccess,
    userPlan: licenseInfo?.license?.plano || null,
    requiredPlan,
    licenseValid: licenseInfo?.isValid || false
  };
};
