import { ReactNode } from 'react';
import { Shield, Star, Crown, Lock } from 'lucide-react';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { usePlanAccess } from '@/react-app/hooks/useLicense';

interface PlanRestrictionProps {
  children: ReactNode;
  requiredPlan: 'Básico' | 'Pro' | 'Premium';
  feature?: string;
}

export default function PlanRestriction({ 
  children, 
  requiredPlan, 
  feature = 'funcionalidade' 
}: PlanRestrictionProps) {
  const { user } = useAuth();
  const { hasAccess, userPlan, licenseValid } = usePlanAccess(requiredPlan, user?.id);

  if (!licenseValid) {
    return null; // LicenseGuard will handle invalid licenses
  }

  if (hasAccess) {
    return <>{children}</>;
  }

  const getPlanIcon = (plan: string) => {
    switch (plan) {
      case 'Básico': return <Shield className="w-5 h-5" />;
      case 'Pro': return <Star className="w-5 h-5" />;
      case 'Premium': return <Crown className="w-5 h-5" />;
      case 'Vitalício': return <Crown className="w-5 h-5" />;
      default: return <Lock className="w-5 h-5" />;
    }
  };

  const getPlanColor = (plan: string) => {
    switch (plan) {
      case 'Básico': return 'from-blue-500 to-blue-600';
      case 'Pro': return 'from-purple-500 to-purple-600';
      case 'Premium': return 'from-amber-500 to-amber-600';
      case 'Vitalício': return 'from-yellow-500 to-amber-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  return (
    <div className="relative">
      {/* Blurred Content */}
      <div className="filter blur-sm pointer-events-none opacity-50">
        {children}
      </div>
      
      {/* Overlay */}
      <div className="absolute inset-0 flex items-center justify-center bg-white/80 backdrop-blur-sm">
        <div className="bg-white rounded-2xl shadow-xl border border-slate-200/50 p-6 max-w-sm text-center">
          <div className={`w-16 h-16 bg-gradient-to-br ${getPlanColor(requiredPlan)} rounded-full flex items-center justify-center mx-auto mb-4`}>
            {getPlanIcon(requiredPlan)}
            <div className="text-white">
              {getPlanIcon(requiredPlan)}
            </div>
          </div>
          
          <h3 className="text-xl font-bold text-slate-800 mb-2">
            Upgrade Necessário
          </h3>
          
          <p className="text-slate-600 mb-4">
            Esta {feature} requer o plano <strong>{requiredPlan}</strong> ou superior.
          </p>
          
          <div className="bg-slate-50 rounded-lg p-3 mb-4">
            <div className="text-sm text-slate-600">
              <div className="flex justify-between items-center">
                <span>Seu plano atual:</span>
                <span className="font-medium flex items-center gap-1">
                  {getPlanIcon(userPlan || 'Básico')}
                  {userPlan || 'Nenhum'}
                </span>
              </div>
              <div className="flex justify-between items-center mt-1">
                <span>Plano necessário:</span>
                <span className="font-medium flex items-center gap-1 text-amber-600">
                  {getPlanIcon(requiredPlan)}
                  {requiredPlan}
                </span>
              </div>
            </div>
          </div>
          
          <div className="space-y-2">
            <button className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-2 px-4 rounded-lg font-medium hover:from-blue-700 hover:to-blue-800 transition-all duration-200">
              Fazer Upgrade
            </button>
            <button className="w-full text-slate-600 hover:text-slate-800 text-sm transition-colors">
              Falar com Suporte
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
