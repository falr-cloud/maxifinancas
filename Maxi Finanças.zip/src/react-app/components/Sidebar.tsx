import { Link, useLocation } from "react-router";
import { 
  Home, 
  Receipt, 
  CreditCard, 
  Building2, 
  BarChart3, 
  Settings,
  DollarSign,
  Users,
  TrendingUp,
  Shield,
  LogOut,
  User
} from "lucide-react";
import { useAuth } from "@/react-app/contexts/AuthContext";

const navigation = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "Transações", href: "/transactions", icon: Receipt },
  { name: "Contas a Receber", href: "/accounts-receivable", icon: TrendingUp },
  { name: "Contas Fixas", href: "/fixed-accounts", icon: CreditCard },
  { name: "Contas não Fixas", href: "/variable-accounts", icon: Building2 },
  { name: "Folha de pagamento", href: "/payroll", icon: Users },
  { name: "Relatórios", href: "/reports", icon: BarChart3 },
  { name: "Configurações", href: "/settings", icon: Settings },
];

export default function Sidebar() {
  const location = useLocation();
  const { user, logout } = useAuth();

  const handleLogout = () => {
    if (confirm('Tem certeza que deseja sair do sistema?')) {
      logout();
    }
  };

  return (
    <div className="flex flex-col h-full bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 border-r border-slate-700/50">
      {/* Logo */}
      <div className="flex items-center gap-3 px-6 py-6 border-b border-slate-700/50">
        <div className="flex items-center justify-center w-10 h-10 bg-gradient-to-br from-emerald-400 to-cyan-400 rounded-xl shadow-lg">
          <DollarSign className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
            Maxi Finanças
          </h1>
          <p className="text-xs text-slate-400">Gestão Financeira</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-6 space-y-2">
        {navigation.map((item) => {
          const isActive = location.pathname === item.href;
          const Icon = item.icon;
          
          return (
            <Link
              key={item.name}
              to={item.href}
              className={`
                flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200
                ${isActive 
                  ? 'bg-gradient-to-r from-emerald-500/20 to-cyan-500/20 text-emerald-400 border border-emerald-500/30 shadow-lg shadow-emerald-500/10' 
                  : 'text-slate-300 hover:text-emerald-400 hover:bg-slate-800/50'
                }
              `}
            >
              <Icon className="w-5 h-5" />
              {item.name}
            </Link>
          );
        })}
      </nav>

      {/* Admin Section - Only for admin users */}
      {user?.tipo === 'admin' && (
        <div className="px-4 py-4 border-t border-slate-700/50">
          <div className="mb-4">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Administração
            </h3>
            <div className="space-y-2">
              <Link
                to="/admin/users"
                className={`
                  flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200
                  ${location.pathname === '/admin/users' 
                    ? 'bg-gradient-to-r from-blue-500/20 to-blue-600/20 text-blue-400 border border-blue-500/30 shadow-lg shadow-blue-500/10' 
                    : 'text-slate-300 hover:text-blue-400 hover:bg-slate-800/50'
                  }
                `}
              >
                <User className="w-5 h-5" />
                Usuários
              </Link>
              <Link
                to="/admin/licenses"
                className={`
                  flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200
                  ${location.pathname === '/admin/licenses' 
                    ? 'bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-400 border border-amber-500/30 shadow-lg shadow-amber-500/10' 
                    : 'text-slate-300 hover:text-amber-400 hover:bg-slate-800/50'
                  }
                `}
              >
                <Shield className="w-5 h-5" />
                Licenças
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* User Info and Logout */}
      <div className="px-4 py-4 border-t border-slate-700/50 space-y-4">
        {/* User Info */}
        <div className="flex items-center gap-3 px-4 py-3 bg-slate-800/50 rounded-xl">
          <div className="w-8 h-8 bg-gradient-to-br from-emerald-400 to-cyan-400 rounded-lg flex items-center justify-center">
            <User className="w-4 h-4 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">{user?.name || user?.email}</p>
            <p className="text-xs text-slate-400 truncate">{user?.email}</p>
          </div>
        </div>

        {/* Logout Button */}
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-4 py-3 text-slate-300 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-all duration-200 group"
        >
          <LogOut className="w-5 h-5 group-hover:scale-110 transition-transform" />
          <span className="text-sm font-medium">Sair do Sistema</span>
        </button>

        {/* Footer */}
        <div className="text-xs text-slate-500 text-center pt-2 border-t border-slate-700/30">
          © 2025 Maxi Finanças
        </div>
      </div>
    </div>
  );
}
