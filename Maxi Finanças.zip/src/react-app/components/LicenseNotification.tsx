import { useLicense } from '@/react-app/hooks/useLicense';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { AlertTriangle, Clock, X } from 'lucide-react';
import { useState } from 'react';

interface LicenseNotificationProps {}

export default function LicenseNotification({}: LicenseNotificationProps) {
  const { user } = useAuth();
  const userId = user?.id || 'default-user';
  const { licenseInfo } = useLicense(userId);
  const [dismissed, setDismissed] = useState(false);

  // Não mostrar se foi dispensado, não há licença, licença é vitalícia, ou licença é válida e não está próxima do vencimento
  if (dismissed || !licenseInfo?.isValid || licenseInfo?.license?.plano === 'Vitalício' || licenseInfo.daysUntilExpiry > 7) {
    return null;
  }

  const daysUntilExpiry = licenseInfo.daysUntilExpiry;
  const isUrgent = daysUntilExpiry <= 3;

  return (
    <div className={`mb-6 rounded-xl border-2 p-4 ${
      isUrgent 
        ? 'bg-red-50 border-red-200 text-red-800' 
        : 'bg-amber-50 border-amber-200 text-amber-800'
    }`}>
      <div className="flex items-start gap-3">
        <div className={`flex-shrink-0 w-6 h-6 ${isUrgent ? 'text-red-600' : 'text-amber-600'}`}>
          {isUrgent ? <AlertTriangle className="w-6 h-6" /> : <Clock className="w-6 h-6" />}
        </div>
        
        <div className="flex-1">
          <h4 className="font-semibold mb-1">
            {isUrgent ? 'Licença Expirando Urgente!' : 'Licença Próxima do Vencimento'}
          </h4>
          <p className="text-sm mb-3">
            Sua licença do plano <strong>{licenseInfo.license?.plano}</strong> expira em{' '}
            <strong>{daysUntilExpiry} dia{daysUntilExpiry !== 1 ? 's' : ''}</strong>.
            {isUrgent && ' Renove agora para evitar interrupção do serviço.'}
          </p>
          
          <div className="flex flex-wrap gap-2">
            <button 
              onClick={() => window.location.href = 'mailto:suporte@maxifinancas.com?subject=Renovação de Licença'}
              className={`text-xs px-3 py-1 rounded-lg font-medium transition-all ${
                isUrgent
                  ? 'bg-red-600 text-white hover:bg-red-700'
                  : 'bg-amber-600 text-white hover:bg-amber-700'
              }`}
            >
              Renovar Licença
            </button>
            <button 
              onClick={() => window.location.href = 'mailto:suporte@maxifinancas.com?subject=Suporte Técnico'}
              className="text-xs px-3 py-1 rounded-lg border border-current hover:bg-current hover:text-white transition-all"
            >
              Falar com Suporte
            </button>
          </div>
        </div>
        
        <button 
          onClick={() => setDismissed(true)}
          className="flex-shrink-0 p-1 hover:bg-black/10 rounded-lg transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
