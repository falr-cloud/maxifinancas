import { ReactNode } from 'react';
import { useLicense } from '@/react-app/hooks/useLicense';
import { useAuth } from '@/react-app/contexts/AuthContext';
import { Shield, AlertTriangle, Crown } from 'lucide-react';

interface LicenseGuardProps {
  children: ReactNode;
}

export default function LicenseGuard({ children }: LicenseGuardProps) {
  const { user, isPending } = useAuth();
  
  // Don't check license if user is not authenticated or auth is still pending
  if (isPending || !user) {
    return <>{children}</>;
  }
  
  const userId = user.id;
  const { licenseInfo, loading } = useLicense(userId);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-slate-600">Verificando licença...</p>
        </div>
      </div>
    );
  }

  // Se não há licença válida, mostrar tela de bloqueio
  if (!licenseInfo?.isValid) {
    const daysUntilExpiry = licenseInfo?.daysUntilExpiry || 0;
    const isExpired = daysUntilExpiry <= 0;
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-red-100 flex items-center justify-center p-4">
        <div className="max-w-2xl mx-auto text-center">
          <div className="bg-white rounded-3xl shadow-2xl p-8 border border-red-200/50">
            {/* Icon */}
            <div className="w-24 h-24 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
              {isExpired ? (
                <AlertTriangle className="w-12 h-12 text-white" />
              ) : (
                <Shield className="w-12 h-12 text-white" />
              )}
            </div>

            {/* Title */}
            <h1 className="text-3xl font-bold text-slate-800 mb-4">
              {isExpired ? 'Licença Expirada' : 'Licença Necessária'}
            </h1>

            {/* Message */}
            <p className="text-lg text-slate-600 mb-6">
              {licenseInfo?.message || 'Você precisa de uma licença válida para acessar o sistema.'}
            </p>

            {/* License Details */}
            {licenseInfo?.license && (
              <div className="bg-red-50 rounded-xl p-6 mb-6 border border-red-200">
                <h3 className="text-lg font-semibold text-red-800 mb-3 flex items-center gap-2">
                  <Crown className="w-5 h-5" />
                  Detalhes da Licença
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-red-700">Plano:</span>
                    <span className="font-medium text-red-800">{licenseInfo.license.plano}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-red-700">Data de Expiração:</span>
                    <span className="font-medium text-red-800">
                      {new Date(licenseInfo.license.data_fim).toLocaleDateString('pt-BR')}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-red-700">Status:</span>
                    <span className={`font-medium ${isExpired ? 'text-red-800' : 'text-amber-600'}`}>
                      {isExpired ? 'Expirada' : `Expira em ${daysUntilExpiry} dias`}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="space-y-4">
              <button 
                onClick={() => window.location.href = 'mailto:suporte@maxifinancas.com?subject=Renovação de Licença'}
                className="w-full bg-gradient-to-r from-emerald-600 to-emerald-700 text-white py-3 px-6 rounded-xl font-semibold hover:from-emerald-700 hover:to-emerald-800 transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                Renovar Licença
              </button>
              
              <button 
                onClick={() => window.location.href = 'mailto:suporte@maxifinancas.com?subject=Suporte Técnico'}
                className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-700 hover:to-blue-800 transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                Falar com Suporte
              </button>

              <button 
                onClick={() => {
                  localStorage.removeItem('maxifinancas_user');
                  window.location.href = '/login';
                }}
                className="w-full text-slate-600 hover:text-slate-800 py-2 px-4 text-sm transition-colors"
              >
                Voltar ao Login
              </button>
            </div>

            {/* Footer */}
            <div className="mt-8 pt-6 border-t border-red-200">
              <p className="text-xs text-slate-500">
                Para questões sobre licenciamento, entre em contato com nossa equipe de suporte.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Se tem licença válida mas está próxima do vencimento, mostrar apenas as crianças
  return <>{children}</>;
}
