import { ReactNode } from "react";
import Sidebar from "@/react-app/components/Sidebar";
import LicenseGuard from "@/react-app/components/LicenseGuard";
import LicenseNotification from "@/react-app/components/LicenseNotification";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <LicenseGuard>
      <div className="flex h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
        {/* Sidebar */}
        <div className="w-64 flex-shrink-0">
          <Sidebar />
        </div>
        
        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          <div className="min-h-full">
            <div className="p-8 pb-0">
              <LicenseNotification />
            </div>
            <div className="px-8">
              {children}
            </div>
          </div>
        </main>
      </div>
    </LicenseGuard>
  );
}
