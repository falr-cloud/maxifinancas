import { useEffect, useState } from "react";
import { Plus, Trash2, Edit3, Save, X, User, Eye, EyeOff, Users, Shield } from "lucide-react";

interface Usuario {
  id: string;
  nome: string;
  email: string;
  tipo: string;
  ativo: number;
  created_at: string;
  updated_at: string;
}

interface CreateUser {
  nome: string;
  email: string;
  senha: string;
  tipo: string;
  ativo: boolean;
}

interface EditingUser extends CreateUser {
  id?: string;
}

interface UserStats {
  total: number;
  ativos: number;
  inativos: number;
  admins: number;
}

export default function UserManagement() {
  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [stats, setStats] = useState<UserStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingUser, setEditingUser] = useState<EditingUser | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [newUser, setNewUser] = useState<CreateUser>({
    nome: '',
    email: '',
    senha: '',
    tipo: 'usuario',
    ativo: true
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [usuariosRes, statsRes] = await Promise.all([
        fetch("/api/usuarios"),
        fetch("/api/usuarios/stats")
      ]);

      const [usuariosData, statsData] = await Promise.all([
        usuariosRes.json(),
        statsRes.json()
      ]);

      setUsuarios(usuariosData);
      setStats(statsData);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateUser = async () => {
    try {
      const response = await fetch("/api/usuarios", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newUser)
      });

      if (response.ok) {
        setShowModal(false);
        setNewUser({
          nome: '',
          email: '',
          senha: '',
          tipo: 'usuario',
          ativo: true
        });
        fetchData();
      }
    } catch (error) {
      console.error("Error creating user:", error);
    }
  };

  const handleUpdateUser = async (id: string) => {
    if (!editingUser) return;

    try {
      const response = await fetch(`/api/usuarios/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editingUser)
      });

      if (response.ok) {
        setEditingUser(null);
        fetchData();
      }
    } catch (error) {
      console.error("Error updating user:", error);
    }
  };

  const handleDeleteUser = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir este usuário?")) return;

    try {
      const response = await fetch(`/api/usuarios/${id}`, {
        method: "DELETE"
      });

      if (response.ok) {
        fetchData();
      }
    } catch (error) {
      console.error("Error deleting user:", error);
    }
  };

  const generateRandomPassword = () => {
    const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
    let result = '';
    for (let i = 0; i < 8; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  };

  const handleGeneratePassword = () => {
    const newPassword = generateRandomPassword();
    if (editingUser) {
      setEditingUser({...editingUser, senha: newPassword});
    } else {
      setNewUser({...newUser, senha: newPassword});
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800 mb-2">Gerenciamento de Usuários</h1>
        <p className="text-slate-600">Administre os usuários e suas credenciais de acesso</p>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl">
                <Users className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-medium text-slate-500">Total</span>
            </div>
            <div className="text-2xl font-bold text-slate-800">{stats.total}</div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl">
                <User className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-medium text-slate-500">Ativos</span>
            </div>
            <div className="text-2xl font-bold text-emerald-600">{stats.ativos}</div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-red-500 to-red-600 rounded-xl">
                <X className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-medium text-slate-500">Inativos</span>
            </div>
            <div className="text-2xl font-bold text-red-600">{stats.inativos}</div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-medium text-slate-500">Admins</span>
            </div>
            <div className="text-2xl font-bold text-purple-600">{stats.admins}</div>
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex justify-end mb-6">
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl hover:shadow-lg transition-all font-medium"
        >
          <Plus className="w-4 h-4" />
          Novo Usuário
        </button>
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-200/50 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200/50">
          <h2 className="text-xl font-semibold text-slate-800">Lista de Usuários</h2>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200/50">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700 min-w-[150px]">Nome</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700 min-w-[200px]">Email</th>
                <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700 min-w-[120px]">Tipo</th>
                <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700 min-w-[80px]">Status</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700 min-w-[120px]">Criado em</th>
                <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700 min-w-[100px]">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/50">
              {usuarios.map((usuario) => (
                <tr key={usuario.id} className="hover:bg-slate-50/50 transition-colors">
                  {editingUser?.id === usuario.id ? (
                    // Edit mode
                    <>
                      <td className="px-6 py-4">
                        <input
                          type="text"
                          value={editingUser.nome || ''}
                          onChange={(e) => setEditingUser({...editingUser, nome: e.target.value})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <input
                          type="email"
                          value={editingUser.email || ''}
                          onChange={(e) => setEditingUser({...editingUser, email: e.target.value})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <select
                          value={editingUser.tipo || ''}
                          onChange={(e) => setEditingUser({...editingUser, tipo: e.target.value})}
                          className="min-w-[120px] w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                        >
                          <option value="usuario">Usuário</option>
                          <option value="admin">Administrador</option>
                        </select>
                      </td>
                      <td className="px-6 py-4">
                        <select
                          value={editingUser.ativo ? 'true' : 'false'}
                          onChange={(e) => setEditingUser({...editingUser, ativo: e.target.value === 'true'})}
                          className="min-w-[100px] w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                        >
                          <option value="true">Ativo</option>
                          <option value="false">Inativo</option>
                        </select>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <input
                            type={showPassword ? "text" : "password"}
                            value={editingUser.senha || ''}
                            onChange={(e) => setEditingUser({...editingUser, senha: e.target.value})}
                            className="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                            placeholder="Nova senha"
                          />
                          <button
                            onClick={() => setShowPassword(!showPassword)}
                            className="p-2 text-slate-400 hover:text-slate-600"
                          >
                            {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                          <button
                            onClick={handleGeneratePassword}
                            className="px-3 py-2 text-xs bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
                          >
                            Gerar
                          </button>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2 justify-center">
                          <button
                            onClick={() => handleUpdateUser(usuario.id)}
                            className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                          >
                            <Save className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setEditingUser(null)}
                            className="p-2 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </>
                  ) : (
                    // View mode
                    <>
                      <td className="px-6 py-4">
                        <div>
                          <div className="text-sm font-medium text-slate-800">{usuario.nome}</div>
                          <div className="text-xs text-slate-500 font-mono bg-slate-50 px-2 py-1 rounded mt-1">
                            ID: {usuario.id}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {usuario.email}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        <div className="min-w-[100px] flex justify-center">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium whitespace-nowrap ${
                            usuario.tipo === 'admin' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'
                          }`}>
                            {usuario.tipo === 'admin' ? 'Administrador' : 'Usuário'}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="min-w-[80px] flex justify-center">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium whitespace-nowrap ${
                            usuario.ativo ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {usuario.ativo ? 'Ativo' : 'Inativo'}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {new Date(usuario.created_at).toLocaleDateString('pt-BR')}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2 justify-center">
                          <button
                            onClick={() => setEditingUser({
                              id: usuario.id,
                              nome: usuario.nome,
                              email: usuario.email,
                              tipo: usuario.tipo,
                              ativo: !!usuario.ativo,
                              senha: ''
                            })}
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteUser(usuario.id)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {usuarios.length === 0 && (
          <div className="text-center py-12">
            <User className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-600 mb-2">Nenhum usuário encontrado</h3>
            <p className="text-slate-500">Crie o primeiro usuário para começar</p>
          </div>
        )}
      </div>

      {/* Create User Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-200/50">
              <h3 className="text-xl font-semibold text-slate-800">Novo Usuário</h3>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Nome Completo</label>
                <input
                  type="text"
                  value={newUser.nome}
                  onChange={(e) => setNewUser({...newUser, nome: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Nome do usuário"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Email</label>
                <input
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser({...newUser, email: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="email@exemplo.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Senha</label>
                <div className="flex gap-2">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={newUser.senha}
                    onChange={(e) => setNewUser({...newUser, senha: e.target.value})}
                    className="flex-1 px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Senha do usuário"
                  />
                  <button
                    onClick={() => setShowPassword(!showPassword)}
                    className="p-2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={handleGeneratePassword}
                    className="px-4 py-2 text-sm bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200"
                  >
                    Gerar
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Tipo</label>
                <select
                  value={newUser.tipo}
                  onChange={(e) => setNewUser({...newUser, tipo: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="usuario">Usuário</option>
                  <option value="admin">Administrador</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="ativo"
                  checked={newUser.ativo}
                  onChange={(e) => setNewUser({...newUser, ativo: e.target.checked})}
                  className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                />
                <label htmlFor="ativo" className="text-sm text-slate-700">Usuário ativo</label>
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleCreateUser}
                className="px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:shadow-lg transition-all"
              >
                Criar Usuário
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
