import { useEffect, useState } from "react";
import { Plus, Trash2, Edit3, Save, X, Shield, AlertTriangle, CheckCircle, XCircle, Clock, Search } from "lucide-react";
import { License, CreateLicense, UpdateLicense } from "@/shared/types";

interface LicenseStats {
  total: number;
  active: number;
  expired: number;
  suspended: number;
  expiringSoon: number;
}

interface EditingLicense extends UpdateLicense {
  id?: number;
}

interface Usuario {
  id: string;
  nome: string;
  email: string;
  tipo: string;
  ativo: number;
}

export default function LicenseManagement() {
  const [licenses, setLicenses] = useState<License[]>([]);
  const [stats, setStats] = useState<LicenseStats | null>(null);
  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingLicense, setEditingLicense] = useState<EditingLicense | null>(null);
  const [showUserSearch, setShowUserSearch] = useState(false);
  const [userSearchTerm, setUserSearchTerm] = useState('');
  const [newLicense, setNewLicense] = useState<CreateLicense>({
    usuario_id: '',
    plano: 'Básico',
    data_inicio: new Date().toISOString().split('T')[0],
    data_fim: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 30 days from now
    status: 'ativa',
    observacoes: ''
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [licensesRes, statsRes, usuariosRes] = await Promise.all([
        fetch("/api/licenses"),
        fetch("/api/licenses/stats"),
        fetch("/api/usuarios")
      ]);

      const [licensesData, statsData, usuariosData] = await Promise.all([
        licensesRes.json(),
        statsRes.json(),
        usuariosRes.json()
      ]);

      setLicenses(licensesData);
      setStats(statsData);
      setUsuarios(usuariosData);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateLicense = async () => {
    try {
      const response = await fetch("/api/licenses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newLicense)
      });

      if (response.ok) {
        setShowModal(false);
        setNewLicense({
          usuario_id: '',
          plano: 'Básico',
          data_inicio: new Date().toISOString().split('T')[0],
          data_fim: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          status: 'ativa',
          observacoes: ''
        });
        setShowUserSearch(false);
        setUserSearchTerm('');
        fetchData();
      }
    } catch (error) {
      console.error("Error creating license:", error);
    }
  };

  const handleUpdateLicense = async (id: number) => {
    if (!editingLicense) return;

    try {
      const response = await fetch(`/api/licenses/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editingLicense)
      });

      if (response.ok) {
        setEditingLicense(null);
        fetchData();
      }
    } catch (error) {
      console.error("Error updating license:", error);
    }
  };

  const handleDeleteLicense = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir esta licença?")) return;

    try {
      const response = await fetch(`/api/licenses/${id}`, {
        method: "DELETE"
      });

      if (response.ok) {
        fetchData();
      }
    } catch (error) {
      console.error("Error deleting license:", error);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ativa': return 'bg-emerald-100 text-emerald-800';
      case 'expirada': return 'bg-red-100 text-red-800';
      case 'suspensa': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'ativa': return <CheckCircle className="w-4 h-4" />;
      case 'expirada': return <XCircle className="w-4 h-4" />;
      case 'suspensa': return <Clock className="w-4 h-4" />;
      default: return null;
    }
  };

  const isExpired = (dataFim: string) => {
    return new Date(dataFim) < new Date();
  };

  const getDaysUntilExpiry = (dataFim: string) => {
    const diff = new Date(dataFim).getTime() - new Date().getTime();
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin w-8 h-8 border-4 border-amber-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800 mb-2">Gerenciamento de Licenças</h1>
        <p className="text-slate-600">Administre as licenças de usuários do sistema</p>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-medium text-slate-500">Total</span>
            </div>
            <div className="text-2xl font-bold text-slate-800">{stats.total}</div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl">
                <CheckCircle className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-medium text-slate-500">Ativas</span>
            </div>
            <div className="text-2xl font-bold text-emerald-600">{stats.active}</div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-red-500 to-red-600 rounded-xl">
                <XCircle className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-medium text-slate-500">Expiradas</span>
            </div>
            <div className="text-2xl font-bold text-red-600">{stats.expired}</div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-xl">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-medium text-slate-500">Suspensas</span>
            </div>
            <div className="text-2xl font-bold text-yellow-600">{stats.suspended}</div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl">
                <AlertTriangle className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-medium text-slate-500">Expirando</span>
            </div>
            <div className="text-2xl font-bold text-orange-600">{stats.expiringSoon}</div>
            <div className="text-xs text-slate-500 mt-1">Próximos 7 dias</div>
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex justify-end mb-6">
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-xl hover:shadow-lg transition-all font-medium"
        >
          <Plus className="w-4 h-4" />
          Nova Licença
        </button>
      </div>

      {/* Licenses Table */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-200/50 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200/50">
          <h2 className="text-xl font-semibold text-slate-800">Lista de Licenças</h2>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200/50">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700 min-w-[200px]">Usuário</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700 min-w-[120px]">Plano</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700 min-w-[110px]">Data Início</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700 min-w-[120px]">Data Fim</th>
                <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700 min-w-[100px]">Status</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700 min-w-[150px]">Observações</th>
                <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700 min-w-[100px]">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/50">
              {licenses.map((license) => (
                <tr key={license.id} className="hover:bg-slate-50/50 transition-colors">
                  {editingLicense?.id === license.id ? (
                    // Edit mode
                    <>
                      <td className="px-6 py-4">
                        <div className="relative">
                          <input
                            type="text"
                            value={editingLicense.usuario_id || ''}
                            onChange={(e) => setEditingLicense({...editingLicense, usuario_id: e.target.value})}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-sm"
                          />
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <select
                          value={editingLicense.plano || ''}
                          onChange={(e) => setEditingLicense({...editingLicense, plano: e.target.value})}
                          className="min-w-[120px] w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-sm"
                        >
                          <option value="Básico">Básico</option>
                          <option value="Pro">Pro</option>
                          <option value="Premium">Premium</option>
                          <option value="Vitalício">Vitalício</option>
                        </select>
                      </td>
                      <td className="px-6 py-4">
                        <input
                          type="date"
                          value={editingLicense.data_inicio || ''}
                          onChange={(e) => setEditingLicense({...editingLicense, data_inicio: e.target.value})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-sm"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <input
                          type="date"
                          value={editingLicense.data_fim || ''}
                          onChange={(e) => setEditingLicense({...editingLicense, data_fim: e.target.value})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-sm"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <select
                          value={editingLicense.status || ''}
                          onChange={(e) => setEditingLicense({...editingLicense, status: e.target.value})}
                          className="min-w-[120px] w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-sm"
                        >
                          <option value="ativa">Ativa</option>
                          <option value="suspensa">Suspensa</option>
                          <option value="expirada">Expirada</option>
                        </select>
                      </td>
                      <td className="px-6 py-4">
                        <input
                          type="text"
                          value={editingLicense.observacoes || ''}
                          onChange={(e) => setEditingLicense({...editingLicense, observacoes: e.target.value})}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-sm"
                          placeholder="Observações"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2 justify-center">
                          <button
                            onClick={() => handleUpdateLicense(license.id)}
                            className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                          >
                            <Save className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setEditingLicense(null)}
                            className="p-2 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </>
                  ) : (
                    // View mode
                    <>
                      <td className="px-6 py-4">
                        <div>
                          <div className="text-sm font-medium text-slate-800">
                            {usuarios.find(u => u.id === license.usuario_id)?.nome || license.usuario_id}
                          </div>
                          <div className="text-xs text-slate-500">
                            {usuarios.find(u => u.id === license.usuario_id)?.email || 'Email não encontrado'}
                          </div>
                          <div className="text-xs font-mono text-slate-400">ID: {license.usuario_id}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        <div className="min-w-[100px]">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium whitespace-nowrap ${
                            license.plano === 'Vitalício' 
                              ? 'bg-gradient-to-r from-yellow-100 to-amber-100 text-amber-800 border border-amber-200' 
                              : 'bg-blue-100 text-blue-800'
                          }`}>
                            {license.plano === 'Vitalício' && '✨ '}
                            {license.plano}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {formatDate(license.data_inicio)}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        <div className="flex flex-col">
                          <span>{license.plano === 'Vitalício' ? 'Vitalício' : formatDate(license.data_fim)}</span>
                          {license.plano === 'Vitalício' ? (
                            <span className="text-xs text-emerald-500 font-medium">✨ Sem expiração</span>
                          ) : isExpired(license.data_fim) ? (
                            <span className="text-xs text-red-500 font-medium">Expirada</span>
                          ) : (
                            <span className="text-xs text-slate-400">
                              {getDaysUntilExpiry(license.data_fim)} dias restantes
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="min-w-[80px] flex justify-center">
                          <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium whitespace-nowrap ${getStatusColor(license.status)}`}>
                            {getStatusIcon(license.status)}
                            {license.status.charAt(0).toUpperCase() + license.status.slice(1)}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {license.observacoes || '-'}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2 justify-center">
                          <button
                            onClick={() => setEditingLicense({
                              id: license.id,
                              usuario_id: license.usuario_id,
                              plano: license.plano,
                              data_inicio: license.data_inicio.split('T')[0],
                              data_fim: license.data_fim.split('T')[0],
                              status: license.status,
                              observacoes: license.observacoes || ''
                            })}
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteLicense(license.id)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {licenses.length === 0 && (
          <div className="text-center py-12">
            <Shield className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-600 mb-2">Nenhuma licença encontrada</h3>
            <p className="text-slate-500">Crie a primeira licença para começar</p>
          </div>
        )}
      </div>

      {/* Create License Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-200/50">
              <h3 className="text-xl font-semibold text-slate-800">Nova Licença</h3>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Usuário</label>
                <div className="relative">
                  <input
                    type="text"
                    value={newLicense.usuario_id}
                    onChange={(e) => {
                      setNewLicense({...newLicense, usuario_id: e.target.value});
                      setUserSearchTerm(e.target.value);
                      setShowUserSearch(e.target.value.length > 0);
                    }}
                    className="w-full px-4 py-2 pr-10 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                    placeholder="Digite o nome, email ou ID do usuário"
                  />
                  <Search className="absolute right-3 top-2.5 w-4 h-4 text-slate-400" />
                  
                  {showUserSearch && (
                    <div className="absolute z-10 w-full mt-1 bg-white border border-slate-300 rounded-lg shadow-lg max-h-48 overflow-y-auto">
                      {usuarios
                        .filter(user => 
                          user.nome.toLowerCase().includes(userSearchTerm.toLowerCase()) ||
                          user.email.toLowerCase().includes(userSearchTerm.toLowerCase()) ||
                          user.id.toLowerCase().includes(userSearchTerm.toLowerCase())
                        )
                        .map(user => (
                          <button
                            key={user.id}
                            type="button"
                            onClick={() => {
                              setNewLicense({...newLicense, usuario_id: user.id});
                              setShowUserSearch(false);
                              setUserSearchTerm('');
                            }}
                            className="w-full text-left px-4 py-2 hover:bg-slate-50 border-b border-slate-100 last:border-b-0"
                          >
                            <div className="font-medium text-slate-800">{user.nome}</div>
                            <div className="text-sm text-slate-600">{user.email}</div>
                            <div className="text-xs font-mono text-slate-400">ID: {user.id}</div>
                          </button>
                        ))
                      }
                      {usuarios.filter(user => 
                        user.nome.toLowerCase().includes(userSearchTerm.toLowerCase()) ||
                        user.email.toLowerCase().includes(userSearchTerm.toLowerCase()) ||
                        user.id.toLowerCase().includes(userSearchTerm.toLowerCase())
                      ).length === 0 && (
                        <div className="px-4 py-2 text-slate-500 text-sm">Nenhum usuário encontrado</div>
                      )}
                    </div>
                  )}
                </div>
                <div className="text-xs text-slate-500 mt-1">
                  Selecione um usuário da lista ou digite o ID manualmente
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Plano</label>
                <select
                  value={newLicense.plano}
                  onChange={(e) => {
                    const selectedPlan = e.target.value;
                    if (selectedPlan === 'Vitalício') {
                      // Para plano vitalício, definir datas automáticas
                      setNewLicense({
                        ...newLicense, 
                        plano: selectedPlan,
                        data_inicio: new Date().toISOString().split('T')[0],
                        data_fim: '2099-12-31' // Data muito distante para simular vitalício
                      });
                    } else {
                      setNewLicense({...newLicense, plano: selectedPlan});
                    }
                  }}
                  className="min-w-[140px] w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                >
                  <option value="Básico">Básico</option>
                  <option value="Pro">Pro</option>
                  <option value="Premium">Premium</option>
                  <option value="Vitalício">Vitalício</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Data Início
                    {newLicense.plano === 'Vitalício' && <span className="text-xs text-slate-500 ml-1">(Automático)</span>}
                  </label>
                  <input
                    type="date"
                    value={newLicense.data_inicio}
                    onChange={(e) => setNewLicense({...newLicense, data_inicio: e.target.value})}
                    disabled={newLicense.plano === 'Vitalício'}
                    className={`w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 ${
                      newLicense.plano === 'Vitalício' ? 'bg-slate-100 cursor-not-allowed' : ''
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Data Fim
                    {newLicense.plano === 'Vitalício' && <span className="text-xs text-slate-500 ml-1">(Vitalício)</span>}
                  </label>
                  <input
                    type="date"
                    value={newLicense.data_fim}
                    onChange={(e) => setNewLicense({...newLicense, data_fim: e.target.value})}
                    disabled={newLicense.plano === 'Vitalício'}
                    className={`w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 ${
                      newLicense.plano === 'Vitalício' ? 'bg-slate-100 cursor-not-allowed' : ''
                    }`}
                  />
                  {newLicense.plano === 'Vitalício' && (
                    <p className="text-xs text-emerald-600 mt-1">
                      ✨ Licença vitalícia - sem data de expiração
                    </p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Status</label>
                <select
                  value={newLicense.status}
                  onChange={(e) => setNewLicense({...newLicense, status: e.target.value})}
                  className="min-w-[120px] w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                >
                  <option value="ativa">Ativa</option>
                  <option value="suspensa">Suspensa</option>
                  <option value="expirada">Expirada</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Observações</label>
                <textarea
                  value={newLicense.observacoes}
                  onChange={(e) => setNewLicense({...newLicense, observacoes: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                  rows={3}
                  placeholder="Observações sobre a licença (opcional)"
                />
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleCreateLicense}
                className="px-4 py-2 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-lg hover:shadow-lg transition-all"
              >
                Criar Licença
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
