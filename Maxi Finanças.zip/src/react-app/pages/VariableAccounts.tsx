import { useEffect, useState } from "react";
import { Plus, Trash2, DollarSign, Filter, Edit3, Calendar, User, Download, Upload, X, ChevronLeft, ChevronRight, ChevronUp, ChevronDown, AlertTriangle, Building2 } from "lucide-react";
import { VariableAccountWithDetails, Category, CostCenter } from "@/shared/types";
import * as XLSX from 'xlsx';

export default function VariableAccounts() {
  const [variableAccounts, setVariableAccounts] = useState<VariableAccountWithDetails[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingAccount, setEditingAccount] = useState<VariableAccountWithDetails | null>(null);
  
  // Form states
  const [formData, setFormData] = useState({
    due_date: "",
    description: "",
    amount: "",
    category_id: "",
    cost_center_id: "",
    payee: "",
    status: "NÃO PAGO",
    is_installment: false,
    installment_count: "",
    installment_interval: "monthly"
  });

  const [newAccount, setNewAccount] = useState({
    due_date: '',
    description: '',
    amount: '',
    category_id: '',
    cost_center_id: '',
    payee: '',
    status: 'NÃO PAGO',
    is_installment: false,
    installment_count: '',
    installment_interval: 'monthly'
  });
  
  const [editAccount, setEditAccount] = useState({
    due_date: '',
    description: '',
    amount: '',
    category_id: '',
    cost_center_id: '',
    payee: '',
    status: 'NÃO PAGO'
  });

  // Amount editing states
  const [editingAmountId, setEditingAmountId] = useState<number | null>(null);
  const [editingAmountValue, setEditingAmountValue] = useState('');

  // Due date editing states
  const [editingDueDateId, setEditingDueDateId] = useState<number | null>(null);
  const [editingDueDateValue, setEditingDueDateValue] = useState('');

  // Filter states
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [filters, setFilters] = useState({
    categoryIds: [] as string[],
    costCenterIds: [] as string[],
    payee: '',
    dueDateFrom: '',
    dueDateTo: '',
    status: ''
  });
  const [appliedFilters, setAppliedFilters] = useState({
    categoryIds: [] as string[],
    costCenterIds: [] as string[],
    payee: '',
    dueDateFrom: '',
    dueDateTo: '',
    status: ''
  });

  // Import state
  const [importing, setImporting] = useState(false);
  const [importResults, setImportResults] = useState<{
    success: boolean;
    message: string;
    imported: number;
    errors: string[];
  } | null>(null);

  // Selection state
  const [selectedAccounts, setSelectedAccounts] = useState<Set<number>>(new Set());
  const [selectAll, setSelectAll] = useState(false);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // Sorting state
  const [sortBy, setSortBy] = useState<'due_date_asc' | 'due_date_desc' | null>(null);

  // Clear data state
  const [showClearModal, setShowClearModal] = useState(false);
  const [clearing, setClearing] = useState(false);

  // Card data state
  const [cardData, setCardData] = useState({
    totalAmount: 0,
    currentMonthUnpaidCount: 0
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      console.log("🔄 Fetching variable accounts data...");
      
      // Get auth data for headers
      const userSession = localStorage.getItem('maxifinancas_user');
      const authHeaders: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      
      if (userSession) {
        authHeaders['Authorization'] = `Bearer ${btoa(userSession)}`;
      }
      
      const [accountsRes, categoriesRes, costCentersRes] = await Promise.all([
        fetch("/api/variable-accounts", {
          credentials: 'include',
          headers: authHeaders
        }),
        fetch("/api/categories", {
          credentials: 'include',
          headers: authHeaders
        }),
        fetch("/api/cost-centers", {
          credentials: 'include',
          headers: authHeaders
        })
      ]);

      if (!accountsRes.ok || !categoriesRes.ok || !costCentersRes.ok) {
        console.error("❌ Error fetching data:", {
          accounts: accountsRes.status,
          categories: categoriesRes.status,
          costCenters: costCentersRes.status
        });
        throw new Error('Failed to fetch data');
      }

      const [accountsData, categoriesData, costCentersData] = await Promise.all([
        accountsRes.json(),
        categoriesRes.json(),
        costCentersRes.json()
      ]);

      console.log("✅ Data fetched successfully:", {
        accounts: accountsData.length,
        categories: categoriesData.length,
        costCenters: costCentersData.length
      });

      setVariableAccounts(accountsData || []);
      setCategories(categoriesData || []);
      setCostCenters(costCentersData || []);
    } catch (error) {
      console.error("❌ Error fetching data:", error);
      // Set empty arrays on error to prevent crashes
      setVariableAccounts([]);
      setCategories([]);
      setCostCenters([]);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateAccount = async () => {
    try {
      // Ensure amount is negative for expenses
      let amount = parseFloat(newAccount.amount);
      if (amount > 0) {
        amount = -amount;
      }
      
      const payload = {
        ...newAccount,
        amount: amount,
        category_id: newAccount.category_id ? parseInt(newAccount.category_id) : undefined,
        cost_center_id: newAccount.cost_center_id ? parseInt(newAccount.cost_center_id) : undefined,
        installment_count: newAccount.is_installment ? parseInt(newAccount.installment_count) : undefined,
        installment_interval: newAccount.is_installment ? newAccount.installment_interval : undefined
      };

      // Get auth data for headers
      const userSession = localStorage.getItem('maxifinancas_user');
      const authHeaders: Record<string, string> = {
        "Content-Type": "application/json"
      };
      
      if (userSession) {
        authHeaders['Authorization'] = `Bearer ${btoa(userSession)}`;
      }

      const response = await fetch("/api/variable-accounts", {
        method: "POST",
        headers: authHeaders,
        credentials: 'include',
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        const result = await response.json();
        setShowModal(false);
        setNewAccount({
          due_date: '',
          description: '',
          amount: '',
          category_id: '',
          cost_center_id: '',
          payee: '',
          status: 'NÃO PAGO',
          is_installment: false,
          installment_count: '',
          installment_interval: 'monthly'
        });
        setFormData({
          due_date: "",
          description: "",
          amount: "",
          category_id: "",
          cost_center_id: "",
          payee: "",
          status: "NÃO PAGO",
          is_installment: false,
          installment_count: "",
          installment_interval: "monthly"
        });
        
        // Show success message for installments
        if (result.installments_created) {
          alert(`${result.installments_created} parcelas criadas com sucesso!`);
        }
        
        await fetchData();
      }
    } catch (error) {
      console.error("Error creating variable account:", error);
    }
  };

  const handleEditAccount = (account: VariableAccountWithDetails) => {
    setEditingAccount(account);
    setEditAccount({
      due_date: account.due_date,
      description: account.description,
      amount: account.amount.toString(),
      category_id: account.category_id?.toString() || '',
      cost_center_id: account.cost_center_id?.toString() || '',
      payee: account.payee,
      status: account.status || 'NÃO PAGO'
    });
    setShowEditModal(true);
  };

  const handleUpdateAccount = async () => {
    if (!editingAccount) return;

    try {
      // Ensure amount is negative for expenses
      let amount = parseFloat(editAccount.amount);
      if (amount > 0) {
        amount = -amount;
      }
      
      // Get auth data for headers
      const userSession = localStorage.getItem('maxifinancas_user');
      const authHeaders: Record<string, string> = {
        "Content-Type": "application/json"
      };
      
      if (userSession) {
        authHeaders['Authorization'] = `Bearer ${btoa(userSession)}`;
      }
      
      const response = await fetch(`/api/variable-accounts/${editingAccount.id}`, {
        method: "PUT",
        headers: authHeaders,
        credentials: 'include',
        body: JSON.stringify({
          ...editAccount,
          amount: amount,
          category_id: editAccount.category_id ? parseInt(editAccount.category_id) : undefined,
          cost_center_id: editAccount.cost_center_id ? parseInt(editAccount.cost_center_id) : undefined,
        })
      });

      if (response.ok) {
        setShowEditModal(false);
        setEditingAccount(null);
        setEditAccount({
          due_date: '',
          description: '',
          amount: '',
          category_id: '',
          cost_center_id: '',
          payee: '',
          status: 'NÃO PAGO'
        });
        await fetchData();
      }
    } catch (error) {
      console.error("Error updating variable account:", error);
    }
  };

  const handleToggleStatus = async (id: number) => {
    // Find the account to get current status
    const account = variableAccounts.find(a => a.id === id);
    if (!account) return;
    
    const currentStatus = account.status || 'NÃO PAGO';
    const newStatus = currentStatus === 'PAGO' ? 'NÃO PAGO' : 'PAGO';
    
    // Show confirmation dialog
    if (!confirm(`Tem certeza que deseja alterar o status desta conta não fixa de "${currentStatus}" para "${newStatus}"?`)) {
      return;
    }
    
    try {
      console.log('Toggling status for account ID:', id);
      
      // Get auth data for headers
      const userSession = localStorage.getItem('maxifinancas_user');
      const authHeaders: Record<string, string> = {};
      
      if (userSession) {
        authHeaders['Authorization'] = `Bearer ${btoa(userSession)}`;
      }
      
      const response = await fetch(`/api/variable-accounts/${id}/status`, {
        method: "PATCH",
        headers: authHeaders,
        credentials: 'include'
      });

      console.log('Response status:', response.status);
      if (response.ok) {
        console.log('Status toggle successful, refreshing data...');
        await fetchData();
      } else {
        console.error('Failed to toggle status:', response.statusText);
        alert('Erro ao alterar status. Tente novamente.');
      }
    } catch (error) {
      console.error("Error toggling variable account status:", error);
      alert('Erro de conexão ao alterar status.');
    }
  };

  const handleStartEditAmount = (id: number, currentAmount: number) => {
    setEditingAmountId(id);
    setEditingAmountValue(currentAmount.toString());
  };

  const handleCancelEditAmount = () => {
    setEditingAmountId(null);
    setEditingAmountValue('');
  };

  const handleSaveAmount = async (id: number) => {
    try {
      let amount = parseFloat(editingAmountValue);
      if (isNaN(amount)) {
        alert("Por favor, insira um valor numérico válido");
        return;
      }

      // Ensure amount is negative for expenses
      if (amount > 0) {
        amount = -amount;
      }

      // Get auth data for headers
      const userSession = localStorage.getItem('maxifinancas_user');
      const authHeaders: Record<string, string> = {
        "Content-Type": "application/json"
      };
      
      if (userSession) {
        authHeaders['Authorization'] = `Bearer ${btoa(userSession)}`;
      }

      const response = await fetch(`/api/variable-accounts/${id}/amount`, {
        method: "PATCH",
        headers: authHeaders,
        credentials: 'include',
        body: JSON.stringify({ amount })
      });

      if (response.ok) {
        setEditingAmountId(null);
        setEditingAmountValue('');
        await fetchData();
      } else {
        alert("Erro ao atualizar o valor");
      }
    } catch (error) {
      console.error("Error updating variable account amount:", error);
      alert("Erro ao atualizar o valor");
    }
  };

  const handleStartEditDueDate = (id: number, currentDueDate: string) => {
    setEditingDueDateId(id);
    setEditingDueDateValue(currentDueDate);
  };

  const handleCancelEditDueDate = () => {
    setEditingDueDateId(null);
    setEditingDueDateValue('');
  };

  const handleSaveDueDate = async (id: number) => {
    try {
      if (!editingDueDateValue) {
        alert("Por favor, insira uma data válida");
        return;
      }

      // Get auth data for headers
      const userSession = localStorage.getItem('maxifinancas_user');
      const authHeaders: Record<string, string> = {
        "Content-Type": "application/json"
      };
      
      if (userSession) {
        authHeaders['Authorization'] = `Bearer ${btoa(userSession)}`;
      }

      const response = await fetch(`/api/variable-accounts/${id}/due-date`, {
        method: "PATCH",
        headers: authHeaders,
        credentials: 'include',
        body: JSON.stringify({ due_date: editingDueDateValue })
      });

      if (response.ok) {
        setEditingDueDateId(null);
        setEditingDueDateValue('');
        await fetchData();
      } else {
        alert("Erro ao atualizar a data de vencimento");
      }
    } catch (error) {
      console.error("Error updating variable account due date:", error);
      alert("Erro ao atualizar a data de vencimento");
    }
  };

  const handleDeleteAccount = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir esta conta não fixa?")) return;

    try {
      // Get auth data for headers
      const userSession = localStorage.getItem('maxifinancas_user');
      const authHeaders: Record<string, string> = {};
      
      if (userSession) {
        authHeaders['Authorization'] = `Bearer ${btoa(userSession)}`;
      }

      const response = await fetch(`/api/variable-accounts/${id}`, {
        method: "DELETE",
        headers: authHeaders,
        credentials: 'include'
      });

      if (response.ok) {
        fetchData();
      }
    } catch (error) {
      console.error("Error deleting variable account:", error);
    }
  };

  const handleSelectAccount = (id: number, checked: boolean) => {
    const newSelected = new Set(selectedAccounts);
    if (checked) {
      newSelected.add(id);
    } else {
      newSelected.delete(id);
    }
    setSelectedAccounts(newSelected);
    
    // Update select all state
    setSelectAll(newSelected.size === paginatedAccounts.length && paginatedAccounts.length > 0);
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const allIds = new Set(paginatedAccounts.map(a => a.id));
      setSelectedAccounts(allIds);
    } else {
      setSelectedAccounts(new Set());
    }
    setSelectAll(checked);
  };

  const handleBulkDelete = async () => {
    if (selectedAccounts.size === 0) return;
    
    if (!confirm(`Tem certeza que deseja excluir ${selectedAccounts.size} conta(s) não fixa(s) selecionada(s)?`)) return;

    try {
      // Get auth data for headers
      const userSession = localStorage.getItem('maxifinancas_user');
      const authHeaders: Record<string, string> = {};
      
      if (userSession) {
        authHeaders['Authorization'] = `Bearer ${btoa(userSession)}`;
      }

      const deletePromises = Array.from(selectedAccounts).map(id =>
        fetch(`/api/variable-accounts/${id}`, { 
          method: "DELETE",
          headers: authHeaders,
          credentials: 'include'
        })
      );

      await Promise.all(deletePromises);
      
      setSelectedAccounts(new Set());
      setSelectAll(false);
      await fetchData();
    } catch (error) {
      console.error("Error deleting variable accounts:", error);
    }
  };

  const handleBulkPay = async () => {
    if (selectedAccounts.size === 0) return;
    
    if (!confirm(`Tem certeza que deseja marcar ${selectedAccounts.size} conta(s) não fixa(s) selecionada(s) como PAGO?`)) return;

    try {
      // Get auth data for headers
      const userSession = localStorage.getItem('maxifinancas_user');
      const authHeaders: Record<string, string> = {};
      
      if (userSession) {
        authHeaders['Authorization'] = `Bearer ${btoa(userSession)}`;
      }

      const payPromises = Array.from(selectedAccounts).map(id =>
        fetch(`/api/variable-accounts/${id}/bulk-pay`, { 
          method: "PATCH",
          headers: authHeaders,
          credentials: 'include'
        })
      );

      await Promise.all(payPromises);
      
      setSelectedAccounts(new Set());
      setSelectAll(false);
      fetchData();
    } catch (error) {
      console.error("Error marking variable accounts as paid:", error);
    }
  };

  const formatCurrency = (amount: number) => {
    const formatted = new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(Math.abs(amount));
    
    return amount < 0 ? `-${formatted}` : formatted;
  };

  const formatDate = (dateString: string) => {
    // Garantir que sempre exibimos no formato brasileiro DD/MM/YY
    // dateString vem no formato "YYYY-MM-DD" do banco
    console.log(`🔍 FORMATAÇÃO: Data original do banco: "${dateString}"`);
    
    if (dateString.includes('-')) {
      const [year, month, day] = dateString.split('-');
      const shortYear = year.substring(2); // Apenas últimos 2 dígitos do ano
      const formattedDate = `${day.padStart(2, '0')}/${month.padStart(2, '0')}/${shortYear}`;
      console.log(`✅ FORMATAÇÃO: "${dateString}" → "${formattedDate}" (formato brasileiro DD/MM/YY)`);
      return formattedDate;
    }
    
    // Fallback para outros formatos (não deveria acontecer)
    console.log(`⚠️ FORMATAÇÃO: Formato inesperado, usando fallback para: "${dateString}"`);
    const date = new Date(dateString + 'T00:00:00'); // Força horário local
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear().toString().substring(2);
    const fallbackDate = `${day}/${month}/${year}`;
    console.log(`✅ FORMATAÇÃO FALLBACK: "${dateString}" → "${fallbackDate}" (formato brasileiro DD/MM/YY)`);
    return fallbackDate;
  };

  const getCategoryById = (id: number) => categories.find(c => c.id === id);
  const getCostCenterById = (id: number) => costCenters.find(cc => cc.id === id);

  // Handle sorting
  const handleSortByDueDate = () => {
    if (sortBy === 'due_date_asc') {
      setSortBy('due_date_desc');
    } else {
      setSortBy('due_date_asc');
    }
    setCurrentPage(1); // Reset to first page when sorting
    setSelectedAccounts(new Set()); // Clear selections
    setSelectAll(false);
  };

  // Apply filters
  const filteredAccounts = variableAccounts.filter(account => {
    // Category filter
    if (appliedFilters.categoryIds.length > 0) {
      const categoryIdNumbers = appliedFilters.categoryIds.map(id => parseInt(id));
      if (!account.category_id || !categoryIdNumbers.includes(account.category_id)) {
        return false;
      }
    }

    // Cost center filter
    if (appliedFilters.costCenterIds.length > 0) {
      const costCenterIdNumbers = appliedFilters.costCenterIds.map(id => parseInt(id));
      if (!account.cost_center_id || !costCenterIdNumbers.includes(account.cost_center_id)) {
        return false;
      }
    }

    // Payee filter
    if (appliedFilters.payee && !account.payee.toLowerCase().includes(appliedFilters.payee.toLowerCase())) {
      return false;
    }

    // Due date range filter
    if (appliedFilters.dueDateFrom && account.due_date < appliedFilters.dueDateFrom) {
      return false;
    }
    if (appliedFilters.dueDateTo && account.due_date > appliedFilters.dueDateTo) {
      return false;
    }

    // Status filter
    if (appliedFilters.status && (account.status || 'NÃO PAGO') !== appliedFilters.status) {
      return false;
    }

    return true;
  });

  // Apply sorting
  const sortedAndFilteredAccounts = [...filteredAccounts];
  if (sortBy === 'due_date_asc') {
    sortedAndFilteredAccounts.sort((a, b) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime());
  } else if (sortBy === 'due_date_desc') {
    sortedAndFilteredAccounts.sort((a, b) => new Date(b.due_date).getTime() - new Date(a.due_date).getTime());
  }

  // Calculate card data directly from local variable accounts data
  const calculateCardData = () => {
    console.log('🔄 Calculating card data from local variable accounts...');
    console.log(`📊 Total variable accounts: ${variableAccounts.length}`);
    
    // Calculate total amount of unpaid accounts (sum of all "NÃO PAGO" amounts)
    const unpaidAccounts = variableAccounts.filter(account => 
      (account.status || 'NÃO PAGO') === 'NÃO PAGO'
    );
    
    const totalUnpaidAmount = unpaidAccounts.reduce((sum, account) => sum + account.amount, 0);
    const unpaidCount = unpaidAccounts.length;
    
    console.log(`💰 Unpaid accounts count: ${unpaidCount}`);
    console.log(`💰 Total unpaid amount: ${totalUnpaidAmount}`);
    console.log('📋 Unpaid accounts details:', unpaidAccounts.map(a => ({
      id: a.id,
      description: a.description,
      amount: a.amount,
      status: a.status || 'NÃO PAGO'
    })));
    
    const newCardData = {
      totalAmount: totalUnpaidAmount,
      currentMonthUnpaidCount: unpaidCount
    };
    
    console.log('🎯 Setting card data:', newCardData);
    setCardData(newCardData);
  };

  // Update card data when variable accounts change
  useEffect(() => {
    console.log('🔄 Variable accounts changed, updating card data...');
    calculateCardData();
  }, [variableAccounts]);

  // Pagination calculations
  const totalPages = Math.ceil(sortedAndFilteredAccounts.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedAccounts = sortedAndFilteredAccounts.slice(startIndex, endIndex);

  // Reset to first page when items per page changes
  const handleItemsPerPageChange = (newItemsPerPage: number) => {
    setItemsPerPage(newItemsPerPage);
    setCurrentPage(1);
    // Clear selections when changing pagination
    setSelectedAccounts(new Set());
    setSelectAll(false);
  };

  // Navigate to specific page
  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
      // Clear selections when changing page
      setSelectedAccounts(new Set());
      setSelectAll(false);
    }
  };

  // Handle right click to clear all selections
  const handleRightClick = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent browser context menu
    if (selectedAccounts.size > 0) {
      setSelectedAccounts(new Set());
      setSelectAll(false);
    }
  };

  // Filter functions
  const handleApplyFilters = () => {
    setAppliedFilters(filters);
    setCurrentPage(1); // Reset to first page
    setSelectedAccounts(new Set()); // Clear selections
    setSelectAll(false);
    setShowFilterModal(false);
  };

  const handleClearFilters = () => {
    const emptyFilters = {
      categoryIds: [] as string[],
      costCenterIds: [] as string[],
      payee: '',
      dueDateFrom: '',
      dueDateTo: '',
      status: ''
    };
    setFilters(emptyFilters);
    setAppliedFilters(emptyFilters);
    setCurrentPage(1);
    setSelectedAccounts(new Set());
    setSelectAll(false);
    setShowFilterModal(false);
  };

  const handleOpenFilterModal = () => {
    setFilters(appliedFilters);
    setShowFilterModal(true);
  };

  // Count active filters
  const activeFilterCount = Object.entries(appliedFilters).filter(([key, value]) => {
    if (key === 'categoryIds' || key === 'costCenterIds') {
      return Array.isArray(value) && value.length > 0;
    }
    return value !== '';
  }).length;

  // Import functions
  const handleImportVariableAccounts = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImporting(true);
    setImportResults(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('/api/variable-accounts/import', {
        method: 'POST',
        credentials: 'include',
        body: formData
      });

      const result = await response.json();
      setImportResults(result);
      
      if (result.success) {
        fetchData();
      }
    } catch (error) {
      setImportResults({
        success: false,
        message: 'Erro ao importar contas não fixas',
        imported: 0,
        errors: ['Erro de conexão com o servidor']
      });
    } finally {
      setImporting(false);
      // Reset file input
      event.target.value = '';
    }
  };

  // Clear all variable accounts
  const handleClearAllVariableAccounts = async () => {
    setClearing(true);
    
    try {
      const response = await fetch('/api/clear-variable-accounts', {
        method: 'POST',
        credentials: 'include'
      });
      
      const result = await response.json();
      
      if (result.success) {
        setImportResults({
          success: true,
          message: result.message,
          imported: 0,
          errors: []
        });
        fetchData(); // Refresh the data
      } else {
        setImportResults({
          success: false,
          message: 'Erro ao limpar contas não fixas',
          imported: 0,
          errors: [result.error || 'Erro desconhecido']
        });
      }
    } catch (error) {
      setImportResults({
        success: false,
        message: 'Erro ao conectar com o servidor',
        imported: 0,
        errors: ['Erro de conexão']
      });
    } finally {
      setClearing(false);
      setShowClearModal(false);
    }
  };

  const downloadVariableAccountSample = () => {
    // Create comprehensive sample data for variable accounts with proper Excel dates (identical to Accounts Receivable)
    const sampleData = [
      // Gastos eventuais típicos
      { vencimento: new Date(2025, 1, 5), descricao: 'Manutenção do Carro', categoria: 'Transporte', centro_custo: 'Carro', a_quem_pagar: 'Oficina Mecânica Silva', valor: -450.00, status: 'NÃO PAGO' },
      { vencimento: new Date(2025, 1, 10), descricao: 'Consulta Médica', categoria: 'Saude', centro_custo: 'Pessoal', a_quem_pagar: 'Dr. João Cardiologista', valor: -300.00, status: 'PAGO' },
      { vencimento: new Date(2025, 1, 15), descricao: 'Material Escolar', categoria: 'Educacao', centro_custo: 'Familia', a_quem_pagar: 'Papelaria Central', valor: -180.50, status: 'NÃO PAGO' },
      { vencimento: new Date(2025, 1, 20), descricao: 'Jantar Comemorativo', categoria: 'Lazer', centro_custo: 'Pessoal', a_quem_pagar: 'Restaurante Italiano', valor: -220.00, status: 'PAGO' },
      { vencimento: new Date(2025, 1, 25), descricao: 'Reparo Geladeira', categoria: 'Moradia', centro_custo: 'Casa', a_quem_pagar: 'Técnico em Refrigeração', valor: -150.00, status: 'NÃO PAGO' },
      { vencimento: new Date(2025, 1, 28), descricao: 'Presente Aniversário', categoria: 'Lazer', centro_custo: 'Familia', a_quem_pagar: 'Loja de Presentes', valor: -120.00, status: 'NÃO PAGO' },
      
      // Receitas eventuais
      { vencimento: new Date(2025, 1, 3), descricao: 'Freelance Design', categoria: 'Renda', centro_custo: 'Trabalho', a_quem_pagar: 'Cliente XYZ Ltda', valor: 800.00, status: 'PAGO' },
      { vencimento: new Date(2025, 1, 12), descricao: 'Venda Produto Usado', categoria: 'Renda', centro_custo: 'Pessoal', a_quem_pagar: 'Comprador Online', valor: 350.00, status: 'NÃO PAGO' },
      { vencimento: new Date(2025, 1, 18), descricao: 'Cashback Cartão', categoria: 'Renda', centro_custo: 'Financeiro', a_quem_pagar: 'Banco Nubank', valor: 45.80, status: 'PAGO' },
      
      // Gastos sazonais/anuais
      { vencimento: new Date(2025, 2, 5), descricao: 'IPVA Veículo', categoria: 'Transporte', centro_custo: 'Carro', a_quem_pagar: 'Governo do Estado', valor: -1200.00, status: 'NÃO PAGO' },
      { vencimento: new Date(2025, 2, 15), descricao: 'Seguro Vida Anual', categoria: 'Financeiro', centro_custo: 'Pessoal', a_quem_pagar: 'Seguradora ABC', valor: -580.00, status: 'NÃO PAGO' },
      { vencimento: new Date(2025, 2, 30), descricao: 'Viagem Férias', categoria: 'Lazer', centro_custo: 'Familia', a_quem_pagar: 'Agência de Turismo', valor: -2500.00, status: 'NÃO PAGO' },
      
      // Emergências e imprevistos
      { vencimento: new Date(2025, 1, 8), descricao: 'Medicamento Urgente', categoria: 'Saude', centro_custo: 'Familia', a_quem_pagar: 'Farmácia São Paulo', valor: -85.50, status: 'PAGO' },
      { vencimento: new Date(2025, 1, 22), descricao: 'Reparo Celular', categoria: 'Tecnologia', centro_custo: 'Pessoal', a_quem_pagar: 'Assistência Técnica', valor: -280.00, status: 'NÃO PAGO' }
    ];

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(sampleData);

    // Auto-size columns
    const colWidths = [
      { wch: 12 }, // vencimento
      { wch: 25 }, // descricao  
      { wch: 15 }, // categoria
      { wch: 15 }, // centro_custo
      { wch: 20 }, // a_quem_pagar
      { wch: 12 }, // valor
      { wch: 10 }  // status
    ];
    ws['!cols'] = colWidths;

    // Configure date format for vencimento column (column A) - identical to Accounts Receivable
    const range = XLSX.utils.decode_range(ws['!ref'] || 'A1');
    for (let rowNum = range.s.r + 1; rowNum <= range.e.r; rowNum++) {
      const cellAddress = XLSX.utils.encode_cell({ r: rowNum, c: 0 }); // Column A (vencimento)
      if (ws[cellAddress] && ws[cellAddress].t === 'd') {
        // Use same format as Accounts Receivable: dd-mmm-yy format
        ws[cellAddress].z = 'dd-mmm-yy'; // Standard format: 31-jan-25
        ws[cellAddress].t = 'd'; // Ensure it's treated as date
      }
    }

    // Add the worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Exemplo_Contas_Nao_Fixas');

    // Generate Excel file and download
    XLSX.writeFile(wb, 'exemplo_importacao_contas_nao_fixas.xlsx');
  };

  const handleExportVariableAccounts = () => {
    // Export current filtered data
    const exportData = filteredAccounts.map(account => {
      const category = getCategoryById(account.category_id || 0);
      const costCenter = getCostCenterById(account.cost_center_id || 0);
      
      return {
        vencimento: formatDate(account.due_date),
        descricao: account.description,
        categoria: category?.name || '',
        centro_custo: costCenter?.name || '',
        a_quem_pagar: account.payee,
        valor: account.amount,
        status: account.status || 'NÃO PAGO'
      };
    });

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(exportData);

    // Auto-size columns
    const colWidths = [
      { wch: 12 }, // vencimento
      { wch: 25 }, // descricao  
      { wch: 15 }, // categoria
      { wch: 15 }, // centro_custo
      { wch: 20 }, // a_quem_pagar
      { wch: 12 }, // valor
      { wch: 10 }  // status
    ];
    ws['!cols'] = colWidths;

    // Add the worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Contas_Nao_Fixas');

    // Generate Excel file and download
    const today = new Date().toISOString().split('T')[0].replace(/-/g, '');
    XLSX.writeFile(wb, `contas_nao_fixas_export_${today}.xlsx`);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full min-h-screen">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-slate-600">Carregando contas não fixas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
      {/* Import Results */}
      {importResults && (
        <div className={`mb-6 p-4 rounded-xl border ${
          importResults.success 
            ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
            : 'bg-red-50 border-red-200 text-red-800'
        }`}>
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">{importResults.message}</h3>
              {importResults.success && (
                <p className="text-sm mt-1">
                  {importResults.imported} conta(s) não fixa(s) importada(s) com sucesso
                </p>
              )}
            </div>
            <button
              onClick={() => setImportResults(null)}
              className="text-current hover:opacity-70"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          {importResults.errors && importResults.errors.length > 0 && (
            <div className="mt-3">
              <p className="text-sm font-medium">Erros encontrados:</p>
              <ul className="text-sm mt-1 list-disc list-inside">
                {importResults.errors.map((error, index) => (
                  <li key={index}>{error}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Contas Não Fixas</h1>
          <p className="text-slate-600">Gerencie suas contas com datas específicas de vencimento</p>
        </div>
        
        {/* Clear All Variable Accounts Button */}
        <button
          onClick={() => setShowClearModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 hover:shadow-lg transition-all duration-200 font-medium"
          title="Limpar todas as contas não fixas"
        >
          <AlertTriangle className="w-4 h-4" />
          Limpar Tudo
        </button>
      </div>

      <div className="flex items-center justify-between mb-8">
        <div className="invisible">
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Contas Não Fixas</h1>
          <p className="text-slate-600">Gerencie suas contas com datas específicas de vencimento</p>
        </div>
        <div className="flex gap-3">
          {selectedAccounts.size > 0 && (
            <>
              <button
                onClick={handleBulkPay}
                className="flex items-center justify-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-colors font-medium min-w-[140px]"
              >
                <DollarSign className="w-4 h-4" />
                Pagar ({selectedAccounts.size})
              </button>
              <button
                onClick={handleBulkDelete}
                className="flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors font-medium min-w-[140px]"
              >
                <Trash2 className="w-4 h-4" />
                Excluir ({selectedAccounts.size})
              </button>
            </>
          )}
          <button 
            onClick={handleOpenFilterModal}
            className={`flex items-center justify-center gap-2 px-4 py-2 rounded-xl transition-colors font-medium relative ${
              activeFilterCount > 0 
                ? 'bg-blue-600 text-white hover:bg-blue-700' 
                : 'bg-indigo-600 text-white hover:bg-indigo-700'
            }`}
          >
            <Filter className="w-4 h-4" />
            Filtros
            {activeFilterCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
          </button>
          <button 
            onClick={handleExportVariableAccounts}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-teal-600 text-white rounded-xl hover:bg-teal-700 transition-colors font-medium min-w-[100px]"
          >
            <Download className="w-4 h-4" />
            Exportar
          </button>
          <input
            type="file"
            accept=".csv,.xlsx,.xls"
            onChange={handleImportVariableAccounts}
            className="hidden"
            id="import-variable-accounts"
            disabled={importing}
          />
          <button
            onClick={downloadVariableAccountSample}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-amber-600 text-white rounded-xl hover:bg-amber-700 transition-colors font-medium min-w-[120px]"
            title="Baixar planilha de exemplo com dados de teste"
          >
            <Download className="w-4 h-4" />
            Baixar Modelo
          </button>
          <label
            htmlFor="import-variable-accounts"
            className={`flex items-center justify-center gap-2 px-4 py-2 bg-violet-600 text-white rounded-xl hover:bg-violet-700 transition-colors cursor-pointer font-medium min-w-[100px] ${importing ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            <Upload className="w-4 h-4" />
            {importing ? 'Importando...' : 'Importar'}
          </label>
          <button 
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              console.log('🔘 Botão clicado - Estado atual do modal:', showModal);
              console.log('🔘 Abrindo modal de criação...');
              setShowModal(true);
              console.log('🔘 Modal setado para true');
            }}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-600 to-cyan-600 text-white rounded-xl hover:shadow-lg transition-all font-medium"
          >
            <Plus className="w-4 h-4" />
            Criar Conta Não Fixa
          </button>
        </div>
      </div>

      {/* Cards Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Selection Summary Card */}
        {selectedAccounts.size > 0 && (
          <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-6 text-white shadow-xl border-2 border-blue-400/30">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-blue-200 mb-2">Contas Selecionadas</p>
                <p className="text-2xl font-bold text-white mb-1">
                  {selectedAccounts.size} {selectedAccounts.size === 1 ? 'conta' : 'contas'}
                </p>
                <p className={`text-xl font-semibold ${
                  variableAccounts
                    .filter(a => selectedAccounts.has(a.id))
                    .reduce((sum, a) => sum + a.amount, 0) < 0 
                    ? 'text-red-300' 
                    : 'text-emerald-300'
                }`}>
                  Valor Total: {formatCurrency(
                    variableAccounts
                      .filter(a => selectedAccounts.has(a.id))
                      .reduce((sum, a) => sum + a.amount, 0)
                  )}
                </p>
              </div>
              <div className="p-4 bg-white/15 rounded-xl backdrop-blur-sm">
                <DollarSign className="w-8 h-8 text-blue-200" />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="text-sm text-blue-200">
                Selecionadas de {filteredAccounts.length} contas
              </div>
              <button
                onClick={() => {
                  setSelectedAccounts(new Set());
                  setSelectAll(false);
                }}
                className="text-xs bg-white/20 hover:bg-white/30 px-3 py-1 rounded-lg transition-colors"
              >
                Limpar Seleção
              </button>
            </div>
          </div>
        )}

        {/* Summary Cards */}
        <div className={`grid grid-cols-2 gap-4 ${selectedAccounts.size === 0 ? 'lg:col-span-2' : ''}`}>
          {/* Total Amount */}
          <div className="bg-gradient-to-r from-emerald-600 to-teal-700 rounded-2xl p-6 text-white shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-emerald-200 mb-2">
                  Valor Total em Aberto
                </p>
                <p className="text-2xl font-bold text-white">
                  {formatCurrency(cardData.totalAmount)}
                </p>
              </div>
              <div className="p-3 bg-white/15 rounded-xl backdrop-blur-sm">
                <DollarSign className="w-6 h-6 text-emerald-200" />
              </div>
            </div>
          </div>

          {/* Unpaid Count */}
          <div className="bg-gradient-to-r from-purple-600 to-pink-700 rounded-2xl p-6 text-white shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-200 mb-2">
                  Quantidade Total em Aberto
                </p>
                <p className="text-2xl font-bold text-white">
                  {cardData.currentMonthUnpaidCount}
                </p>
              </div>
              <div className="p-3 bg-white/15 rounded-xl backdrop-blur-sm">
                <User className="w-6 h-6 text-purple-200" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Variable Accounts Table */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-200/50 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200/50">
          <h2 className="text-xl font-semibold text-slate-800">Lista de Contas Não Fixas</h2>
        </div>
        
        {sortedAndFilteredAccounts.length === 0 ? (
          /* Empty State */
          <div className="flex flex-col items-center justify-center py-16 px-6">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mb-4">
              <Building2 className="w-10 h-10 text-slate-400" />
            </div>
            <h3 className="text-lg font-semibold text-slate-800 mb-2">Nenhuma conta não fixa</h3>
            <p className="text-slate-500 text-center mb-6 max-w-md">
              Comece adicionando sua primeira conta com data específica de vencimento.
            </p>
            <button
              onClick={() => setShowModal(true)}
              className="flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 hover:shadow-lg transition-all font-medium"
            >
              <Plus className="w-4 h-4" />
              Criar Conta Não Fixa
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full" onContextMenu={handleRightClick}>
              <thead className="bg-slate-50 border-b border-slate-200/50">
                <tr>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">
                    <input
                      type="checkbox"
                      checked={selectAll}
                      onChange={(e) => handleSelectAll(e.target.checked)}
                      className="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500"
                    />
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">
                    <button
                      onClick={handleSortByDueDate}
                      className="flex items-center gap-2 hover:text-blue-600 transition-colors"
                      title="Clique para ordenar por data de vencimento"
                    >
                      Vencimento
                      {sortBy === 'due_date_asc' && <ChevronUp className="w-4 h-4" />}
                      {sortBy === 'due_date_desc' && <ChevronDown className="w-4 h-4" />}
                      {!sortBy && <div className="flex flex-col"><ChevronUp className="w-3 h-3 -mb-1 opacity-40" /><ChevronDown className="w-3 h-3 opacity-40" /></div>}
                    </button>
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Descrição</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Categoria</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Centro de Custo</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">A Quem Pagar</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-slate-700">Valor</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">Status</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/50">
                {paginatedAccounts.map((account) => {
                  const category = getCategoryById(account.category_id || 0);
                  const costCenter = getCostCenterById(account.cost_center_id || 0);
                  
                  return (
                    <tr key={account.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4 text-center">
                        <input
                          type="checkbox"
                          checked={selectedAccounts.has(account.id)}
                          onChange={(e) => handleSelectAccount(account.id, e.target.checked)}
                          className="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500"
                        />
                      </td>
                      <td className="px-6 py-4">
                        {editingDueDateId === account.id ? (
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4 text-slate-400" />
                            <input
                              type="date"
                              value={editingDueDateValue}
                              onChange={(e) => setEditingDueDateValue(e.target.value)}
                              className="px-3 py-2 text-sm border border-slate-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 w-36"
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  handleSaveDueDate(account.id);
                                } else if (e.key === 'Escape') {
                                  handleCancelEditDueDate();
                                }
                              }}
                              autoFocus
                            />
                            <button
                              onClick={() => handleSaveDueDate(account.id)}
                              className="text-emerald-600 hover:bg-emerald-50 p-1 rounded text-xs"
                              title="Salvar"
                            >
                              ✓
                            </button>
                            <button
                              onClick={handleCancelEditDueDate}
                              className="text-red-600 hover:bg-red-50 p-1 rounded text-xs"
                              title="Cancelar"
                            >
                              ✕
                            </button>
                          </div>
                        ) : (
                          <div 
                            className="flex items-center gap-2 hover:bg-slate-100 px-2 py-1 rounded transition-colors cursor-pointer group"
                            onClick={() => handleStartEditDueDate(account.id, account.due_date)}
                            title="Clique para editar a data de vencimento"
                          >
                            <Calendar className="w-4 h-4 text-slate-400 group-hover:text-blue-500" />
                            <span className="text-sm font-medium text-slate-800 group-hover:text-blue-700">
                              {formatDate(account.due_date)}
                            </span>
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-slate-800">
                          {account.description}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {category?.name || "-"}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {costCenter?.name || "-"}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-slate-400" />
                          <span className="text-sm text-slate-600">{account.payee}</span>
                        </div>
                      </td>
                      <td className={`px-6 py-4 text-right font-semibold whitespace-nowrap ${
                        account.amount < 0 ? 'text-red-600' : 'text-emerald-600'
                      }`}>
                        {editingAmountId === account.id ? (
                          <div className="flex items-center justify-end gap-2">
                            <input
                              type="number"
                              step="0.01"
                              value={editingAmountValue}
                              onChange={(e) => setEditingAmountValue(e.target.value)}
                              className="w-32 px-3 py-2 text-sm border border-slate-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right"
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  handleSaveAmount(account.id);
                                } else if (e.key === 'Escape') {
                                  handleCancelEditAmount();
                                }
                              }}
                              autoFocus
                            />
                            <button
                              onClick={() => handleSaveAmount(account.id)}
                              className="text-emerald-600 hover:bg-emerald-50 p-1 rounded text-xs"
                              title="Salvar"
                            >
                              ✓
                            </button>
                            <button
                              onClick={handleCancelEditAmount}
                              className="text-red-600 hover:bg-red-50 p-1 rounded text-xs"
                              title="Cancelar"
                            >
                              ✕
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => handleStartEditAmount(account.id, account.amount)}
                            className="hover:bg-slate-100 px-2 py-1 rounded transition-colors cursor-pointer w-full text-right"
                            title="Clique para editar o valor"
                          >
                            {formatCurrency(account.amount)}
                          </button>
                        )}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <button
                          onClick={() => handleToggleStatus(account.id)}
                          className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium transition-all hover:scale-105 hover:shadow-md cursor-pointer ${
                            (account.status || 'NÃO PAGO') === 'PAGO' 
                              ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200' 
                              : 'bg-red-100 text-red-800 hover:bg-red-200'
                          }`}
                          title="Clique para alterar o status"
                        >
                          {(account.status || 'NÃO PAGO')}
                        </button>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleEditAccount(account)}
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="Editar conta não fixa"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteAccount(account.id)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Excluir conta não fixa"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {sortedAndFilteredAccounts.length > 0 && (
          <div className="px-6 py-4 border-t border-slate-200/50 bg-slate-50/50">
            <div className="flex items-center justify-between">
              {/* Items per page selector */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-slate-600">Itens por página:</span>
                <select
                  value={itemsPerPage}
                  onChange={(e) => handleItemsPerPageChange(Number(e.target.value))}
                  className="px-3 py-1 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                >
                  <option value={5}>5</option>
                  <option value={10}>10</option>
                  <option value={20}>20</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>

              {/* Page info and navigation */}
              <div className="flex items-center gap-4">
                <span className="text-sm text-slate-600">
                  Mostrando {startIndex + 1} a {Math.min(endIndex, sortedAndFilteredAccounts.length)} de {sortedAndFilteredAccounts.length} registros
                </span>
                
                <div className="flex items-center gap-2">
                  {/* Previous button */}
                  <button
                    onClick={() => goToPage(currentPage - 1)}
                    disabled={currentPage === 1}
                    className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    title="Página anterior"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>

                  {/* Page number selector */}
                  <div className="flex items-center gap-1">
                    {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                      let pageNumber;
                      if (totalPages <= 5) {
                        pageNumber = i + 1;
                      } else if (currentPage <= 3) {
                        pageNumber = i + 1;
                      } else if (currentPage >= totalPages - 2) {
                        pageNumber = totalPages - 4 + i;
                      } else {
                        pageNumber = currentPage - 2 + i;
                      }

                      return (
                        <button
                          key={pageNumber}
                          onClick={() => goToPage(pageNumber)}
                          className={`px-3 py-1 text-sm rounded-lg transition-colors ${
                            currentPage === pageNumber
                              ? 'bg-emerald-600 text-white'
                              : 'text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          {pageNumber}
                        </button>
                      );
                    })}
                  </div>

                  {/* Next button */}
                  <button
                    onClick={() => goToPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                    className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    title="Próxima página"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Direct page input */}
                {totalPages > 5 && (
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-600">Ir para:</span>
                    <input
                      type="number"
                      min={1}
                      max={totalPages}
                      value={currentPage}
                      onChange={(e) => {
                        const page = Number(e.target.value);
                        if (page >= 1 && page <= totalPages) {
                          goToPage(page);
                        }
                      }}
                      className="w-16 px-2 py-1 border border-slate-300 rounded-lg text-sm text-center focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer Information */}
      <div className="mt-8 py-4 border-t border-slate-200/50">
        <div className="text-center text-sm text-slate-600">
          {activeFilterCount > 0 ? (
            <>
              Registros filtrados: <span className="font-semibold">{sortedAndFilteredAccounts.length}</span> de {variableAccounts.length}
              {sortedAndFilteredAccounts.length > 0 && (
                <span className="ml-4">
                  Mostrando {Math.min(startIndex + 1, sortedAndFilteredAccounts.length)} a {Math.min(endIndex, sortedAndFilteredAccounts.length)} de {sortedAndFilteredAccounts.length} registros filtrados
                </span>
              )}
            </>
          ) : (
            <>
              Total de registros: <span className="font-semibold">{variableAccounts.length}</span>
              {sortedAndFilteredAccounts.length > 0 && (
                <span className="ml-4">
                  Mostrando {Math.min(startIndex + 1, sortedAndFilteredAccounts.length)} a {Math.min(endIndex, sortedAndFilteredAccounts.length)} de {sortedAndFilteredAccounts.length} registros
                </span>
              )}
            </>
          )}
        </div>
      </div>

      {/* Create Modal */}
      {console.log('🔧 Renderizando modal - showModal:', showModal)}
      {showModal && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4" 
          style={{ zIndex: 9999 }}
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setShowModal(false);
            }
          }}
        >
          <div 
            className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-slate-200/50">
              <h3 className="text-xl font-semibold text-slate-800">Nova Conta Não Fixa</h3>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Data de Vencimento</label>
                <input
                  type="date"
                  value={newAccount.due_date}
                  onChange={(e) => setNewAccount({...newAccount, due_date: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Descrição</label>
                <input
                  type="text"
                  value={newAccount.description}
                  onChange={(e) => setNewAccount({...newAccount, description: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="Descrição da conta"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Valor (Despesa)</label>
                <input
                  type="number"
                  step="0.01"
                  value={newAccount.amount}
                  onChange={(e) => {
                    let value = e.target.value;
                    // Ensure value is negative for expenses
                    if (value && parseFloat(value) > 0) {
                      value = `-${value}`;
                    }
                    setNewAccount({...newAccount, amount: value});
                  }}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="-0.00"
                />
                <p className="text-xs text-slate-500 mt-1">Valor será automaticamente convertido para negativo (despesa)</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Categoria</label>
                <select
                  value={newAccount.category_id}
                  onChange={(e) => setNewAccount({...newAccount, category_id: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                >
                  <option value="">Selecione uma categoria</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Centro de Custo</label>
                <select
                  value={newAccount.cost_center_id}
                  onChange={(e) => setNewAccount({...newAccount, cost_center_id: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                >
                  <option value="">Selecione um centro de custo</option>
                  {costCenters.map((costCenter) => (
                    <option key={costCenter.id} value={costCenter.id}>
                      {costCenter.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">A Quem Pagar</label>
                <input
                  type="text"
                  value={newAccount.payee}
                  onChange={(e) => setNewAccount({...newAccount, payee: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="Nome da empresa ou pessoa"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Status</label>
                <select
                  value={newAccount.status}
                  onChange={(e) => setNewAccount({...newAccount, status: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                >
                  <option value="NÃO PAGO">NÃO PAGO</option>
                  <option value="PAGO">PAGO</option>
                </select>
              </div>

              {/* Parcelamento Section */}
              <div className="border-t pt-4">
                <div className="flex items-center gap-2 mb-4">
                  <input
                    type="checkbox"
                    id="is_installment"
                    checked={newAccount.is_installment}
                    onChange={(e) => setNewAccount({...newAccount, is_installment: e.target.checked})}
                    className="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500"
                  />
                  <label htmlFor="is_installment" className="text-sm font-medium text-slate-700">
                    Criar lançamento parcelado
                  </label>
                </div>

                {newAccount.is_installment && (
                  <div className="space-y-4 bg-slate-50 p-4 rounded-lg">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">Número de Parcelas</label>
                        <input
                          type="number"
                          min="2"
                          max="60"
                          value={newAccount.installment_count}
                          onChange={(e) => setNewAccount({...newAccount, installment_count: e.target.value})}
                          className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                          placeholder="Ex: 12"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">Intervalo</label>
                        <select
                          value={newAccount.installment_interval}
                          onChange={(e) => setNewAccount({...newAccount, installment_interval: e.target.value})}
                          className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                        >
                          <option value="weekly">Semanal (7 dias)</option>
                          <option value="biweekly">Quinzenal (15 dias)</option>
                          <option value="monthly">Mensal (30 dias)</option>
                          <option value="bimonthly">Bimestral (60 dias)</option>
                          <option value="quarterly">Trimestral (90 dias)</option>
                        </select>
                      </div>
                    </div>
                    
                    {newAccount.installment_count && parseInt(newAccount.installment_count) > 1 && (
                      <div className="text-sm text-slate-600 bg-blue-50 p-3 rounded-lg">
                        <strong>Resumo do Parcelamento:</strong>
                        <br />
                        • {newAccount.installment_count} parcelas de {newAccount.amount ? formatCurrency(parseFloat(newAccount.amount) / parseInt(newAccount.installment_count)) : 'R$ 0,00'}
                        <br />
                        • Data da 1ª parcela: {newAccount.due_date ? formatDate(newAccount.due_date) : 'Não definida'}
                        <br />
                        • Intervalo: {
                          newAccount.installment_interval === 'weekly' ? 'Semanal' :
                          newAccount.installment_interval === 'biweekly' ? 'Quinzenal' :
                          newAccount.installment_interval === 'monthly' ? 'Mensal' :
                          newAccount.installment_interval === 'bimonthly' ? 'Bimestral' :
                          newAccount.installment_interval === 'quarterly' ? 'Trimestral' : ''
                        }
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={(e) => {
                  e.preventDefault();
                  console.log('🔘 Botão cancelar clicado');
                  setShowModal(false);
                }}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleCreateAccount}
                className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-lg hover:shadow-lg transition-all"
              >
                Criar Conta Não Fixa
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {showEditModal && editingAccount && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-slate-200/50">
              <h3 className="text-xl font-semibold text-slate-800">Editar Conta Não Fixa</h3>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Data de Vencimento</label>
                <input
                  type="date"
                  value={editAccount.due_date}
                  onChange={(e) => setEditAccount({...editAccount, due_date: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Descrição</label>
                <input
                  type="text"
                  value={editAccount.description}
                  onChange={(e) => setEditAccount({...editAccount, description: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Descrição da conta"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Valor (Despesa)</label>
                <input
                  type="number"
                  step="0.01"
                  value={editAccount.amount}
                  onChange={(e) => {
                    let value = e.target.value;
                    // Ensure value is negative for expenses
                    if (value && parseFloat(value) > 0) {
                      value = `-${value}`;
                    }
                    setEditAccount({...editAccount, amount: value});
                  }}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="-0.00"
                />
                <p className="text-xs text-slate-500 mt-1">Valor será automaticamente convertido para negativo (despesa)</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Categoria</label>
                <select
                  value={editAccount.category_id}
                  onChange={(e) => setEditAccount({...editAccount, category_id: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Selecione uma categoria</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Centro de Custo</label>
                <select
                  value={editAccount.cost_center_id}
                  onChange={(e) => setEditAccount({...editAccount, cost_center_id: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Selecione um centro de custo</option>
                  {costCenters.map((costCenter) => (
                    <option key={costCenter.id} value={costCenter.id}>
                      {costCenter.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">A Quem Pagar</label>
                <input
                  type="text"
                  value={editAccount.payee}
                  onChange={(e) => setEditAccount({...editAccount, payee: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Nome da empresa ou pessoa"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Status</label>
                <select
                  value={editAccount.status}
                  onChange={(e) => setEditAccount({...editAccount, status: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="NÃO PAGO">NÃO PAGO</option>
                  <option value="PAGO">PAGO</option>
                </select>
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => {
                  setShowEditModal(false);
                  setEditingAccount(null);
                }}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleUpdateAccount}
                className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:shadow-lg transition-all"
              >
                Salvar Alterações
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Filter Modal */}
      {showFilterModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-slate-200/50">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold text-slate-800">Filtrar Contas Não Fixas</h3>
                {activeFilterCount > 0 && (
                  <span className="bg-blue-100 text-blue-800 text-sm px-3 py-1 rounded-full">
                    {activeFilterCount} filtro{activeFilterCount > 1 ? 's' : ''} ativo{activeFilterCount > 1 ? 's' : ''}
                  </span>
                )}
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Due Date Range */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Data de Vencimento (Inicial)</label>
                  <input
                    type="date"
                    value={filters.dueDateFrom}
                    onChange={(e) => setFilters({...filters, dueDateFrom: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Data de Vencimento (Final)</label>
                  <input
                    type="date"
                    value={filters.dueDateTo}
                    onChange={(e) => setFilters({...filters, dueDateTo: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>

              {/* Category and Cost Center */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Categorias ({filters.categoryIds.length} selecionada{filters.categoryIds.length !== 1 ? 's' : ''})
                  </label>
                  <div className="relative">
                    <div className="border border-slate-300 rounded-lg p-3 max-h-40 overflow-y-auto bg-white">
                      <div className="space-y-2">
                        <label className="flex items-center gap-2 cursor-pointer hover:bg-slate-50 p-1 rounded">
                          <input
                            type="checkbox"
                            checked={filters.categoryIds.length === categories.length}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFilters({...filters, categoryIds: categories.map(c => c.id.toString())});
                              } else {
                                setFilters({...filters, categoryIds: []});
                              }
                            }}
                            className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                          />
                          <span className="text-sm font-medium text-slate-700">Todas as categorias</span>
                        </label>
                        <hr className="border-slate-200" />
                        {categories.map((category) => (
                          <label key={category.id} className="flex items-center gap-2 cursor-pointer hover:bg-slate-50 p-1 rounded">
                            <input
                              type="checkbox"
                              checked={filters.categoryIds.includes(category.id.toString())}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setFilters({
                                    ...filters, 
                                    categoryIds: [...filters.categoryIds, category.id.toString()]
                                  });
                                } else {
                                  setFilters({
                                    ...filters, 
                                    categoryIds: filters.categoryIds.filter(id => id !== category.id.toString())
                                  });
                                }
                              }}
                              className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm text-slate-700">{category.name}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Centros de Custo ({filters.costCenterIds.length} selecionado{filters.costCenterIds.length !== 1 ? 's' : ''})
                  </label>
                  <div className="relative">
                    <div className="border border-slate-300 rounded-lg p-3 max-h-40 overflow-y-auto bg-white">
                      <div className="space-y-2">
                        <label className="flex items-center gap-2 cursor-pointer hover:bg-slate-50 p-1 rounded">
                          <input
                            type="checkbox"
                            checked={filters.costCenterIds.length === costCenters.length}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFilters({...filters, costCenterIds: costCenters.map(cc => cc.id.toString())});
                              } else {
                                setFilters({...filters, costCenterIds: []});
                              }
                            }}
                            className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                          />
                          <span className="text-sm font-medium text-slate-700">Todos os centros de custo</span>
                        </label>
                        <hr className="border-slate-200" />
                        {costCenters.map((costCenter) => (
                          <label key={costCenter.id} className="flex items-center gap-2 cursor-pointer hover:bg-slate-50 p-1 rounded">
                            <input
                              type="checkbox"
                              checked={filters.costCenterIds.includes(costCenter.id.toString())}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setFilters({
                                    ...filters, 
                                    costCenterIds: [...filters.costCenterIds, costCenter.id.toString()]
                                  });
                                } else {
                                  setFilters({
                                    ...filters, 
                                    costCenterIds: filters.costCenterIds.filter(id => id !== costCenter.id.toString())
                                  });
                                }
                              }}
                              className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm text-slate-700">{costCenter.name}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Status and Payee */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Status</label>
                  <select
                    value={filters.status}
                    onChange={(e) => setFilters({...filters, status: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Todos os status</option>
                    <option value="PAGO">PAGO</option>
                    <option value="NÃO PAGO">NÃO PAGO</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">A Quem Pagar</label>
                  <input
                    type="text"
                    value={filters.payee}
                    onChange={(e) => setFilters({...filters, payee: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Buscar por nome..."
                  />
                </div>
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-between">
              <div className="flex gap-3">
                <button
                  onClick={() => setShowFilterModal(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleClearFilters}
                  className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  Limpar Filtros
                </button>
              </div>
              <button
                onClick={handleApplyFilters}
                className="px-6 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:shadow-lg transition-all font-medium"
              >
                Aplicar Filtros
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clear All Variable Accounts Modal */}
      {showClearModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-200/50 flex items-center gap-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold text-slate-800">Limpar Todas as Contas Não Fixas</h3>
            </div>
            
            <div className="p-6">
              <div className="mb-4">
                <p className="text-slate-700 mb-2">
                  <strong>Atenção:</strong> Esta ação irá remover permanentemente:
                </p>
                <ul className="list-disc list-inside text-sm text-slate-600 space-y-1 ml-4">
                  <li>Todas as contas não fixas cadastradas</li>
                  <li>Histórico de contas eventuais e parcelamentos</li>
                  <li>Dados de vencimentos específicos</li>
                </ul>
              </div>
              
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
                <p className="text-red-800 text-sm font-medium">
                  ⚠️ Esta ação não pode ser desfeita!
                </p>
                <p className="text-red-700 text-sm">
                  Certifique-se de ter um backup dos seus dados se necessário.
                </p>
              </div>
              
              <p className="text-slate-600 text-sm">
                As categorias e centros de custo permanecerão inalterados.
              </p>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => setShowClearModal(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                disabled={clearing}
              >
                Cancelar
              </button>
              <button
                onClick={handleClearAllVariableAccounts}
                disabled={clearing}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {clearing ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                    Limpando...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    Confirmar Limpeza
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
