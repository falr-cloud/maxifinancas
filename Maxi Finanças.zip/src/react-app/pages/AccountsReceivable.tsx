import { useEffect, useState } from "react";
import { Plus, Upload, Trash2, Edit3, Check, X, Calendar, DollarSign, Users, Download, Filter, AlertTriangle, ChevronLeft, ChevronRight, TrendingUp } from "lucide-react";
import { useAuth } from "@/react-app/contexts/AuthContext";
import * as XLSX from 'xlsx';

interface Category {
  id: number;
  name: string;
  description?: string;
}

interface CostCenter {
  id: number;
  name: string;
  description?: string;
}

interface AccountReceivable {
  id: number;
  due_date: string;
  description: string;
  amount: number;
  category_id?: number;
  cost_center_id?: number;
  payer: string;
  status: string;
  created_at: string;
  updated_at: string;
  category_name?: string;
  cost_center_name?: string;
}

export default function AccountsReceivable() {
  const { user } = useAuth();
  const [accountsReceivable, setAccountsReceivable] = useState<AccountReceivable[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingAccount, setEditingAccount] = useState<AccountReceivable | null>(null);
  
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingField, setEditingField] = useState<string | null>(null);
  const [editingValue, setEditingValue] = useState<string>("");

  // Form states
  const [formData, setFormData] = useState({
    due_date: "",
    description: "",
    amount: "",
    category_id: "",
    cost_center_id: "",
    payer: "",
    status: "NÃO RECEBIDO"
  });

  // Edit form states
  const [editFormData, setEditFormData] = useState({
    due_date: "",
    description: "",
    amount: "",
    category_id: "",
    cost_center_id: "",
    payer: "",
    status: "NÃO RECEBIDO"
  });

  // Import states
  const [importing, setImporting] = useState(false);
  const [importResults, setImportResults] = useState<{
    success: boolean;
    message: string;
    imported: number;
    errors: string[];
  } | null>(null);

  // Filter states
  const [filters, setFilters] = useState({
    description: "",
    payer: "",
    status: "",
    category: "",
    costCenter: "",
    dateFrom: "",
    dateTo: "",
    amountFrom: "",
    amountTo: ""
  });
  const [filteredAccountsReceivable, setFilteredAccountsReceivable] = useState<AccountReceivable[]>([]);

  // Clear data state
  const [showClearModal, setShowClearModal] = useState(false);
  const [clearing, setClearing] = useState(false);

  // Count active filters
  const hasActiveFilters = Object.values(filters).some(value => value.trim() !== "");
  const activeFilterCount = Object.entries(filters).filter(([, value]) => {
    return value.trim() !== '';
  }).length;

  // Selection state
  const [selectedAccounts, setSelectedAccounts] = useState<Set<number>>(new Set());
  const [selectAll, setSelectAll] = useState(false);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  useEffect(() => {
    fetchAccountsReceivable();
    fetchCategories();
    fetchCostCenters();
  }, []);

  // Apply filters whenever accounts or filters change
  useEffect(() => {
    let filtered = [...accountsReceivable];

    if (filters.description.trim()) {
      filtered = filtered.filter(account => 
        account.description.toLowerCase().includes(filters.description.toLowerCase())
      );
    }

    if (filters.payer.trim()) {
      filtered = filtered.filter(account => 
        account.payer.toLowerCase().includes(filters.payer.toLowerCase())
      );
    }

    if (filters.status) {
      filtered = filtered.filter(account => account.status === filters.status);
    }

    if (filters.category) {
      filtered = filtered.filter(account => account.category_name === filters.category);
    }

    if (filters.costCenter) {
      filtered = filtered.filter(account => account.cost_center_name === filters.costCenter);
    }

    if (filters.dateFrom) {
      filtered = filtered.filter(account => account.due_date >= filters.dateFrom);
    }

    if (filters.dateTo) {
      filtered = filtered.filter(account => account.due_date <= filters.dateTo);
    }

    if (filters.amountFrom) {
      filtered = filtered.filter(account => account.amount >= parseFloat(filters.amountFrom));
    }

    if (filters.amountTo) {
      filtered = filtered.filter(account => account.amount <= parseFloat(filters.amountTo));
    }

    // Sort by due_date descending (most recent first)
    filtered.sort((a, b) => new Date(b.due_date).getTime() - new Date(a.due_date).getTime());

    setFilteredAccountsReceivable(filtered);
  }, [accountsReceivable, filters]);

  const fetchAccountsReceivable = async () => {
    try {
      const response = await fetch("/api/accounts-receivable", {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${btoa(JSON.stringify(user))}`
        }
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      // Sort by due_date descending (most recent first)
      const sortedData = data.sort((a: AccountReceivable, b: AccountReceivable) => 
        new Date(b.due_date).getTime() - new Date(a.due_date).getTime()
      );
      setAccountsReceivable(sortedData);
    } catch (error) {
      console.error("Error fetching accounts receivable:", error);
      setAccountsReceivable([]); // Set empty array as fallback
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await fetch("/api/categories", {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${btoa(JSON.stringify(user))}`
        }
      });
      const data = await response.json();
      setCategories(data);
    } catch (error) {
      console.error("Error fetching categories:", error);
    }
  };

  const fetchCostCenters = async () => {
    try {
      const response = await fetch("/api/cost-centers", {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${btoa(JSON.stringify(user))}`
        }
      });
      const data = await response.json();
      setCostCenters(data);
    } catch (error) {
      console.error("Error fetching cost centers:", error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validação para garantir que o valor seja positivo
    const amount = parseFloat(formData.amount);
    if (amount <= 0) {
      alert("O valor deve ser positivo para contas a receber.");
      return;
    }
    
    try {
      console.log("Creating account receivable with data:", {
        ...formData,
        amount: amount,
        category_id: formData.category_id ? parseInt(formData.category_id) : undefined,
        cost_center_id: formData.cost_center_id ? parseInt(formData.cost_center_id) : undefined,
      });
      
      const response = await fetch("/api/accounts-receivable", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        },
        credentials: 'include',
        body: JSON.stringify({
          ...formData,
          amount: amount,
          category_id: formData.category_id ? parseInt(formData.category_id) : undefined,
          cost_center_id: formData.cost_center_id ? parseInt(formData.cost_center_id) : undefined,
        }),
      });

      console.log("Response status:", response.status);
      
      if (response.ok) {
        const result = await response.json();
        console.log("Account receivable created successfully:", result);
        setFormData({
          due_date: "",
          description: "",
          amount: "",
          category_id: "",
          cost_center_id: "",
          payer: "",
          status: "NÃO RECEBIDO"
        });
        setShowAddForm(false);
        fetchAccountsReceivable();
      } else {
        const errorData = await response.json();
        console.error("Error response:", errorData);
        alert(`Erro ao criar conta a receber: ${errorData.error || 'Erro desconhecido'}`);
      }
    } catch (error) {
      console.error("Error creating account receivable:", error);
      alert("Erro de conexão ao criar conta a receber");
    }
  };

  const toggleStatus = async (id: number) => {
    // Find the account to get current status
    const account = accountsReceivable.find(a => a.id === id);
    if (!account) return;
    
    const currentStatus = account.status || 'NÃO RECEBIDO';
    const newStatus = currentStatus === 'RECEBIDO' ? 'NÃO RECEBIDO' : 'RECEBIDO';
    
    // Show confirmation dialog
    if (!confirm(`Tem certeza que deseja alterar o status desta conta a receber de "${currentStatus}" para "${newStatus}"?`)) {
      return;
    }
    
    try {
      const response = await fetch(`/api/accounts-receivable/${id}/status`, {
        method: "PATCH",
        headers: {
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        },
        credentials: 'include'
      });
      
      if (response.ok) {
        fetchAccountsReceivable();
      }
    } catch (error) {
      console.error("Error toggling status:", error);
    }
  };

  const handleEdit = (id: number, field: string, currentValue: any) => {
    setEditingId(id);
    setEditingField(field);
    
    if (field === 'due_date') {
      setEditingValue(currentValue);
    } else if (field === 'amount') {
      // Para contas a receber, o valor sempre deve ser positivo
      setEditingValue(Math.abs(currentValue).toString());
    } else {
      setEditingValue(currentValue?.toString() || "");
    }
  };

  const saveEdit = async () => {
    if (!editingId || !editingField) return;

    // Validação para valores positivos em contas a receber
    if (editingField === 'amount') {
      const amount = parseFloat(editingValue);
      if (amount <= 0) {
        alert("O valor deve ser positivo para contas a receber.");
        return;
      }
    }

    try {
      let endpoint = `/api/accounts-receivable/${editingId}`;
      let body = {};

      if (editingField === 'amount') {
        endpoint += '/amount';
        body = { amount: parseFloat(editingValue) };
      } else if (editingField === 'due_date') {
        endpoint += '/due-date';
        body = { due_date: editingValue };
      } else {
        body = { [editingField]: editingValue };
      }

      const response = await fetch(endpoint, {
        method: editingField === 'amount' || editingField === 'due_date' ? "PATCH" : "PUT",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        },
        credentials: 'include',
        body: JSON.stringify(body),
      });

      if (response.ok) {
        fetchAccountsReceivable();
      }
    } catch (error) {
      console.error("Error saving edit:", error);
    } finally {
      setEditingId(null);
      setEditingField(null);
      setEditingValue("");
    }
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditingField(null);
    setEditingValue("");
  };

  const deleteAccount = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir esta conta a receber?")) return;

    try {
      const response = await fetch(`/api/accounts-receivable/${id}`, {
        method: "DELETE",
        headers: {
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        },
        credentials: 'include'
      });

      if (response.ok) {
        fetchAccountsReceivable();
      }
    } catch (error) {
      console.error("Error deleting account:", error);
    }
  };

  const handleEditAccount = (account: AccountReceivable) => {
    setEditingAccount(account);
    setEditFormData({
      due_date: account.due_date,
      description: account.description,
      amount: account.amount.toString(),
      category_id: account.category_id?.toString() || "",
      cost_center_id: account.cost_center_id?.toString() || "",
      payer: account.payer,
      status: account.status
    });
    setShowEditModal(true);
  };

  const handleUpdateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAccount) return;
    
    // Validação para garantir que o valor seja positivo
    const amount = parseFloat(editFormData.amount);
    if (amount <= 0) {
      alert("O valor deve ser positivo para contas a receber.");
      return;
    }
    
    try {
      const response = await fetch(`/api/accounts-receivable/${editingAccount.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        },
        credentials: 'include',
        body: JSON.stringify({
          ...editFormData,
          amount: amount,
          category_id: editFormData.category_id ? parseInt(editFormData.category_id) : undefined,
          cost_center_id: editFormData.cost_center_id ? parseInt(editFormData.cost_center_id) : undefined,
        }),
      });

      if (response.ok) {
        setShowEditModal(false);
        setEditingAccount(null);
        setEditFormData({
          due_date: "",
          description: "",
          amount: "",
          category_id: "",
          cost_center_id: "",
          payer: "",
          status: "NÃO RECEBIDO"
        });
        fetchAccountsReceivable();
      }
    } catch (error) {
      console.error("Error updating account receivable:", error);
    }
  };

  const handleImportAccountsReceivable = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImporting(true);
    setImportResults(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('/api/accounts-receivable/import', {
        method: 'POST',
        credentials: 'include',
        body: formData,
      });

      const result = await response.json();
      setImportResults(result);
      
      if (result.success) {
        fetchAccountsReceivable();
      }
    } catch (error) {
      setImportResults({
        success: false,
        message: 'Erro ao importar contas a receber',
        imported: 0,
        errors: ['Erro de conexão com o servidor']
      });
    } finally {
      setImporting(false);
      // Reset file input
      event.target.value = '';
    }
  };

  const downloadExampleTemplate = () => {
    // Create sample data for accounts receivable with proper Excel dates
    const sampleData = [
      { vencimento: new Date(2025, 0, 31), descricao: 'Venda de produto', categoria: 'Vendas', centro_custo: 'Comercial', pagador: 'Cliente ABC', valor: 1500.00, status: 'NÃO RECEBIDO' },
      { vencimento: new Date(2025, 1, 15), descricao: 'Prestação de serviço', categoria: 'Serviços', centro_custo: 'Administrativo', pagador: 'Cliente XYZ', valor: 2000.00, status: 'RECEBIDO' },
      { vencimento: new Date(2025, 1, 27), descricao: 'Consultoria', categoria: 'Consultoria', centro_custo: 'Projetos', pagador: 'Cliente 123', valor: 5000.00, status: 'NÃO RECEBIDO' },
      { vencimento: new Date(2025, 2, 4), descricao: 'Curso Online', categoria: 'Educação', centro_custo: 'Digital', pagador: 'Empresa EDU', valor: 800.00, status: 'NÃO RECEBIDO' },
      { vencimento: new Date(2025, 2, 11), descricao: 'Comissão Vendas', categoria: 'Vendas', centro_custo: 'Comercial', pagador: 'Parceiro A', valor: 1200.00, status: 'RECEBIDO' },
      { vencimento: new Date(2025, 2, 19), descricao: 'Projeto Desenvolvimento', categoria: 'Tecnologia', centro_custo: 'TI', pagador: 'StartupTech', valor: 3500.00, status: 'NÃO RECEBIDO' }
    ];

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(sampleData);

    // Auto-size columns
    const colWidths = [
      { wch: 12 }, // vencimento
      { wch: 25 }, // descricao  
      { wch: 15 }, // categoria
      { wch: 15 }, // centro_custo
      { wch: 20 }, // pagador
      { wch: 12 }, // valor
      { wch: 12 }  // status
    ];
    ws['!cols'] = colWidths;

    // Configure date format for vencimento column (column A) - usar formato de data padrão do Excel
    const range = XLSX.utils.decode_range(ws['!ref'] || 'A1');
    for (let rowNum = range.s.r + 1; rowNum <= range.e.r; rowNum++) {
      const cellAddress = XLSX.utils.encode_cell({ r: rowNum, c: 0 }); // Column A (vencimento)
      if (ws[cellAddress] && ws[cellAddress].t === 'd') {
        // Usar formato de data padrão que é reconhecido como "Data" no Excel, não "Personalizado"
        ws[cellAddress].z = 'dd-mmm-yy'; // Formato padrão: 31-jan-25
        ws[cellAddress].t = 'd'; // Certificar que é tratado como data
      }
    }

    // Add the worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Exemplo_Contas_Receber');

    // Generate Excel file and download
    XLSX.writeFile(wb, 'exemplo_contas_a_receber.xlsx');
  };

  const exportToCSV = () => {
    const dataToExport = filteredAccountsReceivable.length > 0 ? filteredAccountsReceivable : accountsReceivable;
    
    if (dataToExport.length === 0) {
      alert('Não há dados para exportar.');
      return;
    }

    const headers = ['Vencimento', 'Descrição', 'Pagador', 'Categoria', 'Centro de Custo', 'Valor', 'Status'];
    const csvData = [
      headers.join(','),
      ...dataToExport.map(account => [
        formatDate(account.due_date),
        `"${account.description}"`,
        `"${account.payer}"`,
        `"${account.category_name || '-'}"`,
        `"${account.cost_center_name || 'Sem centro'}"`,
        account.amount.toFixed(2).replace('.', ','),
        account.status
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `contas_a_receber_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
  };

  const clearFilters = () => {
    setFilters({
      description: "",
      payer: "",
      status: "",
      category: "",
      costCenter: "",
      dateFrom: "",
      dateTo: "",
      amountFrom: "",
      amountTo: ""
    });
  };

  // Pagination calculations
  const totalPages = Math.ceil(filteredAccountsReceivable.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedAccounts = filteredAccountsReceivable.length > 0 || hasActiveFilters ? 
    filteredAccountsReceivable.slice(startIndex, endIndex) : 
    accountsReceivable.slice(startIndex, endIndex);

  // Reset to first page when items per page changes
  const handleItemsPerPageChange = (newItemsPerPage: number) => {
    setItemsPerPage(newItemsPerPage);
    setCurrentPage(1);
    // Clear selections when changing pagination
    setSelectedAccounts(new Set());
    setSelectAll(false);
  };

  // Navigate to specific page
  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
      // Clear selections when changing page
      setSelectedAccounts(new Set());
      setSelectAll(false);
    }
  };

  // Handle right click to clear all selections
  const handleRightClick = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent browser context menu
    if (selectedAccounts.size > 0) {
      setSelectedAccounts(new Set());
      setSelectAll(false);
    }
  };

  const handleSelectAccount = (id: number, checked: boolean) => {
    const newSelected = new Set(selectedAccounts);
    if (checked) {
      newSelected.add(id);
    } else {
      newSelected.delete(id);
    }
    setSelectedAccounts(newSelected);
    
    // Update select all state
    setSelectAll(newSelected.size === paginatedAccounts.length && paginatedAccounts.length > 0);
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const allIds = new Set(paginatedAccounts.map(a => a.id));
      setSelectedAccounts(allIds);
    } else {
      setSelectedAccounts(new Set());
    }
    setSelectAll(checked);
  };

  const handleBulkDelete = async () => {
    if (selectedAccounts.size === 0) return;
    
    if (!confirm(`Tem certeza que deseja excluir ${selectedAccounts.size} conta(s) a receber selecionada(s)?`)) return;

    try {
      const deletePromises = Array.from(selectedAccounts).map(id =>
        fetch(`/api/accounts-receivable/${id}`, { 
          method: "DELETE",
          headers: {
            "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
          },
          credentials: 'include'
        })
      );

      await Promise.all(deletePromises);
      
      setSelectedAccounts(new Set());
      setSelectAll(false);
      fetchAccountsReceivable();
    } catch (error) {
      console.error("Error deleting accounts receivable:", error);
    }
  };

  const handleBulkReceive = async () => {
    if (selectedAccounts.size === 0) return;
    
    if (!confirm(`Tem certeza que deseja marcar ${selectedAccounts.size} conta(s) a receber selecionada(s) como RECEBIDO?`)) return;

    try {
      const receivePromises = Array.from(selectedAccounts).map(id =>
        fetch(`/api/accounts-receivable/${id}/status`, { 
          method: "PATCH",
          headers: {
            "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
          },
          credentials: 'include'
        })
      );

      await Promise.all(receivePromises);
      
      setSelectedAccounts(new Set());
      setSelectAll(false);
      fetchAccountsReceivable();
    } catch (error) {
      console.error("Error marking accounts receivable as received:", error);
    }
  };

  // Clear all accounts receivable
  const handleClearAllAccountsReceivable = async () => {
    setClearing(true);
    
    try {
      const response = await fetch('/api/clear-accounts-receivable', {
        method: 'POST',
        credentials: 'include'
      });
      
      const result = await response.json();
      
      if (result.success) {
        setImportResults({
          success: true,
          message: result.message,
          imported: 0,
          errors: []
        });
        fetchAccountsReceivable(); // Refresh the data
      } else {
        setImportResults({
          success: false,
          message: 'Erro ao limpar contas a receber',
          imported: 0,
          errors: [result.error || 'Erro desconhecido']
        });
      }
    } catch (error) {
      setImportResults({
        success: false,
        message: 'Erro ao conectar com o servidor',
        imported: 0,
        errors: ['Erro de conexão']
      });
    } finally {
      setClearing(false);
      setShowClearModal(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(Math.abs(amount));
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString + 'T00:00:00').toLocaleDateString("pt-BR");
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Contas a Receber</h1>
          <p className="text-slate-600">Gerencie suas contas a receber</p>
        </div>
        
        {/* Clear All Accounts Receivable Button */}
        <button
          onClick={() => setShowClearModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 hover:shadow-lg transition-all duration-200 font-medium"
          title="Limpar todas as contas a receber"
        >
          <AlertTriangle className="w-4 h-4" />
          Limpar Tudo
        </button>
      </div>

      <div className="flex items-center justify-between mb-8">
        <div className="invisible">
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Contas a Receber</h1>
          <p className="text-slate-600">Gerencie suas contas a receber</p>
        </div>
        <div className="flex gap-3">
          {selectedAccounts.size > 0 && (
            <>
              <button
                onClick={handleBulkReceive}
                className="flex items-center justify-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-colors font-medium min-w-[140px]"
              >
                <DollarSign className="w-4 h-4" />
                Receber ({selectedAccounts.size})
              </button>
              <button
                onClick={handleBulkDelete}
                className="flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors font-medium min-w-[140px]"
              >
                <Trash2 className="w-4 h-4" />
                Excluir ({selectedAccounts.size})
              </button>
            </>
          )}
          <button 
            onClick={() => setShowFilterModal(true)}
            className={`flex items-center justify-center gap-2 px-4 py-2 rounded-xl transition-colors font-medium relative ${
              hasActiveFilters 
                ? 'bg-blue-600 text-white hover:bg-blue-700' 
                : 'bg-indigo-600 text-white hover:bg-indigo-700'
            }`}
          >
            <Filter className="w-4 h-4" />
            Filtros
            {activeFilterCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
          </button>
          <button 
            onClick={exportToCSV}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-teal-600 text-white rounded-xl hover:bg-teal-700 transition-colors font-medium min-w-[100px]"
          >
            <Download className="w-4 h-4" />
            Exportar
          </button>
          <input
            type="file"
            accept=".csv,.xlsx,.xls"
            onChange={handleImportAccountsReceivable}
            className="hidden"
            id="import-accounts-receivable"
            disabled={importing}
          />
          <button
            onClick={downloadExampleTemplate}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-amber-600 text-white rounded-xl hover:bg-amber-700 transition-colors font-medium min-w-[120px]"
            title="Baixar planilha de exemplo com dados de teste"
          >
            <Download className="w-4 h-4" />
            Baixar Modelo
          </button>
          <label
            htmlFor="import-accounts-receivable"
            className={`flex items-center justify-center gap-2 px-4 py-2 bg-violet-600 text-white rounded-xl hover:bg-violet-700 transition-colors cursor-pointer font-medium min-w-[100px] ${importing ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            <Upload className="w-4 h-4" />
            {importing ? 'Importando...' : 'Importar'}
          </label>
          <button 
            onClick={() => setShowAddForm(true)}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-600 to-cyan-600 text-white rounded-xl hover:shadow-lg transition-all font-medium"
          >
            <Plus className="w-4 h-4" />
            Nova Conta a Receber
          </button>
        </div>
      </div>

      {/* Import Results */}
      {importResults && (
        <div className={`mb-6 p-4 rounded-xl border ${importResults.success 
          ? 'bg-emerald-50 border-emerald-200' 
          : 'bg-red-50 border-red-200'
        }`}>
          <div className="flex items-center gap-2 mb-2">
            {importResults.success ? (
              <div className="w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center">
                <Check className="w-3 h-3 text-white" />
              </div>
            ) : (
              <div className="w-5 h-5 rounded-full bg-red-500 flex items-center justify-center">
                <X className="w-3 h-3 text-white" />
              </div>
            )}
            <h3 className={`font-semibold ${importResults.success ? 'text-emerald-800' : 'text-red-800'}`}>
              {importResults.success ? 'Importação realizada com sucesso!' : 'Erro na importação'}
            </h3>
            <button
              onClick={() => setImportResults(null)}
              className="ml-auto text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <p className={`text-sm ${importResults.success ? 'text-emerald-700' : 'text-red-700'} mb-2`}>
            {importResults.message}
          </p>
          {importResults.imported > 0 && (
            <p className="text-sm text-emerald-600 font-medium">
              Contas importadas: {importResults.imported}
            </p>
          )}
          {importResults.errors.length > 0 && (
            <div className="mt-2">
              <p className="text-sm font-medium text-red-700 mb-1">Erros encontrados:</p>
              <ul className="list-disc list-inside text-sm text-red-600 space-y-1">
                {importResults.errors.map((error, index) => (
                  <li key={index}>{error}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {/* Cards Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Selection Summary Card */}
        {selectedAccounts.size > 0 && (
          <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-6 text-white shadow-xl border-2 border-blue-400/30">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-blue-200 mb-2">Contas Selecionadas</p>
                <p className="text-2xl font-bold text-white mb-1">
                  {selectedAccounts.size} {selectedAccounts.size === 1 ? 'conta' : 'contas'}
                </p>
                <p className={`text-xl font-semibold text-emerald-300`}>
                  Valor Total: {formatCurrency(
                    accountsReceivable
                      .filter(a => selectedAccounts.has(a.id))
                      .reduce((sum, a) => sum + a.amount, 0)
                  )}
                </p>
              </div>
              <div className="p-4 bg-white/15 rounded-xl backdrop-blur-sm">
                <DollarSign className="w-8 h-8 text-blue-200" />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="text-sm text-blue-200">
                Recebidos: {accountsReceivable.filter(a => selectedAccounts.has(a.id) && a.status === 'RECEBIDO').length} | 
                Não Recebidos: {accountsReceivable.filter(a => selectedAccounts.has(a.id) && a.status === 'NÃO RECEBIDO').length}
              </div>
              <button
                onClick={() => {
                  setSelectedAccounts(new Set());
                  setSelectAll(false);
                }}
                className="text-xs bg-white/20 hover:bg-white/30 px-3 py-1 rounded-lg transition-colors"
              >
                Limpar Seleção
              </button>
            </div>
          </div>
        )}

        {/* Summary Cards */}
        <div className={`grid grid-cols-2 gap-4 ${selectedAccounts.size === 0 ? 'lg:col-span-2' : ''}`}>
          {/* Total Amount Card */}
          <div className="bg-gradient-to-r from-emerald-600 to-teal-700 rounded-2xl p-6 text-white shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-emerald-200 mb-2">Valor Total em Aberto</p>
                <p className="text-2xl font-bold text-white">
                  {formatCurrency(
                    (filteredAccountsReceivable.length > 0 || hasActiveFilters ? filteredAccountsReceivable : accountsReceivable)
                      .filter(account => account.status === 'NÃO RECEBIDO')
                      .reduce((sum, account) => sum + account.amount, 0)
                  )}
                </p>
              </div>
              <div className="p-3 bg-white/15 rounded-xl backdrop-blur-sm">
                <DollarSign className="w-6 h-6 text-emerald-200" />
              </div>
            </div>
          </div>

          {/* Total Accounts Card */}
          <div className="bg-gradient-to-r from-purple-600 to-pink-700 rounded-2xl p-6 text-white shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-200 mb-2">Quantidade Total em Aberto</p>
                <p className="text-2xl font-bold text-white">
                  {(filteredAccountsReceivable.length > 0 || hasActiveFilters ? filteredAccountsReceivable : accountsReceivable)
                    .filter(account => account.status === 'NÃO RECEBIDO').length}
                </p>
              </div>
              <div className="p-3 bg-white/15 rounded-xl backdrop-blur-sm">
                <Users className="w-6 h-6 text-purple-200" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add Form Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-8 w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold text-slate-800 mb-6">Nova Conta a Receber</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Data de Vencimento
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.due_date}
                    onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                    className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Valor (R$)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    required
                    value={formData.amount}
                    onChange={(e) => {
                      const value = e.target.value;
                      // Apenas permite valores positivos
                      if (value === '' || parseFloat(value) > 0) {
                        setFormData({ ...formData, amount: value });
                      }
                    }}
                    className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Descrição
                </label>
                <input
                  type="text"
                  required
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Pagador
                </label>
                <input
                  type="text"
                  required
                  value={formData.payer}
                  onChange={(e) => setFormData({ ...formData, payer: e.target.value })}
                  className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Categoria
                  </label>
                  <select
                    value={formData.category_id}
                    onChange={(e) => setFormData({ ...formData, category_id: e.target.value })}
                    className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                  >
                    <option value="">Selecionar categoria</option>
                    {categories.map((category) => (
                      <option key={category.id} value={category.id}>
                        {category.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Centro de Custo
                  </label>
                  <select
                    value={formData.cost_center_id}
                    onChange={(e) => setFormData({ ...formData, cost_center_id: e.target.value })}
                    className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                  >
                    <option value="">Selecionar centro de custo</option>
                    {costCenters.map((costCenter) => (
                      <option key={costCenter.id} value={costCenter.id}>
                        {costCenter.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-4">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-6 py-3 text-slate-600 border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-6 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl hover:shadow-lg transition-all"
                >
                  Criar Conta a Receber
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Form Modal */}
      {showEditModal && editingAccount && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-8 w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold text-slate-800 mb-6">Editar Conta a Receber</h2>
            <form onSubmit={handleUpdateAccount} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Data de Vencimento
                  </label>
                  <input
                    type="date"
                    required
                    value={editFormData.due_date}
                    onChange={(e) => setEditFormData({ ...editFormData, due_date: e.target.value })}
                    className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Valor (R$)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    required
                    value={editFormData.amount}
                    onChange={(e) => {
                      const value = e.target.value;
                      // Apenas permite valores positivos
                      if (value === '' || parseFloat(value) > 0) {
                        setEditFormData({ ...editFormData, amount: value });
                      }
                    }}
                    className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Descrição
                </label>
                <input
                  type="text"
                  required
                  value={editFormData.description}
                  onChange={(e) => setEditFormData({ ...editFormData, description: e.target.value })}
                  className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Pagador
                </label>
                <input
                  type="text"
                  required
                  value={editFormData.payer}
                  onChange={(e) => setEditFormData({ ...editFormData, payer: e.target.value })}
                  className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Categoria
                  </label>
                  <select
                    value={editFormData.category_id}
                    onChange={(e) => setEditFormData({ ...editFormData, category_id: e.target.value })}
                    className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Selecionar categoria</option>
                    {categories.map((category) => (
                      <option key={category.id} value={category.id}>
                        {category.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Centro de Custo
                  </label>
                  <select
                    value={editFormData.cost_center_id}
                    onChange={(e) => setEditFormData({ ...editFormData, cost_center_id: e.target.value })}
                    className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Selecionar centro de custo</option>
                    {costCenters.map((costCenter) => (
                      <option key={costCenter.id} value={costCenter.id}>
                        {costCenter.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Status
                </label>
                <select
                  value={editFormData.status}
                  onChange={(e) => setEditFormData({ ...editFormData, status: e.target.value })}
                  className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="NÃO RECEBIDO">NÃO RECEBIDO</option>
                  <option value="RECEBIDO">RECEBIDO</option>
                </select>
              </div>

              <div className="flex justify-end gap-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowEditModal(false);
                    setEditingAccount(null);
                  }}
                  className="px-6 py-3 text-slate-600 border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl hover:shadow-lg transition-all"
                >
                  Salvar Alterações
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Filter Modal */}
      {showFilterModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-slate-200/50">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold text-slate-800">Filtrar Contas a Receber</h3>
                {activeFilterCount > 0 && (
                  <span className="bg-blue-100 text-blue-800 text-sm px-3 py-1 rounded-full">
                    {activeFilterCount} filtro{activeFilterCount > 1 ? 's' : ''} ativo{activeFilterCount > 1 ? 's' : ''}
                  </span>
                )}
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Date Range */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Data De</label>
                  <input
                    type="date"
                    value={filters.dateFrom}
                    onChange={(e) => setFilters({...filters, dateFrom: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Data Até</label>
                  <input
                    type="date"
                    value={filters.dateTo}
                    onChange={(e) => setFilters({...filters, dateTo: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Category and Cost Center */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Categoria</label>
                  <select
                    value={filters.category}
                    onChange={(e) => setFilters({...filters, category: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  >
                    <option value="">Todas as categorias</option>
                    {categories.map((category) => (
                      <option key={category.id} value={category.name}>
                        {category.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Centro de Custo</label>
                  <select
                    value={filters.costCenter}
                    onChange={(e) => setFilters({...filters, costCenter: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  >
                    <option value="">Todos os centros de custo</option>
                    {costCenters.map((costCenter) => (
                      <option key={costCenter.id} value={costCenter.name}>
                        {costCenter.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Status and Payer */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Status</label>
                  <select
                    value={filters.status}
                    onChange={(e) => setFilters({...filters, status: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  >
                    <option value="">Todos os status</option>
                    <option value="RECEBIDO">RECEBIDO</option>
                    <option value="NÃO RECEBIDO">NÃO RECEBIDO</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Pagador</label>
                  <input
                    type="text"
                    value={filters.payer}
                    onChange={(e) => setFilters({...filters, payer: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                    placeholder="Buscar por pagador..."
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Descrição</label>
                <input
                  type="text"
                  value={filters.description}
                  onChange={(e) => setFilters({...filters, description: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="Buscar por descrição..."
                />
              </div>

              {/* Amount Range */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Valor Mínimo (R$)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={filters.amountFrom}
                    onChange={(e) => setFilters({...filters, amountFrom: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                    placeholder="0,00"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Valor Máximo (R$)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={filters.amountTo}
                    onChange={(e) => setFilters({...filters, amountTo: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                    placeholder="0,00"
                  />
                </div>
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-between">
              <div className="flex gap-3">
                <button
                  onClick={() => setShowFilterModal(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  onClick={clearFilters}
                  className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  Limpar Filtros
                </button>
              </div>
              <button
                onClick={() => setShowFilterModal(false)}
                className="px-6 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:shadow-lg transition-all font-medium"
              >
                Aplicar Filtros
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Accounts List */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-200/50 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200/50">
          <h2 className="text-xl font-semibold text-slate-800">Lista de Contas a Receber</h2>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full" onContextMenu={handleRightClick}>
            <thead className="bg-slate-50 border-b border-slate-200/50">
              <tr>
                <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">
                  <input
                    type="checkbox"
                    checked={selectAll}
                    onChange={(e) => handleSelectAll(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500"
                  />
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Vencimento</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Descrição</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Pagador</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Categoria</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Centro de Custo</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-slate-700">Valor</th>
                <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">Status</th>
                <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/50">
              {paginatedAccounts.map((account) => (
                <tr key={account.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4 text-center">
                    <input
                      type="checkbox"
                      checked={selectedAccounts.has(account.id)}
                      onChange={(e) => handleSelectAccount(account.id, e.target.checked)}
                      className="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500"
                    />
                  </td>
                  <td className="px-6 py-4">
                    {editingId === account.id && editingField === 'due_date' ? (
                      <div className="flex items-center gap-2">
                        <input
                          type="date"
                          value={editingValue}
                          onChange={(e) => setEditingValue(e.target.value)}
                          className="w-32 px-3 py-2 border border-slate-300 rounded-lg text-sm"
                          autoFocus
                        />
                        <button onClick={saveEdit} className="text-emerald-600 hover:text-emerald-700">
                          <Check className="w-4 h-4" />
                        </button>
                        <button onClick={cancelEdit} className="text-red-600 hover:text-red-700">
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleEdit(account.id, 'due_date', account.due_date)}
                        className="text-slate-600 hover:text-slate-800 flex items-center gap-2 group"
                      >
                        <Calendar className="w-4 h-4 text-slate-400" />
                        <span className="text-sm font-medium text-slate-800">
                          {formatDate(account.due_date)}
                        </span>
                        <Edit3 className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </button>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    {editingId === account.id && editingField === 'description' ? (
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={editingValue}
                          onChange={(e) => setEditingValue(e.target.value)}
                          className="flex-1 px-3 py-2 border border-slate-300 rounded-lg text-sm"
                          autoFocus
                        />
                        <button onClick={saveEdit} className="text-emerald-600 hover:text-emerald-700">
                          <Check className="w-4 h-4" />
                        </button>
                        <button onClick={cancelEdit} className="text-red-600 hover:text-red-700">
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleEdit(account.id, 'description', account.description)}
                        className="text-slate-800 hover:text-slate-600 flex items-center gap-2 group font-medium"
                      >
                        <div className="text-sm font-medium text-slate-800">
                          {account.description}
                        </div>
                        <Edit3 className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </button>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    {editingId === account.id && editingField === 'payer' ? (
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={editingValue}
                          onChange={(e) => setEditingValue(e.target.value)}
                          className="flex-1 px-3 py-2 border border-slate-300 rounded-lg text-sm"
                          autoFocus
                        />
                        <button onClick={saveEdit} className="text-emerald-600 hover:text-emerald-700">
                          <Check className="w-4 h-4" />
                        </button>
                        <button onClick={cancelEdit} className="text-red-600 hover:text-red-700">
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleEdit(account.id, 'payer', account.payer)}
                        className="text-slate-600 hover:text-slate-800 flex items-center gap-2 group"
                      >
                        <Users className="w-4 h-4 text-slate-400" />
                        <span className="text-sm text-slate-600">{account.payer}</span>
                        <Edit3 className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </button>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-slate-600">{account.category_name || '-'}</span>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">
                    {account.cost_center_name || "-"}
                  </td>
                  <td className={`px-6 py-4 text-right font-semibold whitespace-nowrap text-emerald-600`}>
                    {editingId === account.id && editingField === 'amount' ? (
                      <div className="flex items-center justify-end gap-2">
                        <input
                          type="number"
                          step="0.01"
                          min="0.01"
                          value={editingValue}
                          onChange={(e) => {
                            const value = e.target.value;
                            // Apenas permite valores positivos
                            if (value === '' || parseFloat(value) > 0) {
                              setEditingValue(value);
                            }
                          }}
                          className="w-32 px-3 py-2 border border-slate-300 rounded-lg text-sm text-right"
                          autoFocus
                        />
                        <button onClick={saveEdit} className="text-emerald-600 hover:text-emerald-700">
                          <Check className="w-4 h-4" />
                        </button>
                        <button onClick={cancelEdit} className="text-red-600 hover:text-red-700">
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleEdit(account.id, 'amount', account.amount)}
                        className="hover:bg-slate-100 px-2 py-1 rounded transition-colors cursor-pointer w-full text-right"
                        title="Clique para editar o valor"
                      >
                        {formatCurrency(account.amount)}
                      </button>
                    )}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <button
                      onClick={() => toggleStatus(account.id)}
                      className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium transition-all hover:scale-105 hover:shadow-md cursor-pointer ${
                        account.status === 'RECEBIDO'
                          ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                          : 'bg-red-100 text-red-800 hover:bg-red-200'
                      }`}
                      title="Clique para alterar o status"
                    >
                      {account.status}
                    </button>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        onClick={() => handleEditAccount(account)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Editar conta a receber"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => deleteAccount(account.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Excluir conta a receber"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {(filteredAccountsReceivable.length > 0 || hasActiveFilters ? filteredAccountsReceivable : accountsReceivable).length > 0 && (
          <div className="px-6 py-4 border-t border-slate-200/50 bg-slate-50/50">
            <div className="flex items-center justify-between">
              {/* Items per page selector */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-slate-600">Itens por página:</span>
                <select
                  value={itemsPerPage}
                  onChange={(e) => handleItemsPerPageChange(Number(e.target.value))}
                  className="px-3 py-1 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                >
                  <option value={5}>5</option>
                  <option value={10}>10</option>
                  <option value={20}>20</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>

              {/* Page info and navigation */}
              <div className="flex items-center gap-4">
                <span className="text-sm text-slate-600">
                  Mostrando {startIndex + 1} a {Math.min(endIndex, (filteredAccountsReceivable.length > 0 || hasActiveFilters ? filteredAccountsReceivable : accountsReceivable).length)} de {(filteredAccountsReceivable.length > 0 || hasActiveFilters ? filteredAccountsReceivable : accountsReceivable).length} registros
                </span>
                
                <div className="flex items-center gap-2">
                  {/* Previous button */}
                  <button
                    onClick={() => goToPage(currentPage - 1)}
                    disabled={currentPage === 1}
                    className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    title="Página anterior"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>

                  {/* Page number selector */}
                  <div className="flex items-center gap-1">
                    {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                      let pageNumber;
                      if (totalPages <= 5) {
                        pageNumber = i + 1;
                      } else if (currentPage <= 3) {
                        pageNumber = i + 1;
                      } else if (currentPage >= totalPages - 2) {
                        pageNumber = totalPages - 4 + i;
                      } else {
                        pageNumber = currentPage - 2 + i;
                      }

                      return (
                        <button
                          key={pageNumber}
                          onClick={() => goToPage(pageNumber)}
                          className={`px-3 py-1 text-sm rounded-lg transition-colors ${
                            currentPage === pageNumber
                              ? 'bg-emerald-600 text-white'
                              : 'text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          {pageNumber}
                        </button>
                      );
                    })}
                  </div>

                  {/* Next button */}
                  <button
                    onClick={() => goToPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                    className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    title="Próxima página"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Direct page input */}
                {totalPages > 5 && (
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-600">Ir para:</span>
                    <input
                      type="number"
                      min={1}
                      max={totalPages}
                      value={currentPage}
                      onChange={(e) => {
                        const page = Number(e.target.value);
                        if (page >= 1 && page <= totalPages) {
                          goToPage(page);
                        }
                      }}
                      className="w-16 px-2 py-1 border border-slate-300 rounded-lg text-sm text-center focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {(hasActiveFilters ? filteredAccountsReceivable.length === 0 : accountsReceivable.length === 0) && (
          <div className="text-center py-12">
            <TrendingUp className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">
              {hasActiveFilters ? 'Nenhuma conta encontrada' : 'Nenhuma conta a receber'}
            </h3>
            <p className="text-slate-500 mb-6">
              {hasActiveFilters 
                ? 'Tente ajustar os filtros para encontrar as contas desejadas.' 
                : 'Comece adicionando sua primeira conta a receber.'
              }
            </p>
            {!hasActiveFilters && (
              <button
                onClick={() => setShowAddForm(true)}
                className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Criar Recebimento
              </button>
            )}
            {hasActiveFilters && (
              <button
                onClick={clearFilters}
                className="inline-flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors"
              >
                <Filter className="w-4 h-4" />
                Limpar Filtros
              </button>
            )}
          </div>
        )}
      </div>

      {/* Footer Information */}
      <div className="mt-8 py-4 border-t border-slate-200/50">
        <div className="text-center text-sm text-slate-600">
          {hasActiveFilters ? (
            <>
              Registros filtrados: <span className="font-semibold">{filteredAccountsReceivable.length}</span> de {accountsReceivable.length}
              {filteredAccountsReceivable.length > 0 && (
                <span className="ml-4">
                  Mostrando {Math.min(startIndex + 1, filteredAccountsReceivable.length)} a {Math.min(endIndex, filteredAccountsReceivable.length)} de {filteredAccountsReceivable.length} registros filtrados
                </span>
              )}
            </>
          ) : (
            <>
              Total de registros: <span className="font-semibold">{accountsReceivable.length}</span>
              {accountsReceivable.length > 0 && (
                <span className="ml-4">
                  Mostrando {Math.min(startIndex + 1, accountsReceivable.length)} a {Math.min(endIndex, accountsReceivable.length)} de {accountsReceivable.length} registros
                </span>
              )}
            </>
          )}
        </div>
      </div>

      {/* Clear All Accounts Receivable Modal */}
      {showClearModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-200/50 flex items-center gap-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold text-slate-800">Limpar Todas as Contas a Receber</h3>
            </div>
            
            <div className="p-6">
              <div className="mb-4">
                <p className="text-slate-700 mb-2">
                  <strong>Atenção:</strong> Esta ação irá remover permanentemente:
                </p>
                <ul className="list-disc list-inside text-sm text-slate-600 space-y-1 ml-4">
                  <li>Todas as contas a receber cadastradas</li>
                  <li>Histórico de recebimentos</li>
                  <li>Dados de clientes e valores a receber</li>
                </ul>
              </div>
              
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
                <p className="text-red-800 text-sm font-medium">
                  ⚠️ Esta ação não pode ser desfeita!
                </p>
                <p className="text-red-700 text-sm">
                  Certifique-se de ter um backup dos seus dados se necessário.
                </p>
              </div>
              
              <p className="text-slate-600 text-sm">
                As categorias e centros de custo permanecerão inalterados.
              </p>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => setShowClearModal(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                disabled={clearing}
              >
                Cancelar
              </button>
              <button
                onClick={handleClearAllAccountsReceivable}
                disabled={clearing}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {clearing ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                    Limpando...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    Confirmar Limpeza
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
