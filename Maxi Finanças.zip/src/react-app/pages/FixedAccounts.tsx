import { useEffect, useState } from "react";
import { Plus, Trash2, DollarSign, Filter, Edit3, Calendar, User, ToggleLeft, ToggleRight, Download, Upload, X, ChevronLeft, ChevronRight, AlertTriangle, CreditCard, RotateCcw } from "lucide-react";
import { FixedAccountWithDetails, Category, CostCenter } from "@/shared/types";
import * as XLSX from 'xlsx';

export default function FixedAccounts() {
  const [fixedAccounts, setFixedAccounts] = useState<FixedAccountWithDetails[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingAccount, setEditingAccount] = useState<FixedAccountWithDetails | null>(null);
  
  const [newAccount, setNewAccount] = useState({
    due_day: '',
    description: '',
    amount: '',
    category_id: '',
    cost_center_id: '',
    payee: '',
    is_active: true,
    status: 'NÃO PAGO'
  });
  
  const [editAccount, setEditAccount] = useState({
    due_day: '',
    description: '',
    amount: '',
    category_id: '',
    cost_center_id: '',
    payee: '',
    is_active: true,
    status: 'NÃO PAGO'
  });

  // Amount editing states
  const [editingAmountId, setEditingAmountId] = useState<number | null>(null);
  const [editingAmountValue, setEditingAmountValue] = useState('');

  // Filter states
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [filters, setFilters] = useState({
    categoryIds: [] as string[],
    costCenterIds: [] as string[],
    isActive: '',
    payee: '',
    dueDayFrom: '',
    dueDayTo: '',
    status: ''
  });
  const [appliedFilters, setAppliedFilters] = useState({
    categoryIds: [] as string[],
    costCenterIds: [] as string[],
    isActive: '',
    payee: '',
    dueDayFrom: '',
    dueDayTo: '',
    status: ''
  });

  // Import state
  const [importing, setImporting] = useState(false);
  const [importResults, setImportResults] = useState<{
    success: boolean;
    message: string;
    imported: number;
    errors: string[];
  } | null>(null);

  // Selection state
  const [selectedAccounts, setSelectedAccounts] = useState<Set<number>>(new Set());
  const [selectAll, setSelectAll] = useState(false);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // Clear data state
  const [showClearModal, setShowClearModal] = useState(false);
  const [clearing, setClearing] = useState(false);

  // Reset payments state
  const [showResetPaymentsModal, setShowResetPaymentsModal] = useState(false);
  const [resettingPayments, setResettingPayments] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      console.log('🔄 Fetching data for Fixed Accounts...');
      
      // Get user data from localStorage to include in headers
      const savedUser = localStorage.getItem('maxifinancas_user');
      let authHeaders: { [key: string]: string } = {
        'Content-Type': 'application/json',
      };
      
      if (savedUser) {
        try {
          const userData = JSON.parse(savedUser);
          const sessionData = JSON.stringify(userData);
          
          // Include user data in Authorization header as fallback
          authHeaders['Authorization'] = `Bearer ${btoa(sessionData)}`;
          
          console.log('🔑 FIXED ACCOUNTS: Including auth header for user:', userData.id);
        } catch (e) {
          console.error('🔑 FIXED ACCOUNTS: Error parsing user data:', e);
        }
      }
      
      const [accountsRes, categoriesRes, costCentersRes] = await Promise.all([
        fetch("/api/fixed-accounts", {
          method: 'GET',
          credentials: 'include',
          headers: authHeaders
        }),
        fetch("/api/categories", {
          method: 'GET',
          credentials: 'include',
          headers: authHeaders
        }),
        fetch("/api/cost-centers", {
          method: 'GET',
          credentials: 'include',
          headers: authHeaders
        })
      ]);

      console.log('📊 API responses:', {
        accounts: accountsRes.status,
        categories: categoriesRes.status,
        costCenters: costCentersRes.status
      });

      if (!accountsRes.ok) {
        throw new Error(`Erro ao buscar contas fixas: ${accountsRes.status} ${accountsRes.statusText}`);
      }
      if (!categoriesRes.ok) {
        throw new Error(`Erro ao buscar categorias: ${categoriesRes.status} ${categoriesRes.statusText}`);
      }
      if (!costCentersRes.ok) {
        throw new Error(`Erro ao buscar centros de custo: ${costCentersRes.status} ${costCentersRes.statusText}`);
      }

      const [accountsData, categoriesData, costCentersData] = await Promise.all([
        accountsRes.json(),
        categoriesRes.json(),
        costCentersRes.json()
      ]);

      console.log('✅ Data fetched successfully:', {
        accounts: accountsData?.length || 0,
        categories: categoriesData?.length || 0,
        costCenters: costCentersData?.length || 0
      });

      setFixedAccounts(Array.isArray(accountsData) ? accountsData : []);
      setCategories(Array.isArray(categoriesData) ? categoriesData : []);
      setCostCenters(Array.isArray(costCentersData) ? costCentersData : []);
    } catch (error) {
      console.error("❌ Error fetching data:", error);
      setError(error instanceof Error ? error.message : 'Erro desconhecido ao carregar dados');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateAccount = async () => {
    try {
      // Ensure amount is negative for expenses
      let amount = parseFloat(newAccount.amount);
      if (amount > 0) {
        amount = -amount;
      }
      
      // Get auth headers
      const savedUser = localStorage.getItem('maxifinancas_user');
      let authHeaders: { [key: string]: string } = { "Content-Type": "application/json" };
      
      if (savedUser) {
        try {
          const userData = JSON.parse(savedUser);
          const sessionData = JSON.stringify(userData);
          authHeaders['Authorization'] = `Bearer ${btoa(sessionData)}`;
        } catch (e) {
          console.error('Error parsing user data:', e);
        }
      }
      
      const response = await fetch("/api/fixed-accounts", {
        method: "POST",
        headers: authHeaders,
        credentials: 'include',
        body: JSON.stringify({
          ...newAccount,
          due_day: parseInt(newAccount.due_day),
          amount: amount,
          category_id: newAccount.category_id ? parseInt(newAccount.category_id) : undefined,
          cost_center_id: newAccount.cost_center_id ? parseInt(newAccount.cost_center_id) : undefined,
        })
      });

      if (response.ok) {
        setShowModal(false);
        setNewAccount({
          due_day: '',
          description: '',
          amount: '',
          category_id: '',
          cost_center_id: '',
          payee: '',
          is_active: true,
          status: 'NÃO PAGO'
        });
        fetchData();
      }
    } catch (error) {
      console.error("Error creating fixed account:", error);
    }
  };

  const handleEditAccount = (account: FixedAccountWithDetails) => {
    setEditingAccount(account);
    setEditAccount({
      due_day: account.due_day.toString(),
      description: account.description,
      amount: account.amount.toString(),
      category_id: account.category_id?.toString() || '',
      cost_center_id: account.cost_center_id?.toString() || '',
      payee: account.payee,
      is_active: Boolean(account.is_active),
      status: account.status || 'NÃO PAGO'
    });
    setShowEditModal(true);
  };

  const handleUpdateAccount = async () => {
    if (!editingAccount) {
      console.log('❌ UPDATE: No editing account found');
      return;
    }

    try {
      console.log('🔄 UPDATE: Starting fixed account update for ID:', editingAccount.id);
      console.log('🔄 UPDATE: Edit data:', editAccount);
      
      // Validate required fields
      if (!editAccount.description || !editAccount.amount || !editAccount.payee || !editAccount.due_day) {
        console.log('❌ UPDATE: Missing required fields');
        alert('Por favor, preencha todos os campos obrigatórios: Descrição, Valor, A Quem Pagar e Dia do Vencimento.');
        return;
      }

      // Validate due_day range
      const dueDay = parseInt(editAccount.due_day);
      if (isNaN(dueDay) || dueDay < 1 || dueDay > 31) {
        console.log('❌ UPDATE: Invalid due day:', dueDay);
        alert('Dia do vencimento deve ser um número entre 1 e 31.');
        return;
      }

      // Ensure amount is negative for expenses  
      let amount = parseFloat(editAccount.amount);
      if (isNaN(amount)) {
        console.log('❌ UPDATE: Invalid amount value');
        alert('Por favor, insira um valor numérico válido.');
        return;
      }
      
      if (amount > 0) {
        amount = -amount;
      }
      
      console.log('💰 UPDATE: Final amount:', amount);
      
      // Get auth headers
      const savedUser = localStorage.getItem('maxifinancas_user');
      let authHeaders: { [key: string]: string } = { "Content-Type": "application/json" };
      
      if (savedUser) {
        try {
          const userData = JSON.parse(savedUser);
          const sessionData = JSON.stringify(userData);
          authHeaders['Authorization'] = `Bearer ${btoa(sessionData)}`;
          console.log('🔑 UPDATE: Auth headers prepared for user:', userData.id);
        } catch (e) {
          console.error('🔑 UPDATE: Error parsing user data:', e);
        }
      }
      
      // Create update data matching the expected schema
      const updateData: any = {
        due_day: dueDay,
        description: editAccount.description.trim(),
        amount: amount,
        payee: editAccount.payee.trim(),
        is_active: editAccount.is_active,
        status: editAccount.status || 'NÃO PAGO'
      };

      // Only include category_id if it has a value
      if (editAccount.category_id && editAccount.category_id.trim() !== '') {
        const categoryId = parseInt(editAccount.category_id);
        if (!isNaN(categoryId)) {
          updateData.category_id = categoryId;
        }
      }

      // Only include cost_center_id if it has a value
      if (editAccount.cost_center_id && editAccount.cost_center_id.trim() !== '') {
        const costCenterId = parseInt(editAccount.cost_center_id);
        if (!isNaN(costCenterId)) {
          updateData.cost_center_id = costCenterId;
        }
      }
      
      console.log('📤 UPDATE: Sending update data:', updateData);
      
      const response = await fetch(`/api/fixed-accounts/${editingAccount.id}`, {
        method: "PUT",
        headers: authHeaders,
        credentials: 'include',
        body: JSON.stringify(updateData)
      });

      console.log('📥 UPDATE: Response status:', response.status);
      console.log('📥 UPDATE: Response headers:', Object.fromEntries(response.headers.entries()));

      if (response.ok) {
        console.log('✅ UPDATE: Fixed account updated successfully');
        setShowEditModal(false);
        setEditingAccount(null);
        setEditAccount({
          due_day: '',
          description: '',
          amount: '',
          category_id: '',
          cost_center_id: '',
          payee: '',
          is_active: true,
          status: 'NÃO PAGO'
        });
        fetchData();
        
        // Show success message
        alert('Conta fixa atualizada com sucesso!');
      } else {
        console.log('❌ UPDATE: Failed to update fixed account, status:', response.status);
        let errorData;
        try {
          const responseText = await response.text();
          console.log('❌ UPDATE: Raw response:', responseText);
          if (responseText) {
            errorData = JSON.parse(responseText);
          }
        } catch (parseError) {
          console.log('❌ UPDATE: Error parsing response:', parseError);
        }
        console.log('❌ UPDATE: Error response:', errorData);
        
        let errorMessage = 'Erro ao atualizar conta fixa';
        if (errorData && errorData.error) {
          errorMessage += ': ' + errorData.error;
        } else if (response.status === 404) {
          errorMessage += ': Conta fixa não encontrada';
        } else if (response.status === 401) {
          errorMessage += ': Não autorizado. Faça login novamente.';
        } else if (response.status >= 500) {
          errorMessage += ': Erro interno do servidor';
        } else {
          errorMessage += `: Erro HTTP ${response.status}`;
        }
        alert(errorMessage);
      }
    } catch (error) {
      console.error("❌ UPDATE: Network error updating fixed account:", error);
      alert('Erro de conexão ao atualizar conta fixa. Verifique sua conexão e tente novamente.');
    }
  };

  const handleToggleStatus = async (id: number) => {
    // Find the account to get current status
    const account = fixedAccounts.find(a => a.id === id);
    if (!account) return;
    
    const currentStatus = account.status || 'NÃO PAGO';
    const newStatus = currentStatus === 'PAGO' ? 'NÃO PAGO' : 'PAGO';
    
    // Show confirmation dialog
    if (!confirm(`Tem certeza que deseja alterar o status desta conta fixa de "${currentStatus}" para "${newStatus}"?`)) {
      return;
    }
    
    try {
      const response = await fetch(`/api/fixed-accounts/${id}/status`, {
        method: "PATCH",
        credentials: 'include'
      });

      if (response.ok) {
        fetchData();
      }
    } catch (error) {
      console.error("Error toggling fixed account status:", error);
    }
  };

  const handleStartEditAmount = (id: number, currentAmount: number) => {
    setEditingAmountId(id);
    setEditingAmountValue(currentAmount.toString());
  };

  const handleCancelEditAmount = () => {
    setEditingAmountId(null);
    setEditingAmountValue('');
  };

  const handleSaveAmount = async (id: number) => {
    try {
      console.log('💾 SAVE AMOUNT: Starting amount save for fixed account:', id);
      console.log('💾 SAVE AMOUNT: New value:', editingAmountValue);
      
      let amount = parseFloat(editingAmountValue);
      if (isNaN(amount)) {
        console.log('❌ SAVE AMOUNT: Invalid numeric value');
        alert("Por favor, insira um valor numérico válido");
        return;
      }

      // Ensure amount is negative for expenses
      if (amount > 0) {
        amount = -amount;
      }

      console.log('💾 SAVE AMOUNT: Final amount to save:', amount);

      // Get auth headers
      const savedUser = localStorage.getItem('maxifinancas_user');
      const authHeaders: { [key: string]: string } = {
        'Content-Type': 'application/json'
      };
      
      if (savedUser) {
        try {
          const userData = JSON.parse(savedUser);
          const sessionData = JSON.stringify(userData);
          authHeaders['Authorization'] = `Bearer ${btoa(sessionData)}`;
          console.log('💾 SAVE AMOUNT: Auth headers prepared for user:', userData.id);
        } catch (e) {
          console.error('💾 SAVE AMOUNT: Error parsing user data:', e);
        }
      }

      console.log('💾 SAVE AMOUNT: Making request to update amount');
      const response = await fetch(`/api/fixed-accounts/${id}/amount`, {
        method: "PATCH",
        headers: authHeaders,
        credentials: 'include',
        body: JSON.stringify({ amount })
      });

      console.log('💾 SAVE AMOUNT: Response status:', response.status);

      if (response.ok) {
        console.log('✅ SAVE AMOUNT: Amount updated successfully');
        setEditingAmountId(null);
        setEditingAmountValue('');
        fetchData();
      } else {
        console.log('❌ SAVE AMOUNT: Failed to update amount, status:', response.status);
        const errorData = await response.json().catch(() => null);
        console.log('❌ SAVE AMOUNT: Error response:', errorData);
        alert("Erro ao atualizar o valor");
      }
    } catch (error) {
      console.error("❌ SAVE AMOUNT: Network error updating fixed account amount:", error);
      alert("Erro ao atualizar o valor");
    }
  };

  const handleDeleteAccount = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir esta conta fixa?")) return;

    try {
      const response = await fetch(`/api/fixed-accounts/${id}`, {
        method: "DELETE",
        credentials: 'include'
      });

      if (response.ok) {
        fetchData();
      }
    } catch (error) {
      console.error("Error deleting fixed account:", error);
    }
  };

  const handleSelectAccount = (id: number, checked: boolean) => {
    const newSelected = new Set(selectedAccounts);
    if (checked) {
      newSelected.add(id);
    } else {
      newSelected.delete(id);
    }
    setSelectedAccounts(newSelected);
    
    // Update select all state
    setSelectAll(newSelected.size === paginatedAccounts.length && paginatedAccounts.length > 0);
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const allIds = new Set(paginatedAccounts.map(a => a.id));
      setSelectedAccounts(allIds);
    } else {
      setSelectedAccounts(new Set());
    }
    setSelectAll(checked);
  };

  const handleBulkDelete = async () => {
    if (selectedAccounts.size === 0) return;
    
    if (!confirm(`Tem certeza que deseja excluir ${selectedAccounts.size} conta(s) fixa(s) selecionada(s)?`)) return;

    try {
      console.log('🗑️ BULK DELETE: Starting bulk delete for accounts:', Array.from(selectedAccounts));
      
      // Get auth headers
      const savedUser = localStorage.getItem('maxifinancas_user');
      const authHeaders: { [key: string]: string } = {
        'Content-Type': 'application/json'
      };
      
      if (savedUser) {
        try {
          const userData = JSON.parse(savedUser);
          const sessionData = JSON.stringify(userData);
          authHeaders['Authorization'] = `Bearer ${btoa(sessionData)}`;
          console.log('🗑️ BULK DELETE: Auth headers prepared for user:', userData.id);
        } catch (e) {
          console.error('🗑️ BULK DELETE: Error parsing user data:', e);
        }
      }

      const deletePromises = Array.from(selectedAccounts).map(async (id) => {
        console.log(`🗑️ BULK DELETE: Deleting account ${id}`);
        const response = await fetch(`/api/fixed-accounts/${id}`, { 
          method: "DELETE", 
          credentials: 'include',
          ...(authHeaders.Authorization && { headers: authHeaders })
        });
        
        if (!response.ok) {
          console.error(`🗑️ BULK DELETE: Failed to delete account ${id}:`, response.status, response.statusText);
          throw new Error(`Failed to delete account ${id}`);
        }
        
        console.log(`✅ BULK DELETE: Successfully deleted account ${id}`);
        return response;
      });

      await Promise.all(deletePromises);
      
      console.log('✅ BULK DELETE: All accounts deleted successfully');
      setSelectedAccounts(new Set());
      setSelectAll(false);
      fetchData();
    } catch (error) {
      console.error("❌ BULK DELETE: Error deleting fixed accounts:", error);
      alert("Erro ao excluir contas fixas selecionadas. Tente novamente.");
    }
  };

  const handleBulkPay = async () => {
    if (selectedAccounts.size === 0) return;
    
    if (!confirm(`Tem certeza que deseja marcar ${selectedAccounts.size} conta(s) fixa(s) selecionada(s) como PAGO?`)) return;

    try {
      const payPromises = Array.from(selectedAccounts).map(id =>
        fetch(`/api/fixed-accounts/${id}/bulk-pay`, { method: "PATCH", credentials: 'include' })
      );

      await Promise.all(payPromises);
      
      setSelectedAccounts(new Set());
      setSelectAll(false);
      fetchData();
    } catch (error) {
      console.error("Error marking fixed accounts as paid:", error);
    }
  };

  const formatCurrency = (amount: number) => {
    const formatted = new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(Math.abs(amount));
    
    return amount < 0 ? `-${formatted}` : formatted;
  };

  const getCategoryById = (id: number) => categories.find(c => c.id === id);
  const getCostCenterById = (id: number) => costCenters.find(cc => cc.id === id);

  // Apply filters
  const filteredAccounts = fixedAccounts.filter(account => {
    // Category filter
    if (appliedFilters.categoryIds.length > 0) {
      const categoryIdNumbers = appliedFilters.categoryIds.map(id => parseInt(id));
      if (!account.category_id || !categoryIdNumbers.includes(account.category_id)) {
        return false;
      }
    }

    // Cost center filter
    if (appliedFilters.costCenterIds.length > 0) {
      const costCenterIdNumbers = appliedFilters.costCenterIds.map(id => parseInt(id));
      if (!account.cost_center_id || !costCenterIdNumbers.includes(account.cost_center_id)) {
        return false;
      }
    }

    // Active filter
    if (appliedFilters.isActive === 'active' && !account.is_active) {
      return false;
    }
    if (appliedFilters.isActive === 'inactive' && account.is_active) {
      return false;
    }

    // Payee filter
    if (appliedFilters.payee && !account.payee.toLowerCase().includes(appliedFilters.payee.toLowerCase())) {
      return false;
    }

    // Due day range filter
    if (appliedFilters.dueDayFrom && account.due_day < parseInt(appliedFilters.dueDayFrom)) {
      return false;
    }
    if (appliedFilters.dueDayTo && account.due_day > parseInt(appliedFilters.dueDayTo)) {
      return false;
    }

    // Status filter
    if (appliedFilters.status && (account.status || 'NÃO PAGO') !== appliedFilters.status) {
      return false;
    }

    return true;
  });

  const totalAmount = filteredAccounts.reduce((sum, account) => {
    if (account.is_active && (account.status || 'NÃO PAGO') === 'NÃO PAGO') {
      return sum + account.amount;
    }
    return sum;
  }, 0);

  // Pagination calculations
  const totalPages = Math.ceil(filteredAccounts.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedAccounts = filteredAccounts.slice(startIndex, endIndex);

  // Reset to first page when items per page changes
  const handleItemsPerPageChange = (newItemsPerPage: number) => {
    setItemsPerPage(newItemsPerPage);
    setCurrentPage(1);
    // Clear selections when changing pagination
    setSelectedAccounts(new Set());
    setSelectAll(false);
  };

  // Navigate to specific page
  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
      // Clear selections when changing page
      setSelectedAccounts(new Set());
      setSelectAll(false);
    }
  };

  // Handle right click to clear all selections
  const handleRightClick = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent browser context menu
    if (selectedAccounts.size > 0) {
      setSelectedAccounts(new Set());
      setSelectAll(false);
    }
  };

  // Filter functions
  const handleApplyFilters = () => {
    setAppliedFilters(filters);
    setCurrentPage(1); // Reset to first page
    setSelectedAccounts(new Set()); // Clear selections
    setSelectAll(false);
    setShowFilterModal(false);
  };

  const handleClearFilters = () => {
    const emptyFilters = {
      categoryIds: [] as string[],
      costCenterIds: [] as string[],
      isActive: '',
      payee: '',
      dueDayFrom: '',
      dueDayTo: '',
      status: ''
    };
    setFilters(emptyFilters);
    setAppliedFilters(emptyFilters);
    setCurrentPage(1);
    setSelectedAccounts(new Set());
    setSelectAll(false);
    setShowFilterModal(false);
  };

  const handleOpenFilterModal = () => {
    setFilters(appliedFilters);
    setShowFilterModal(true);
  };

  // Count active filters
  const activeFilterCount = Object.entries(appliedFilters).filter(([key, value]) => {
    if (key === 'categoryIds' || key === 'costCenterIds') {
      return Array.isArray(value) && value.length > 0;
    }
    return value !== '';
  }).length;

  // Import functions
  const handleImportFixedAccounts = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImporting(true);
    setImportResults(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      // Get user data for authorization header (no Content-Type for FormData)
      const userData = localStorage.getItem('maxifinancas_user');
      const authHeaders = userData ? {
        'Authorization': `Bearer ${btoa(userData)}`
      } : {};

      const response = await fetch('/api/fixed-accounts/import', {
        method: 'POST',
        credentials: 'include',
        headers: authHeaders,
        body: formData
      });

      const result = await response.json();
      setImportResults(result);
      
      if (result.success) {
        fetchData();
      }
    } catch (error) {
      setImportResults({
        success: false,
        message: 'Erro ao importar contas fixas',
        imported: 0,
        errors: ['Erro de conexão com o servidor']
      });
    } finally {
      setImporting(false);
      // Reset file input
      event.target.value = '';
    }
  };

  // Clear all fixed accounts
  const handleClearAllFixedAccounts = async () => {
    console.log('🧹 CLEAR ALL: Starting clear all fixed accounts');
    setClearing(true);
    
    try {
      // Get auth headers
      const savedUser = localStorage.getItem('maxifinancas_user');
      const authHeaders: { [key: string]: string } = {
        'Content-Type': 'application/json'
      };
      
      if (savedUser) {
        try {
          const userData = JSON.parse(savedUser);
          const sessionData = JSON.stringify(userData);
          authHeaders['Authorization'] = `Bearer ${btoa(sessionData)}`;
          console.log('🧹 CLEAR ALL: Auth headers prepared for user:', userData.id);
        } catch (e) {
          console.error('🧹 CLEAR ALL: Error parsing user data:', e);
        }
      }

      console.log('🧹 CLEAR ALL: Making request to clear all fixed accounts');
      const response = await fetch('/api/clear-fixed-accounts', {
        method: 'POST',
        credentials: 'include',
        ...(authHeaders.Authorization && { headers: authHeaders })
      });
      
      console.log('🧹 CLEAR ALL: Response status:', response.status);
      const result = await response.json();
      console.log('🧹 CLEAR ALL: Response data:', result);
      
      if (result.success) {
        console.log('✅ CLEAR ALL: Successfully cleared all fixed accounts');
        setImportResults({
          success: true,
          message: result.message,
          imported: 0,
          errors: []
        });
        fetchData(); // Refresh the data
      } else {
        console.error('❌ CLEAR ALL: Failed to clear fixed accounts:', result);
        setImportResults({
          success: false,
          message: 'Erro ao limpar contas fixas',
          imported: 0,
          errors: [result.error || 'Erro desconhecido']
        });
      }
    } catch (error) {
      console.error('❌ CLEAR ALL: Network error:', error);
      setImportResults({
        success: false,
        message: 'Erro ao conectar com o servidor',
        imported: 0,
        errors: ['Erro de conexão']
      });
    } finally {
      setClearing(false);
      setShowClearModal(false);
    }
  };

  // Reset all payments from PAGO to NÃO PAGO
  const handleResetAllPayments = async () => {
    setResettingPayments(true);
    
    try {
      const response = await fetch('/api/fixed-accounts/reset-payments', {
        method: 'POST',
        credentials: 'include'
      });
      
      const result = await response.json();
      
      if (result.success) {
        setImportResults({
          success: true,
          message: `${result.updated} conta(s) fixa(s) alterada(s) de PAGO para NÃO PAGO`,
          imported: 0,
          errors: []
        });
        fetchData(); // Refresh the data
      } else {
        setImportResults({
          success: false,
          message: 'Erro ao zerar pagamentos',
          imported: 0,
          errors: [result.error || 'Erro desconhecido']
        });
      }
    } catch (error) {
      setImportResults({
        success: false,
        message: 'Erro ao conectar com o servidor',
        imported: 0,
        errors: ['Erro de conexão']
      });
    } finally {
      setResettingPayments(false);
      setShowResetPaymentsModal(false);
    }
  };

  const downloadFixedAccountSample = () => {
    // Create comprehensive sample data for fixed accounts (sem coluna ID)
    const sampleData = [
      // Exemplos de despesas fixas mensais
      { vencimento_dia: 5, descricao: 'Conta de Luz', categoria: 'Moradia', centro_custo: 'Casa', a_quem_pagar: 'Companhia Elétrica', valor: -180.50, status: 'PAGO', ativacao: 'Ativa' },
      { vencimento_dia: 7, descricao: 'Conta de Água', categoria: 'Moradia', centro_custo: 'Casa', a_quem_pagar: 'SABESP', valor: -95.30, status: 'PAGO', ativacao: 'Ativa' },
      { vencimento_dia: 10, descricao: 'Internet Fibra', categoria: 'Moradia', centro_custo: 'Casa', a_quem_pagar: 'Vivo Fibra', valor: -120.00, status: 'NÃO PAGO', ativacao: 'Ativa' },
      { vencimento_dia: 12, descricao: 'Plano de Saúde', categoria: 'Saude', centro_custo: 'Pessoal', a_quem_pagar: 'Unimed', valor: -350.00, status: 'PAGO', ativacao: 'Inativa' },
      { vencimento_dia: 15, descricao: 'Financiamento Carro', categoria: 'Transporte', centro_custo: 'Carro', a_quem_pagar: 'Banco do Brasil', valor: -580.00, status: 'NÃO PAGO', ativacao: 'Ativa' },
      { vencimento_dia: 20, descricao: 'Academia', categoria: 'Lazer', centro_custo: 'Pessoal', a_quem_pagar: 'Smart Fit', valor: -89.90, status: 'PAGO', ativacao: 'Ativa' },
      { vencimento_dia: 25, descricao: 'Seguro Residencial', categoria: 'Moradia', centro_custo: 'Casa', a_quem_pagar: 'Porto Seguro', valor: -65.00, status: 'NÃO PAGO', ativacao: 'Inativa' },
      { vencimento_dia: 28, descricao: 'Streaming Netflix', categoria: 'Lazer', centro_custo: 'Pessoal', a_quem_pagar: 'Netflix', valor: -29.90, status: 'PAGO', ativacao: 'Ativa' },
      { vencimento_dia: 30, descricao: 'Condomínio', categoria: 'Moradia', centro_custo: 'Casa', a_quem_pagar: 'Administradora Predial', valor: -450.00, status: 'NÃO PAGO', ativacao: 'Ativa' },
      
      // Receitas mensais fixas
      { vencimento_dia: 1, descricao: 'Aluguel Recebido', categoria: 'Renda', centro_custo: 'Investimento', a_quem_pagar: 'Inquilino Apartamento', valor: 1200.00, status: 'PAGO', ativacao: 'Ativa' },
      { vencimento_dia: 5, descricao: 'Salário', categoria: 'Renda', centro_custo: 'Trabalho', a_quem_pagar: 'Empresa ABC Ltda', valor: 5000.00, status: 'PAGO', ativacao: 'Ativa' },
      
      // Outras despesas mensais
      { vencimento_dia: 8, descricao: 'Seguro Carro', categoria: 'Transporte', centro_custo: 'Carro', a_quem_pagar: 'Bradesco Seguros', valor: -120.00, status: 'NÃO PAGO', ativacao: 'Inativa' },
      { vencimento_dia: 18, descricao: 'Mensalidade Escola', categoria: 'Educacao', centro_custo: 'Familia', a_quem_pagar: 'Colégio São José', valor: -800.00, status: 'PAGO', ativacao: 'Ativa' },
      { vencimento_dia: 22, descricao: 'Cartão de Crédito', categoria: 'Financeiro', centro_custo: 'Pessoal', a_quem_pagar: 'Banco Itaú', valor: -650.00, status: 'NÃO PAGO', ativacao: 'Ativa' }
    ];

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(sampleData);

    // Auto-size columns (sem a coluna ID)
    const colWidths = [
      { wch: 15 }, // vencimento_dia
      { wch: 25 }, // descricao  
      { wch: 15 }, // categoria
      { wch: 15 }, // centro_custo
      { wch: 20 }, // a_quem_pagar
      { wch: 12 }, // valor
      { wch: 10 }, // status
      { wch: 10 }  // ativacao
    ];
    ws['!cols'] = colWidths;

    // Add the worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Exemplo_Contas_Fixas');

    // Generate Excel file and download
    XLSX.writeFile(wb, 'exemplo_importacao_contas_fixas.xlsx');
  };

  const handleExportFixedAccounts = () => {
    // Export current filtered data
    const exportData = filteredAccounts.map(account => {
      const category = getCategoryById(account.category_id || 0);
      const costCenter = getCostCenterById(account.cost_center_id || 0);
      
      return {
        id: account.id,
        vencimento_dia: account.due_day,
        descricao: account.description,
        categoria: category?.name || '',
        centro_custo: costCenter?.name || '',
        a_quem_pagar: account.payee,
        valor: account.amount,
        status: account.status || 'NÃO PAGO',
        ativacao: account.is_active ? 'Ativa' : 'Inativa'
      };
    });

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(exportData);

    // Auto-size columns
    const colWidths = [
      { wch: 8 },  // id
      { wch: 15 }, // vencimento_dia
      { wch: 25 }, // descricao  
      { wch: 15 }, // categoria
      { wch: 15 }, // centro_custo
      { wch: 20 }, // a_quem_pagar
      { wch: 12 }, // valor
      { wch: 10 }, // status
      { wch: 10 }  // ativacao
    ];
    ws['!cols'] = colWidths;

    // Add the worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Contas_Fixas');

    // Generate Excel file and download
    const today = new Date().toISOString().split('T')[0].replace(/-/g, '');
    XLSX.writeFile(wb, `contas_fixas_export_${today}.xlsx`);
  };

  // Show error state
  if (error) {
    return (
      <div className="p-8">
        <div className="flex flex-col items-center justify-center min-h-[400px] bg-red-50 rounded-2xl border border-red-200">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
            <AlertTriangle className="w-8 h-8 text-red-600" />
          </div>
          <h3 className="text-xl font-semibold text-red-800 mb-2">Erro ao Carregar Dados</h3>
          <p className="text-red-600 text-center mb-6 max-w-md">{error}</p>
          <button
            onClick={fetchData}
            className="px-6 py-3 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors font-medium"
          >
            Tentar Novamente
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-slate-600">Carregando contas fixas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      {/* Import Results */}
      {importResults && (
        <div className={`mb-6 p-4 rounded-xl border ${
          importResults.success 
            ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
            : 'bg-red-50 border-red-200 text-red-800'
        }`}>
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">{importResults.message}</h3>
              {importResults.success && (
                <p className="text-sm mt-1">
                  {importResults.imported} conta(s) fixa(s) importada(s) com sucesso
                </p>
              )}
            </div>
            <button
              onClick={() => setImportResults(null)}
              className="text-current hover:opacity-70"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          {importResults.errors && importResults.errors.length > 0 && (
            <div className="mt-3">
              <p className="text-sm font-medium">Erros encontrados:</p>
              <ul className="text-sm mt-1 list-disc list-inside">
                {importResults.errors.map((error, index) => (
                  <li key={index}>{error}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Contas Fixas</h1>
          <p className="text-slate-600">Gerencie suas contas mensais recorrentes</p>
        </div>
        
        <div className="flex gap-3">
          {/* Reset Payments Button */}
          <button
            onClick={() => setShowResetPaymentsModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-xl hover:bg-orange-700 hover:shadow-lg transition-all duration-200 font-medium"
            title="Alterar todos os lançamentos de PAGO para NÃO PAGO"
          >
            <RotateCcw className="w-4 h-4" />
            Zerar Pagamentos
          </button>
          
          {/* Clear All Fixed Accounts Button */}
          <button
            onClick={() => setShowClearModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 hover:shadow-lg transition-all duration-200 font-medium"
            title="Limpar todas as contas fixas"
          >
            <AlertTriangle className="w-4 h-4" />
            Limpar Tudo
          </button>
        </div>
      </div>

      <div className="flex items-center justify-between mb-8">
        <div className="invisible">
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Contas Fixas</h1>
          <p className="text-slate-600">Gerencie suas contas mensais recorrentes</p>
        </div>
        <div className="flex gap-3">
          {selectedAccounts.size > 0 && (
            <>
              <button
                onClick={handleBulkPay}
                className="flex items-center justify-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-colors font-medium min-w-[140px]"
              >
                <DollarSign className="w-4 h-4" />
                Pagar ({selectedAccounts.size})
              </button>
              <button
                onClick={handleBulkDelete}
                className="flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors font-medium min-w-[140px]"
              >
                <Trash2 className="w-4 h-4" />
                Excluir ({selectedAccounts.size})
              </button>
            </>
          )}
          <button 
            onClick={handleOpenFilterModal}
            className={`flex items-center justify-center gap-2 px-4 py-2 rounded-xl transition-colors font-medium relative ${
              activeFilterCount > 0 
                ? 'bg-blue-600 text-white hover:bg-blue-700' 
                : 'bg-indigo-600 text-white hover:bg-indigo-700'
            }`}
          >
            <Filter className="w-4 h-4" />
            Filtros
            {activeFilterCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
          </button>
          <button 
            onClick={handleExportFixedAccounts}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-teal-600 text-white rounded-xl hover:bg-teal-700 transition-colors font-medium min-w-[100px]"
          >
            <Download className="w-4 h-4" />
            Exportar
          </button>
          <input
            type="file"
            accept=".csv,.xlsx,.xls"
            onChange={handleImportFixedAccounts}
            className="hidden"
            id="import-fixed-accounts"
            disabled={importing}
          />
          <button
            onClick={downloadFixedAccountSample}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-amber-600 text-white rounded-xl hover:bg-amber-700 transition-colors font-medium min-w-[120px]"
            title="Baixar planilha de exemplo com dados de teste"
          >
            <Download className="w-4 h-4" />
            Baixar Modelo
          </button>
          <label
            htmlFor="import-fixed-accounts"
            className={`flex items-center justify-center gap-2 px-4 py-2 bg-violet-600 text-white rounded-xl hover:bg-violet-700 transition-colors cursor-pointer font-medium min-w-[100px] ${importing ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            <Upload className="w-4 h-4" />
            {importing ? 'Importando...' : 'Importar'}
          </label>
          <button 
            onClick={() => setShowModal(true)}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-600 to-cyan-600 text-white rounded-xl hover:shadow-lg transition-all font-medium"
          >
            <Plus className="w-4 h-4" />
            Nova Conta Fixa
          </button>
        </div>
      </div>

      {/* Cards Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Selection Summary Card */}
        {selectedAccounts.size > 0 && (
          <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-6 text-white shadow-xl border-2 border-blue-400/30">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-blue-200 mb-2">Contas Selecionadas</p>
                <p className="text-2xl font-bold text-white mb-1">
                  {selectedAccounts.size} {selectedAccounts.size === 1 ? 'conta' : 'contas'}
                </p>
                <p className={`text-xl font-semibold ${
                  fixedAccounts
                    .filter(a => selectedAccounts.has(a.id))
                    .reduce((sum, a) => sum + a.amount, 0) < 0 
                    ? 'text-red-300' 
                    : 'text-emerald-300'
                }`}>
                  Valor Total: {formatCurrency(
                    fixedAccounts
                      .filter(a => selectedAccounts.has(a.id))
                      .reduce((sum, a) => sum + a.amount, 0)
                  )}
                </p>
              </div>
              <div className="p-4 bg-white/15 rounded-xl backdrop-blur-sm">
                <DollarSign className="w-8 h-8 text-blue-200" />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="text-sm text-blue-200">
                Ativas: {fixedAccounts.filter(a => selectedAccounts.has(a.id) && a.is_active).length} | 
                Inativas: {fixedAccounts.filter(a => selectedAccounts.has(a.id) && !a.is_active).length}
              </div>
              <button
                onClick={() => {
                  setSelectedAccounts(new Set());
                  setSelectAll(false);
                }}
                className="text-xs bg-white/20 hover:bg-white/30 px-3 py-1 rounded-lg transition-colors"
              >
                Limpar Seleção
              </button>
            </div>
          </div>
        )}

        {/* Summary Cards */}
        <div className={`grid grid-cols-2 gap-4 ${selectedAccounts.size === 0 ? 'lg:col-span-2' : ''}`}>
          {/* Total Monthly Amount */}
          <div className="bg-gradient-to-r from-emerald-600 to-teal-700 rounded-2xl p-6 text-white shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-emerald-200 mb-2">Valor Total em Aberto</p>
                <p className="text-2xl font-bold text-white">
                  {formatCurrency(totalAmount)}
                </p>
              </div>
              <div className="p-3 bg-white/15 rounded-xl backdrop-blur-sm">
                <DollarSign className="w-6 h-6 text-emerald-200" />
              </div>
            </div>
          </div>

          {/* Total Accounts */}
          <div className="bg-gradient-to-r from-purple-600 to-pink-700 rounded-2xl p-6 text-white shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-200 mb-2">Quantidade Total em Aberto</p>
                <p className="text-2xl font-bold text-white">
                  {filteredAccounts.filter(account => (account.status || 'NÃO PAGO') === 'NÃO PAGO').length}
                </p>
              </div>
              <div className="p-3 bg-white/15 rounded-xl backdrop-blur-sm">
                <User className="w-6 h-6 text-purple-200" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Fixed Accounts Table */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-200/50 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200/50">
          <h2 className="text-xl font-semibold text-slate-800">Lista de Contas Fixas</h2>
        </div>
        
        {filteredAccounts.length === 0 ? (
          /* Empty State */
          <div className="flex flex-col items-center justify-center py-16 px-6">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mb-4">
              <CreditCard className="w-10 h-10 text-slate-400" />
            </div>
            <h3 className="text-lg font-semibold text-slate-800 mb-2">Nenhuma conta fixa</h3>
            <p className="text-slate-500 text-center mb-6 max-w-md">
              Comece adicionando sua primeira conta fixa mensal.
            </p>
            <button
              onClick={() => setShowModal(true)}
              className="flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 hover:shadow-lg transition-all font-medium"
            >
              <Plus className="w-4 h-4" />
              Criar Conta Fixa
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full" onContextMenu={handleRightClick}>
              <thead className="bg-slate-50 border-b border-slate-200/50">
                <tr>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">
                    <input
                      type="checkbox"
                      checked={selectAll}
                      onChange={(e) => handleSelectAll(e.target.checked)}
                      className="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500"
                    />
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Vencimento</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Descrição</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Categoria</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Centro de Custo</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">A Quem Pagar</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-slate-700">Valor</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">Status</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">Ativação</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/50">
                {paginatedAccounts.map((account) => {
                  const category = getCategoryById(account.category_id || 0);
                  const costCenter = getCostCenterById(account.cost_center_id || 0);
                  
                  return (
                    <tr key={account.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4 text-center">
                        <input
                          type="checkbox"
                          checked={selectedAccounts.has(account.id)}
                          onChange={(e) => handleSelectAccount(account.id, e.target.checked)}
                          className="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-slate-400" />
                          <span className="text-sm font-medium text-slate-800">
                            Dia {account.due_day}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-slate-800">
                          {account.description}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {category?.name || "-"}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {costCenter?.name || "-"}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-slate-400" />
                          <span className="text-sm text-slate-600">{account.payee}</span>
                        </div>
                      </td>
                      <td className={`px-6 py-4 text-right font-semibold whitespace-nowrap ${
                        account.amount < 0 ? 'text-red-600' : 'text-emerald-600'
                      }`}>
                        {editingAmountId === account.id ? (
                          <div className="flex items-center justify-end gap-2">
                            <input
                              type="number"
                              step="0.01"
                              value={editingAmountValue}
                              onChange={(e) => setEditingAmountValue(e.target.value)}
                              className="w-32 px-3 py-2 text-sm border border-slate-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right"
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  handleSaveAmount(account.id);
                                } else if (e.key === 'Escape') {
                                  handleCancelEditAmount();
                                }
                              }}
                              autoFocus
                            />
                            <button
                              onClick={() => handleSaveAmount(account.id)}
                              className="text-emerald-600 hover:bg-emerald-50 p-1 rounded text-xs"
                              title="Salvar"
                            >
                              ✓
                            </button>
                            <button
                              onClick={handleCancelEditAmount}
                              className="text-red-600 hover:bg-red-50 p-1 rounded text-xs"
                              title="Cancelar"
                            >
                              ✕
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => handleStartEditAmount(account.id, account.amount)}
                            className="hover:bg-slate-100 px-2 py-1 rounded transition-colors cursor-pointer w-full text-right"
                            title="Clique para editar o valor"
                          >
                            {formatCurrency(account.amount)}
                          </button>
                        )}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <button
                          onClick={() => handleToggleStatus(account.id)}
                          className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium transition-all hover:scale-105 hover:shadow-md cursor-pointer ${
                            (account.status || 'NÃO PAGO') === 'PAGO' 
                              ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200' 
                              : 'bg-red-100 text-red-800 hover:bg-red-200'
                          }`}
                          title="Clique para alterar o status"
                        >
                          {account.status || 'NÃO PAGO'}
                        </button>
                      </td>
                      <td className="px-6 py-4 text-center">
                        {account.is_active ? (
                          <span className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-medium rounded-full">
                            <ToggleRight className="w-3 h-3" />
                            Ativa
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-3 py-1 bg-slate-100 text-slate-600 text-xs font-medium rounded-full">
                            <ToggleLeft className="w-3 h-3" />
                            Inativa
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleEditAccount(account)}
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="Editar conta fixa"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteAccount(account.id)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Excluir conta fixa"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {filteredAccounts.length > 0 && (
          <div className="px-6 py-4 border-t border-slate-200/50 bg-slate-50/50">
            <div className="flex items-center justify-between">
              {/* Items per page selector */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-slate-600">Itens por página:</span>
                <select
                  value={itemsPerPage}
                  onChange={(e) => handleItemsPerPageChange(Number(e.target.value))}
                  className="px-3 py-1 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                >
                  <option value={5}>5</option>
                  <option value={10}>10</option>
                  <option value={20}>20</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>

              {/* Page info and navigation */}
              <div className="flex items-center gap-4">
                <span className="text-sm text-slate-600">
                  Mostrando {startIndex + 1} a {Math.min(endIndex, filteredAccounts.length)} de {filteredAccounts.length} registros
                </span>
                
                <div className="flex items-center gap-2">
                  {/* Previous button */}
                  <button
                    onClick={() => goToPage(currentPage - 1)}
                    disabled={currentPage === 1}
                    className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    title="Página anterior"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>

                  {/* Page number selector */}
                  <div className="flex items-center gap-1">
                    {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                      let pageNumber;
                      if (totalPages <= 5) {
                        pageNumber = i + 1;
                      } else if (currentPage <= 3) {
                        pageNumber = i + 1;
                      } else if (currentPage >= totalPages - 2) {
                        pageNumber = totalPages - 4 + i;
                      } else {
                        pageNumber = currentPage - 2 + i;
                      }

                      return (
                        <button
                          key={pageNumber}
                          onClick={() => goToPage(pageNumber)}
                          className={`px-3 py-1 text-sm rounded-lg transition-colors ${
                            currentPage === pageNumber
                              ? 'bg-emerald-600 text-white'
                              : 'text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          {pageNumber}
                        </button>
                      );
                    })}
                  </div>

                  {/* Next button */}
                  <button
                    onClick={() => goToPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                    className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    title="Próxima página"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Direct page input */}
                {totalPages > 5 && (
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-600">Ir para:</span>
                    <input
                      type="number"
                      min={1}
                      max={totalPages}
                      value={currentPage}
                      onChange={(e) => {
                        const page = Number(e.target.value);
                        if (page >= 1 && page <= totalPages) {
                          goToPage(page);
                        }
                      }}
                      className="w-16 px-2 py-1 border border-slate-300 rounded-lg text-sm text-center focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer Information */}
      <div className="mt-8 py-4 border-t border-slate-200/50">
        <div className="text-center text-sm text-slate-600">
          {activeFilterCount > 0 ? (
            <>
              Registros filtrados: <span className="font-semibold">{filteredAccounts.length}</span> de {fixedAccounts.length}
              {filteredAccounts.length > 0 && (
                <span className="ml-4">
                  Mostrando {Math.min(startIndex + 1, filteredAccounts.length)} a {Math.min(endIndex, filteredAccounts.length)} de {filteredAccounts.length} registros filtrados
                </span>
              )}
            </>
          ) : (
            <>
              Total de registros: <span className="font-semibold">{fixedAccounts.length}</span>
              {fixedAccounts.length > 0 && (
                <span className="ml-4">
                  Mostrando {Math.min(startIndex + 1, filteredAccounts.length)} a {Math.min(endIndex, filteredAccounts.length)} de {filteredAccounts.length} registros
                </span>
              )}
            </>
          )}
        </div>
      </div>

      {/* Create Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-slate-200/50">
              <h3 className="text-xl font-semibold text-slate-800">Nova Conta Fixa</h3>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Dia do Vencimento</label>
                <input
                  type="number"
                  min="1"
                  max="31"
                  value={newAccount.due_day}
                  onChange={(e) => setNewAccount({...newAccount, due_day: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="1-31"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Descrição</label>
                <input
                  type="text"
                  value={newAccount.description}
                  onChange={(e) => setNewAccount({...newAccount, description: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="Descrição da conta"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Valor (Despesa)</label>
                <input
                  type="number"
                  step="0.01"
                  value={newAccount.amount}
                  onChange={(e) => {
                    let value = e.target.value;
                    // Ensure value is negative for expenses
                    if (value && parseFloat(value) > 0) {
                      value = `-${value}`;
                    }
                    setNewAccount({...newAccount, amount: value});
                  }}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="-0.00"
                />
                <p className="text-xs text-slate-500 mt-1">Valor será automaticamente convertido para negativo (despesa)</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Categoria</label>
                <select
                  value={newAccount.category_id}
                  onChange={(e) => setNewAccount({...newAccount, category_id: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                >
                  <option value="">Selecione uma categoria</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Centro de Custo</label>
                <select
                  value={newAccount.cost_center_id}
                  onChange={(e) => setNewAccount({...newAccount, cost_center_id: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                >
                  <option value="">Selecione um centro de custo</option>
                  {costCenters.map((costCenter) => (
                    <option key={costCenter.id} value={costCenter.id}>
                      {costCenter.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">A Quem Pagar</label>
                <input
                  type="text"
                  value={newAccount.payee}
                  onChange={(e) => setNewAccount({...newAccount, payee: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="Nome da empresa ou pessoa"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Status</label>
                <select
                  value={newAccount.status}
                  onChange={(e) => setNewAccount({...newAccount, status: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                >
                  <option value="NÃO PAGO">NÃO PAGO</option>
                  <option value="PAGO">PAGO</option>
                </select>
              </div>
              
              <div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={newAccount.is_active}
                    onChange={(e) => setNewAccount({...newAccount, is_active: e.target.checked})}
                    className="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500"
                  />
                  <span className="text-sm font-medium text-slate-700">Conta ativa</span>
                </label>
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleCreateAccount}
                className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-lg hover:shadow-lg transition-all"
              >
                Criar Conta Fixa
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {showEditModal && editingAccount && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-slate-200/50">
              <h3 className="text-xl font-semibold text-slate-800">Editar Conta Fixa</h3>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Dia do Vencimento</label>
                <input
                  type="number"
                  min="1"
                  max="31"
                  value={editAccount.due_day}
                  onChange={(e) => setEditAccount({...editAccount, due_day: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="1-31"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Descrição</label>
                <input
                  type="text"
                  value={editAccount.description}
                  onChange={(e) => setEditAccount({...editAccount, description: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Descrição da conta"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Valor (Despesa)</label>
                <input
                  type="number"
                  step="0.01"
                  value={editAccount.amount}
                  onChange={(e) => {
                    let value = e.target.value;
                    // Ensure value is negative for expenses
                    if (value && parseFloat(value) > 0) {
                      value = `-${value}`;
                    }
                    setEditAccount({...editAccount, amount: value});
                  }}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="-0.00"
                />
                <p className="text-xs text-slate-500 mt-1">Valor será automaticamente convertido para negativo (despesa)</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Categoria</label>
                <select
                  value={editAccount.category_id}
                  onChange={(e) => setEditAccount({...editAccount, category_id: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Selecione uma categoria</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Centro de Custo</label>
                <select
                  value={editAccount.cost_center_id}
                  onChange={(e) => setEditAccount({...editAccount, cost_center_id: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Selecione um centro de custo</option>
                  {costCenters.map((costCenter) => (
                    <option key={costCenter.id} value={costCenter.id}>
                      {costCenter.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">A Quem Pagar</label>
                <input
                  type="text"
                  value={editAccount.payee}
                  onChange={(e) => setEditAccount({...editAccount, payee: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Nome da empresa ou pessoa"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Status</label>
                <select
                  value={editAccount.status}
                  onChange={(e) => setEditAccount({...editAccount, status: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="NÃO PAGO">NÃO PAGO</option>
                  <option value="PAGO">PAGO</option>
                </select>
              </div>
              
              <div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editAccount.is_active}
                    onChange={(e) => setEditAccount({...editAccount, is_active: e.target.checked})}
                    className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                  />
                  <span className="text-sm font-medium text-slate-700">Conta ativa</span>
                </label>
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => {
                  setShowEditModal(false);
                  setEditingAccount(null);
                }}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleUpdateAccount}
                className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:shadow-lg transition-all"
              >
                Salvar Alterações
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Filter Modal */}
      {showFilterModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-slate-200/50">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold text-slate-800">Filtrar Contas Fixas</h3>
                {activeFilterCount > 0 && (
                  <span className="bg-blue-100 text-blue-800 text-sm px-3 py-1 rounded-full">
                    {activeFilterCount} filtro{activeFilterCount > 1 ? 's' : ''} ativo{activeFilterCount > 1 ? 's' : ''}
                  </span>
                )}
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Due Day Range */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Vencimento (Dia Inicial)</label>
                  <input
                    type="number"
                    min="1"
                    max="31"
                    value={filters.dueDayFrom}
                    onChange={(e) => setFilters({...filters, dueDayFrom: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="1"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Vencimento (Dia Final)</label>
                  <input
                    type="number"
                    min="1"
                    max="31"
                    value={filters.dueDayTo}
                    onChange={(e) => setFilters({...filters, dueDayTo: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="31"
                  />
                </div>
              </div>

              {/* Category and Cost Center */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Categorias ({filters.categoryIds.length} selecionada{filters.categoryIds.length !== 1 ? 's' : ''})
                  </label>
                  <div className="relative">
                    <div className="border border-slate-300 rounded-lg p-3 max-h-40 overflow-y-auto bg-white">
                      <div className="space-y-2">
                        <label className="flex items-center gap-2 cursor-pointer hover:bg-slate-50 p-1 rounded">
                          <input
                            type="checkbox"
                            checked={filters.categoryIds.length === categories.length}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFilters({...filters, categoryIds: categories.map(c => c.id.toString())});
                              } else {
                                setFilters({...filters, categoryIds: []});
                              }
                            }}
                            className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                          />
                          <span className="text-sm font-medium text-slate-700">Todas as categorias</span>
                        </label>
                        <hr className="border-slate-200" />
                        {categories.map((category) => (
                          <label key={category.id} className="flex items-center gap-2 cursor-pointer hover:bg-slate-50 p-1 rounded">
                            <input
                              type="checkbox"
                              checked={filters.categoryIds.includes(category.id.toString())}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setFilters({
                                    ...filters, 
                                    categoryIds: [...filters.categoryIds, category.id.toString()]
                                  });
                                } else {
                                  setFilters({
                                    ...filters, 
                                    categoryIds: filters.categoryIds.filter(id => id !== category.id.toString())
                                  });
                                }
                              }}
                              className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm text-slate-700">{category.name}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Centros de Custo ({filters.costCenterIds.length} selecionado{filters.costCenterIds.length !== 1 ? 's' : ''})
                  </label>
                  <div className="relative">
                    <div className="border border-slate-300 rounded-lg p-3 max-h-40 overflow-y-auto bg-white">
                      <div className="space-y-2">
                        <label className="flex items-center gap-2 cursor-pointer hover:bg-slate-50 p-1 rounded">
                          <input
                            type="checkbox"
                            checked={filters.costCenterIds.length === costCenters.length}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFilters({...filters, costCenterIds: costCenters.map(cc => cc.id.toString())});
                              } else {
                                setFilters({...filters, costCenterIds: []});
                              }
                            }}
                            className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                          />
                          <span className="text-sm font-medium text-slate-700">Todos os centros de custo</span>
                        </label>
                        <hr className="border-slate-200" />
                        {costCenters.map((costCenter) => (
                          <label key={costCenter.id} className="flex items-center gap-2 cursor-pointer hover:bg-slate-50 p-1 rounded">
                            <input
                              type="checkbox"
                              checked={filters.costCenterIds.includes(costCenter.id.toString())}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setFilters({
                                    ...filters, 
                                    costCenterIds: [...filters.costCenterIds, costCenter.id.toString()]
                                  });
                                } else {
                                  setFilters({
                                    ...filters, 
                                    costCenterIds: filters.costCenterIds.filter(id => id !== costCenter.id.toString())
                                  });
                                }
                              }}
                              className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm text-slate-700">{costCenter.name}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Status and Active Status */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Status</label>
                  <select
                    value={filters.status}
                    onChange={(e) => setFilters({...filters, status: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Todos os status</option>
                    <option value="PAGO">PAGO</option>
                    <option value="NÃO PAGO">NÃO PAGO</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Ativação da Conta</label>
                  <select
                    value={filters.isActive}
                    onChange={(e) => setFilters({...filters, isActive: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Todas as ativações</option>
                    <option value="active">Apenas Ativas</option>
                    <option value="inactive">Apenas Inativas</option>
                  </select>
                </div>
              </div>

              {/* Payee */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">A Quem Pagar</label>
                <input
                  type="text"
                  value={filters.payee}
                  onChange={(e) => setFilters({...filters, payee: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Buscar por nome..."
                />
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-between">
              <div className="flex gap-3">
                <button
                  onClick={() => setShowFilterModal(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleClearFilters}
                  className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  Limpar Filtros
                </button>
              </div>
              <button
                onClick={handleApplyFilters}
                className="px-6 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:shadow-lg transition-all font-medium"
              >
                Aplicar Filtros
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reset Payments Modal */}
      {showResetPaymentsModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-200/50 flex items-center gap-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <RotateCcw className="w-5 h-5 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold text-slate-800">Zerar Pagamentos</h3>
            </div>
            
            <div className="p-6">
              <div className="mb-4">
                <p className="text-slate-700 mb-2">
                  <strong>Confirmação:</strong> Esta ação irá alterar:
                </p>
                <ul className="list-disc list-inside text-sm text-slate-600 space-y-1 ml-4">
                  <li>Todas as contas fixas com status <strong>"PAGO"</strong></li>
                  <li>Status será alterado para <strong>"NÃO PAGO"</strong></li>
                  <li>Útil para reiniciar o ciclo mensal de pagamentos</li>
                </ul>
              </div>
              
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 mb-4">
                <p className="text-orange-800 text-sm font-medium">
                  📋 Operação Reversível
                </p>
                <p className="text-orange-700 text-sm">
                  Você pode marcar as contas como pagas novamente a qualquer momento.
                </p>
              </div>
              
              <p className="text-slate-600 text-sm">
                {fixedAccounts.filter(account => (account.status || 'NÃO PAGO') === 'PAGO').length} conta(s) fixa(s) com status "PAGO" serão alteradas.
              </p>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => setShowResetPaymentsModal(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                disabled={resettingPayments}
              >
                Cancelar
              </button>
              <button
                onClick={handleResetAllPayments}
                disabled={resettingPayments}
                className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {resettingPayments ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                    Zerando...
                  </>
                ) : (
                  <>
                    <RotateCcw className="w-4 h-4" />
                    Confirmar Operação
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clear All Fixed Accounts Modal */}
      {showClearModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-200/50 flex items-center gap-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold text-slate-800">Limpar Todas as Contas Fixas</h3>
            </div>
            
            <div className="p-6">
              <div className="mb-4">
                <p className="text-slate-700 mb-2">
                  <strong>Atenção:</strong> Esta ação irá remover permanentemente:
                </p>
                <ul className="list-disc list-inside text-sm text-slate-600 space-y-1 ml-4">
                  <li>Todas as contas fixas cadastradas</li>
                  <li>Histórico de contas mensais recorrentes</li>
                  <li>Configurações de vencimento e valores</li>
                </ul>
              </div>
              
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
                <p className="text-red-800 text-sm font-medium">
                  ⚠️ Esta ação não pode ser desfeita!
                </p>
                <p className="text-red-700 text-sm">
                  Certifique-se de ter um backup dos seus dados se necessário.
                </p>
              </div>
              
              <p className="text-slate-600 text-sm">
                As categorias e centros de custo permanecerão inalterados.
              </p>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => setShowClearModal(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                disabled={clearing}
              >
                Cancelar
              </button>
              <button
                onClick={handleClearAllFixedAccounts}
                disabled={clearing}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {clearing ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                    Limpando...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    Confirmar Limpeza
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
