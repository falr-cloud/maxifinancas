import { useEffect, useState } from "react";
import { Plus, Trash2, Edit3, Save, X, Tag, Building2, Upload, Download, AlertTriangle, User, ChevronLeft, ChevronRight, RotateCcw } from "lucide-react";
import { Category, CostCenter, CreateCategory, CreateCostCenter, PayrollDescription, CreatePayrollDescription } from "@/shared/types";
import PlanRestriction from "@/react-app/components/PlanRestriction";
import { useAuth } from "@/react-app/contexts/AuthContext";
import * as XLSX from 'xlsx';

interface EditingCategory extends CreateCategory {
  id?: number;
}

interface EditingCostCenter extends CreateCostCenter {
  id?: number;
}

interface EditingPayrollDescription extends CreatePayrollDescription {
  id?: number;
}

export default function Settings() {
  const { user, isPending } = useAuth();
  const [categories, setCategories] = useState<Category[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [payrollDescriptions, setPayrollDescriptions] = useState<PayrollDescription[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Category state
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState<EditingCategory | null>(null);
  const [newCategory, setNewCategory] = useState<CreateCategory>({
    name: '',
    description: ''
  });
  
  // Cost Center state
  const [showCostCenterModal, setShowCostCenterModal] = useState(false);
  const [editingCostCenter, setEditingCostCenter] = useState<EditingCostCenter | null>(null);
  const [newCostCenter, setNewCostCenter] = useState<CreateCostCenter>({
    name: '',
    description: ''
  });

  // Payroll Description state
  const [showPayrollDescModal, setShowPayrollDescModal] = useState(false);
  const [editingPayrollDesc, setEditingPayrollDesc] = useState<EditingPayrollDescription | null>(null);
  const [newPayrollDesc, setNewPayrollDesc] = useState<CreatePayrollDescription>({
    name: '',
    description: '',
    tipo: ''
  });

  // Import state
  const [importing, setImporting] = useState(false);
  const [importResults, setImportResults] = useState<{
    success: boolean;
    message: string;
    imported: number;
    errors: string[];
  } | null>(null);

  // Clear database state
  const [showClearModal, setShowClearModal] = useState(false);
  const [clearing, setClearing] = useState(false);
  const [repairing, setRepairing] = useState(false);

  // Pagination states
  const [categoriesPage, setCategoriesPage] = useState(1);
  const [categoriesPerPage, setCategoriesPerPage] = useState(5);
  const [costCentersPage, setCostCentersPage] = useState(1);
  const [costCentersPerPage, setCostCentersPerPage] = useState(5);
  const [payrollDescPage, setPayrollDescPage] = useState(1);
  const [payrollDescPerPage, setPayrollDescPerPage] = useState(5);

  useEffect(() => {
    if (!isPending && user) {
      fetchData();
    }
  }, [user, isPending]);

  const fetchData = async () => {
    try {
      setError(null);
      console.log("🔄 Settings: Fetching data...");
      
      // Check if user is authenticated
      if (!user) {
        console.log("⚠️ Settings: No user authenticated");
        setError("Usuário não autenticado. Faça login novamente.");
        setLoading(false);
        return;
      }
      
      console.log("👤 Settings: User authenticated:", user.id);

      // Add better error handling for each request individually
      const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${btoa(JSON.stringify(user))}`
      };

      console.log("📡 Settings: Making API requests...");
      
      let categoriesData = [];
      let costCentersData = [];
      let payrollDescData = [];

      // Fetch categories
      try {
        console.log("📡 Settings: Fetching categories for user:", user.id);
        const categoriesRes = await fetch("/api/categories", {
          method: "GET",
          credentials: 'include',
          headers
        });
        console.log("📡 Categories response status:", categoriesRes.status);
        console.log("📡 Categories response headers:", Object.fromEntries(categoriesRes.headers.entries()));
        
        if (categoriesRes.ok) {
          categoriesData = await categoriesRes.json();
          console.log("📊 Categories raw data received:", categoriesData);
        } else {
          const errorText = await categoriesRes.text();
          console.error("❌ Categories request failed:", categoriesRes.status, categoriesRes.statusText, errorText);
        }
      } catch (err) {
        console.error("❌ Categories fetch error:", err);
      }

      // Fetch cost centers
      try {
        const costCentersRes = await fetch("/api/cost-centers", {
          method: "GET",
          credentials: 'include',
          headers
        });
        console.log("📡 Cost Centers response:", costCentersRes.status);
        if (costCentersRes.ok) {
          costCentersData = await costCentersRes.json();
        } else {
          console.error("❌ Cost Centers request failed:", costCentersRes.status, costCentersRes.statusText);
        }
      } catch (err) {
        console.error("❌ Cost Centers fetch error:", err);
      }

      // Fetch payroll descriptions
      try {
        const payrollDescRes = await fetch("/api/payroll-descriptions", {
          method: "GET",
          credentials: 'include',
          headers
        });
        console.log("📡 Payroll Descriptions response:", payrollDescRes.status);
        if (payrollDescRes.ok) {
          payrollDescData = await payrollDescRes.json();
        } else {
          console.error("❌ Payroll Descriptions request failed:", payrollDescRes.status, payrollDescRes.statusText);
        }
      } catch (err) {
        console.error("❌ Payroll Descriptions fetch error:", err);
      }

      console.log("✅ Settings: Data fetched successfully");
      console.log("📊 Settings: Categories:", categoriesData?.length || 0);
      console.log("📊 Settings: Cost Centers:", costCentersData?.length || 0);
      console.log("📊 Settings: Payroll Descriptions:", payrollDescData?.length || 0);

      setCategories(Array.isArray(categoriesData) ? categoriesData : []);
      setCostCenters(Array.isArray(costCentersData) ? costCentersData : []);
      setPayrollDescriptions(Array.isArray(payrollDescData) ? payrollDescData : []);
      
    } catch (error) {
      console.error("❌ Settings: Error fetching data:", error);
      setError("Erro ao carregar dados. Tente recarregar a página.");
      // Set empty arrays to allow component to render
      setCategories([]);
      setCostCenters([]);
      setPayrollDescriptions([]);
    } finally {
      setLoading(false);
    }
  };

  // Pagination helper functions
  const paginateData = (data: any[], page: number, perPage: number) => {
    const startIndex = (page - 1) * perPage;
    const endIndex = startIndex + perPage;
    return data.slice(startIndex, endIndex);
  };

  const getTotalPages = (totalItems: number, perPage: number) => {
    return Math.ceil(totalItems / perPage);
  };

  const goToPage = (page: number, setPage: React.Dispatch<React.SetStateAction<number>>, totalPages: number) => {
    if (page >= 1 && page <= totalPages) {
      setPage(page);
    }
  };

  // Pagination calculations
  const paginatedCategories = paginateData(categories, categoriesPage, categoriesPerPage);
  const categoriesTotalPages = getTotalPages(categories.length, categoriesPerPage);
  const categoriesStartIndex = (categoriesPage - 1) * categoriesPerPage;

  const paginatedCostCenters = paginateData(costCenters, costCentersPage, costCentersPerPage);
  const costCentersTotalPages = getTotalPages(costCenters.length, costCentersPerPage);
  const costCentersStartIndex = (costCentersPage - 1) * costCentersPerPage;

  const paginatedPayrollDesc = paginateData(payrollDescriptions, payrollDescPage, payrollDescPerPage);
  const payrollDescTotalPages = getTotalPages(payrollDescriptions.length, payrollDescPerPage);
  const payrollDescStartIndex = (payrollDescPage - 1) * payrollDescPerPage;

  // Category functions
  const handleCreateCategory = async () => {
    try {
      // Validação do formulário
      if (!newCategory.name || newCategory.name.trim() === '') {
        setError('O nome da categoria é obrigatório');
        return;
      }

      console.log("🔄 Creating category:", newCategory);
      setError(null); // Limpar erros anteriores
      
      const categoryData = {
        name: newCategory.name.trim(),
        description: newCategory.description && newCategory.description.trim() !== '' ? newCategory.description.trim() : undefined
      };
      
      const response = await fetch("/api/categories", {
        method: "POST",
        credentials: 'include',
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        },
        body: JSON.stringify(categoryData)
      });

      console.log("📡 Category creation response:", response.status);

      if (response.ok) {
        const result = await response.json();
        console.log("✅ Category created successfully:", result);
        
        // Fechar modal e limpar formulário
        setShowCategoryModal(false);
        setNewCategory({ name: '', description: '' });
        
        // Forçar atualização dos dados
        console.log("🔄 Recarregando dados após criação da categoria...");
        await fetchData();
        
        // Verificar se os dados foram atualizados
        console.log("📊 Categories após atualização:", categories.length);
        
        // Mostrar mensagem de sucesso temporária
        setImportResults({
          success: true,
          message: `Categoria "${categoryData.name}" criada com sucesso!`,
          imported: 1,
          errors: []
        });
        
        // Limpar a mensagem após 3 segundos
        setTimeout(() => setImportResults(null), 3000);
      } else {
        const errorData = await response.json();
        console.error("❌ Error creating category:", response.status, errorData);
        setError(`Erro ao criar categoria: ${errorData.error || 'Erro desconhecido'}`);
      }
    } catch (error) {
      console.error("❌ Error creating category:", error);
      setError(`Erro ao criar categoria: ${error instanceof Error ? error.message : 'Erro de conexão'}`);
    }
  };

  const handleUpdateCategory = async (id: number) => {
    if (!editingCategory) return;

    try {
      const categoryData = {
        name: editingCategory.name,
        description: editingCategory.description && editingCategory.description.trim() === '' ? undefined : editingCategory.description
      };
      
      const response = await fetch(`/api/categories/${id}`, {
        method: "PUT",
        credentials: 'include',
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        },
        body: JSON.stringify(categoryData)
      });

      if (response.ok) {
        setEditingCategory(null);
        fetchData();
      } else {
        console.error("Error updating category:", response.status);
      }
    } catch (error) {
      console.error("Error updating category:", error);
    }
  };

  const handleDeleteCategory = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir esta categoria?")) return;

    try {
      const response = await fetch(`/api/categories/${id}`, {
        method: "DELETE",
        credentials: 'include',
        headers: {
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        }
      });

      if (response.ok) {
        fetchData();
      } else {
        console.error("Error deleting category:", response.status);
      }
    } catch (error) {
      console.error("Error deleting category:", error);
    }
  };

  // Cost Center functions
  const handleCreateCostCenter = async () => {
    try {
      // Validação do formulário
      if (!newCostCenter.name || newCostCenter.name.trim() === '') {
        setError('O nome do centro de custo é obrigatório');
        return;
      }

      console.log("🔄 Creating cost center:", newCostCenter);
      setError(null); // Limpar erros anteriores
      
      const costCenterData = {
        name: newCostCenter.name.trim(),
        description: newCostCenter.description && newCostCenter.description.trim() !== '' ? newCostCenter.description.trim() : undefined
      };
      
      const response = await fetch("/api/cost-centers", {
        method: "POST",
        credentials: 'include',
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        },
        body: JSON.stringify(costCenterData)
      });

      console.log("📡 Cost center creation response:", response.status);

      if (response.ok) {
        const result = await response.json();
        console.log("✅ Cost center created successfully:", result);
        setShowCostCenterModal(false);
        setNewCostCenter({ name: '', description: '' });
        await fetchData(); // Usar await para garantir que os dados sejam atualizados
        
        // Mostrar mensagem de sucesso temporária
        setImportResults({
          success: true,
          message: `Centro de custo "${costCenterData.name}" criado com sucesso!`,
          imported: 1,
          errors: []
        });
        
        // Limpar a mensagem após 3 segundos
        setTimeout(() => setImportResults(null), 3000);
      } else {
        const errorData = await response.json();
        console.error("❌ Error creating cost center:", response.status, errorData);
        setError(`Erro ao criar centro de custo: ${errorData.error || 'Erro desconhecido'}`);
      }
    } catch (error) {
      console.error("❌ Error creating cost center:", error);
      setError(`Erro ao criar centro de custo: ${error instanceof Error ? error.message : 'Erro de conexão'}`);
    }
  };

  const handleUpdateCostCenter = async (id: number) => {
    if (!editingCostCenter) return;

    try {
      const costCenterData = {
        name: editingCostCenter.name,
        description: editingCostCenter.description && editingCostCenter.description.trim() === '' ? undefined : editingCostCenter.description
      };
      
      const response = await fetch(`/api/cost-centers/${id}`, {
        method: "PUT",
        credentials: 'include',
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        },
        body: JSON.stringify(costCenterData)
      });

      if (response.ok) {
        setEditingCostCenter(null);
        fetchData();
      } else {
        console.error("Error updating cost center:", response.status);
      }
    } catch (error) {
      console.error("Error updating cost center:", error);
    }
  };

  const handleDeleteCostCenter = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir este centro de custo?")) return;

    try {
      const response = await fetch(`/api/cost-centers/${id}`, {
        method: "DELETE",
        credentials: 'include',
        headers: {
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        }
      });

      if (response.ok) {
        fetchData();
      } else {
        console.error("Error deleting cost center:", response.status);
      }
    } catch (error) {
      console.error("Error deleting cost center:", error);
    }
  };

  // Import functions
  const handleImportCategories = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImporting(true);
    setImportResults(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('/api/categories/import', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Authorization': `Bearer ${btoa(JSON.stringify(user))}`
        },
        body: formData
      });

      const result = await response.json();
      setImportResults(result);
      
      if (result.success) {
        fetchData();
      }
    } catch (error) {
      setImportResults({
        success: false,
        message: 'Erro ao importar categorias',
        imported: 0,
        errors: ['Erro de conexão com o servidor']
      });
    } finally {
      setImporting(false);
      // Reset file input
      event.target.value = '';
    }
  };

  const handleImportCostCenters = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImporting(true);
    setImportResults(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('/api/cost-centers/import', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Authorization': `Bearer ${btoa(JSON.stringify(user))}`
        },
        body: formData
      });

      const result = await response.json();
      setImportResults(result);
      
      if (result.success) {
        fetchData();
      }
    } catch (error) {
      setImportResults({
        success: false,
        message: 'Erro ao importar centros de custo',
        imported: 0,
        errors: ['Erro de conexão com o servidor']
      });
    } finally {
      setImporting(false);
      // Reset file input
      event.target.value = '';
    }
  };

  const downloadCategorySample = () => {
    // Create sample data for categories
    const sampleData = [
      { nome: 'Alimentação', descricao: 'Gastos com comida e bebidas' },
      { nome: 'Transporte', descricao: 'Combustível, transporte público, etc.' },
      { nome: 'Lazer', descricao: 'Entretenimento e diversão' },
      { nome: 'Saúde', descricao: 'Medicamentos, consultas médicas' },
      { nome: 'Educação', descricao: 'Cursos, livros, material escolar' },
      { nome: 'Casa', descricao: 'Aluguel, contas básicas, manutenção' },
      { nome: 'Vestuário', descricao: 'Roupas e acessórios' },
    ];

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(sampleData);

    // Add the worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Categorias');

    // Generate Excel file and download
    XLSX.writeFile(wb, 'exemplo_categorias.xlsx');
  };

  const downloadCostCenterSample = () => {
    // Create sample data for cost centers
    const sampleData = [
      { nome: 'Pessoal', descricao: 'Gastos pessoais individuais' },
      { nome: 'Casa', descricao: 'Despesas relacionadas ao lar' },
      { nome: 'Trabalho', descricao: 'Gastos profissionais e trabalho' },
      { nome: 'Família', descricao: 'Despesas familiares compartilhadas' },
      { nome: 'Investimentos', descricao: 'Aplicações e investimentos' },
      { nome: 'Negócios', descricao: 'Atividades empresariais' },
      { nome: 'Emergência', descricao: 'Fundo de emergência e imprevistos' },
    ];

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(sampleData);

    // Add the worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Centros de Custo');

    // Generate Excel file and download
    XLSX.writeFile(wb, 'exemplo_centros_custo.xlsx');
  };

  // Payroll Description functions
  const handleCreatePayrollDesc = async () => {
    try {
      // Validação do formulário
      if (!newPayrollDesc.name || newPayrollDesc.name.trim() === '') {
        setError('O nome do colaborador é obrigatório');
        return;
      }

      console.log("🔄 Creating payroll description:", newPayrollDesc);
      setError(null); // Limpar erros anteriores
      
      const payrollDescData = {
        name: newPayrollDesc.name.trim(),
        description: newPayrollDesc.description && newPayrollDesc.description.trim() !== '' ? newPayrollDesc.description.trim() : undefined,
        tipo: newPayrollDesc.tipo && newPayrollDesc.tipo.trim() !== '' ? newPayrollDesc.tipo.trim() : undefined
      };
      
      const response = await fetch("/api/payroll-descriptions", {
        method: "POST",
        credentials: 'include',
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        },
        body: JSON.stringify(payrollDescData)
      });

      console.log("📡 Payroll description creation response:", response.status);

      if (response.ok) {
        const result = await response.json();
        console.log("✅ Payroll description created successfully:", result);
        setShowPayrollDescModal(false);
        setNewPayrollDesc({ name: '', description: '', tipo: '' });
        await fetchData(); // Usar await para garantir que os dados sejam atualizados
        
        // Mostrar mensagem de sucesso temporária
        setImportResults({
          success: true,
          message: `Colaborador "${payrollDescData.name}" criado com sucesso!`,
          imported: 1,
          errors: []
        });
        
        // Limpar a mensagem após 3 segundos
        setTimeout(() => setImportResults(null), 3000);
      } else {
        const errorData = await response.json();
        console.error("❌ Error creating payroll description:", response.status, errorData);
        setError(`Erro ao criar colaborador: ${errorData.error || 'Erro desconhecido'}`);
      }
    } catch (error) {
      console.error("❌ Error creating payroll description:", error);
      setError(`Erro ao criar colaborador: ${error instanceof Error ? error.message : 'Erro de conexão'}`);
    }
  };

  const handleUpdatePayrollDesc = async (id: number) => {
    if (!editingPayrollDesc) return;

    try {
      const payrollDescData = {
        name: editingPayrollDesc.name,
        description: editingPayrollDesc.description && editingPayrollDesc.description.trim() === '' ? undefined : editingPayrollDesc.description,
        tipo: editingPayrollDesc.tipo && editingPayrollDesc.tipo.trim() === '' ? undefined : editingPayrollDesc.tipo
      };
      
      const response = await fetch(`/api/payroll-descriptions/${id}`, {
        method: "PUT",
        credentials: 'include',
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        },
        body: JSON.stringify(payrollDescData)
      });

      if (response.ok) {
        setEditingPayrollDesc(null);
        fetchData();
      } else {
        console.error("Error updating payroll description:", response.status);
      }
    } catch (error) {
      console.error("Error updating payroll description:", error);
    }
  };

  const handleDeletePayrollDesc = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir este colaborador?")) return;

    try {
      const response = await fetch(`/api/payroll-descriptions/${id}`, {
        method: "DELETE",
        credentials: 'include',
        headers: {
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        }
      });

      if (response.ok) {
        fetchData();
      } else {
        console.error("Error deleting payroll description:", response.status);
      }
    } catch (error) {
      console.error("Error deleting payroll description:", error);
    }
  };

  const handleImportPayrollDescs = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImporting(true);
    setImportResults(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('/api/payroll-descriptions/import', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Authorization': `Bearer ${btoa(JSON.stringify(user))}`
        },
        body: formData
      });

      const result = await response.json();
      setImportResults(result);
      
      if (result.success) {
        fetchData();
      }
    } catch (error) {
      setImportResults({
        success: false,
        message: 'Erro ao importar colaboradores',
        imported: 0,
        errors: ['Erro de conexão com o servidor']
      });
    } finally {
      setImporting(false);
      // Reset file input
      event.target.value = '';
    }
  };

  const downloadPayrollDescSample = () => {
    // Create sample data for payroll descriptions
    const sampleData = [
      { nome: 'João Silva', tipo: 'Funcionário CLT', descricao: 'Analista de Sistemas' },
      { nome: 'Maria Santos', tipo: 'Funcionário CLT', descricao: 'Gerente de Vendas' },
      { nome: 'Pedro Costa', tipo: 'Terceirizado', descricao: 'Consultor de TI' },
      { nome: 'Ana Oliveira', tipo: 'Freelancer', descricao: 'Designer Gráfica' },
      { nome: 'Carlos Ferreira', tipo: 'Funcionário CLT', descricao: 'Contador' },
      { nome: 'Julia Rodrigues', tipo: 'Estagiário', descricao: 'Assistente Administrativo' },
      { nome: 'Roberto Lima', tipo: 'Terceirizado', descricao: 'Técnico de Manutenção' },
      { nome: 'Luciana Alves', tipo: 'Funcionário CLT', descricao: 'Coordenadora de Marketing' },
      { nome: 'Fernando Souza', tipo: 'PJ', descricao: 'Desenvolvedor Frontend' },
      { nome: 'Camila Torres', tipo: 'Funcionário CLT', descricao: 'Analista Financeiro' },
      { nome: 'Gabriel Martins', tipo: 'Freelancer', descricao: 'Redator de Conteúdo' },
      { nome: 'Patrícia Gomes', tipo: 'Funcionário CLT', descricao: 'Recursos Humanos' },
      { nome: 'Ricardo Dias', tipo: 'Terceirizado', descricao: 'Motorista' },
      { nome: 'Beatriz Silva', tipo: 'Estagiário', descricao: 'Assistente de Marketing' }
    ];

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(sampleData);

    // Add the worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Colaboradores');

    // Generate Excel file and download
    XLSX.writeFile(wb, 'exemplo_colaboradores.xlsx');
  };

  // Repair orphaned records
  const handleRepairOrphanedRecords = async () => {
    if (!confirm('Esta operação vai associar dados importados que não apareceram na lista ao seu usuário. Deseja continuar?')) return;

    setRepairing(true);
    try {
      const response = await fetch('/api/repair-orphaned-records', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Authorization': `Bearer ${btoa(JSON.stringify(user))}`
        }
      });
      
      const result = await response.json();
      
      if (result.success) {
        const totalRepaired = Object.values(result.repaired || {}).reduce((sum: number, count: any) => sum + (count || 0), 0);
        setImportResults({
          success: true,
          message: `${totalRepaired} registro(s) reparado(s) com sucesso`,
          imported: totalRepaired,
          errors: []
        });
        fetchData(); // Refresh the data
      } else {
        setImportResults({
          success: false,
          message: 'Erro ao reparar dados',
          imported: 0,
          errors: [result.error || 'Erro desconhecido']
        });
      }
    } catch (error) {
      setImportResults({
        success: false,
        message: 'Erro ao conectar com o servidor',
        imported: 0,
        errors: ['Erro de conexão']
      });
    } finally {
      setRepairing(false);
    }
  };

  // Clear all data
  const handleClearAllData = async () => {
    setClearing(true);
    
    try {
      const response = await fetch('/api/clear-all-data', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Authorization': `Bearer ${btoa(JSON.stringify(user))}`
        }
      });
      
      const result = await response.json();
      
      if (result.success) {
        setImportResults({
          success: true,
          message: 'Configurações foram removidas com sucesso (categorias, centros de custo e colaboradores)',
          imported: 0,
          errors: []
        });
        fetchData(); // Refresh the data
      } else {
        setImportResults({
          success: false,
          message: 'Erro ao limpar as configurações',
          imported: 0,
          errors: [result.error || 'Erro desconhecido']
        });
      }
    } catch (error) {
      setImportResults({
        success: false,
        message: 'Erro ao conectar com o servidor para limpar configurações',
        imported: 0,
        errors: ['Erro de conexão']
      });
    } finally {
      setClearing(false);
      setShowClearModal(false);
    }
  };

  // Show loading state while auth is pending
  if (isPending) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  // Show error if user is not authenticated
  if (!user) {
    return (
      <div className="p-8">
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-6 text-center">
          <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-amber-800 mb-2">Acesso Negado</h3>
          <p className="text-amber-600 mb-4">Você precisa estar logado para acessar esta página.</p>
          <button
            onClick={() => window.location.href = '/login'}
            className="px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
          >
            Fazer Login
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8">
        <div className="bg-red-50 border border-red-200 rounded-2xl p-6 text-center">
          <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-red-800 mb-2">Erro ao Carregar Dados</h3>
          <p className="text-red-600 mb-4">{error}</p>
          <div className="space-y-2">
            <button
              onClick={fetchData}
              className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors mr-2"
            >
              Tentar Novamente
            </button>
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
            >
              Recarregar Página
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Configurações</h1>
          <p className="text-slate-600">Gerencie categorias, centros de custo e descrições da folha</p>
        </div>
        
        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleRepairOrphanedRecords}
            disabled={repairing}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 hover:shadow-lg transition-all duration-200 font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            title="Reparar dados importados que não aparecem na lista"
          >
            {repairing ? (
              <>
                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                Reparando...
              </>
            ) : (
              <>
                <RotateCcw className="w-4 h-4" />
                Reparar Dados
              </>
            )}
          </button>
          
          <button
            onClick={() => setShowClearModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 hover:shadow-lg transition-all duration-200 font-medium"
            title="Limpar configurações (categorias, centros de custo e colaboradores)"
          >
            <AlertTriangle className="w-4 h-4" />
            Limpar Configurações
          </button>
        </div>
      </div>

      {/* Import Results */}
      {importResults && (
        <div className={`mb-6 p-4 rounded-xl border ${
          importResults.success 
            ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
            : 'bg-red-50 border-red-200 text-red-800'
        }`}>
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">{importResults.message}</h3>
              {importResults.success && (
                <p className="text-sm mt-1">
                  {importResults.imported} item(s) importado(s) com sucesso
                </p>
              )}
            </div>
            <button
              onClick={() => setImportResults(null)}
              className="text-current hover:opacity-70"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          {importResults.errors && importResults.errors.length > 0 && (
            <div className="mt-3">
              <p className="text-sm font-medium">Erros encontrados:</p>
              <ul className="text-sm mt-1 list-disc list-inside">
                {importResults.errors.map((error, index) => (
                  <li key={index}>{error}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        {/* Categories Section */}
        <div className="bg-white rounded-2xl shadow-lg border border-slate-200/50">
          <div className="px-6 py-4 border-b border-slate-200/50 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg">
                <Tag className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-xl font-semibold text-slate-800">Categorias</h2>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="file"
                accept=".csv,.xlsx,.xls"
                onChange={handleImportCategories}
                className="hidden"
                id="import-categories"
                disabled={importing}
              />
              <button
                onClick={downloadCategorySample}
                className="flex items-center justify-center gap-2 px-4 py-2.5 bg-orange-600 text-white rounded-xl hover:bg-orange-700 hover:shadow-md transition-all duration-200 font-medium w-24"
                title="Baixar exemplo XLSX"
              >
                <Download className="w-4 h-4" />
                Modelo
              </button>
              <PlanRestriction requiredPlan="Pro" feature="importação em massa">
                <label
                  htmlFor="import-categories"
                  className={`flex items-center justify-center gap-2 px-4 py-2.5 bg-pink-600 text-white rounded-xl hover:bg-pink-700 hover:shadow-md transition-all duration-200 font-medium cursor-pointer w-24 ${importing ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <Upload className="w-4 h-4" />
                  {importing ? 'Importando...' : 'Importar'}
                </label>
              </PlanRestriction>
              <button
                onClick={() => setShowCategoryModal(true)}
                className="flex items-center justify-center gap-2 px-4 py-2.5 bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-xl hover:from-purple-700 hover:to-purple-800 hover:shadow-lg transition-all duration-200 font-medium w-24"
              >
                <Plus className="w-4 h-4" />
                Nova
              </button>
            </div>
          </div>

          <div className="p-6">
            <div className="space-y-4">
              {Array.isArray(categories) && paginatedCategories.map((category) => (
                <div key={category.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-200/50">
                  {editingCategory?.id === category.id ? (
                    <div className="flex-1 space-y-3">
                      <input
                        type="text"
                        value={editingCategory.name}
                        onChange={(e) => setEditingCategory({...editingCategory, name: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 text-sm"
                        placeholder="Nome da categoria"
                      />
                      <input
                        type="text"
                        value={editingCategory.description || ''}
                        onChange={(e) => setEditingCategory({...editingCategory, description: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 text-sm"
                        placeholder="Descrição (opcional)"
                      />
                      
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleUpdateCategory(category.id)}
                          className="flex items-center gap-1 px-3 py-1 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors text-sm"
                        >
                          <Save className="w-3 h-3" />
                          Salvar
                        </button>
                        <button
                          onClick={() => setEditingCategory(null)}
                          className="flex items-center gap-1 px-3 py-1 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors text-sm"
                        >
                          <X className="w-3 h-3" />
                          Cancelar
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div>
                        <div className="font-medium text-slate-800">{category.name}</div>
                        {category.description && (
                          <div className="text-sm text-slate-500">{category.description}</div>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setEditingCategory({
                            id: category.id,
                            name: category.name,
                            description: category.description || ''
                          })}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteCategory(category.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ))}
              {categories.length === 0 && (
                <div className="text-center py-8">
                  <Tag className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                  <p className="text-slate-500">Nenhuma categoria encontrada</p>
                  <p className="text-sm text-slate-400">Crie sua primeira categoria</p>
                </div>
              )}
            </div>

            {/* Categories Pagination */}
            {categories.length > 0 && (
              <div className="px-6 py-4 border-t border-slate-200/50 bg-slate-50/50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-600">Itens por página:</span>
                    <select
                      value={categoriesPerPage}
                      onChange={(e) => {
                        setCategoriesPerPage(Number(e.target.value));
                        setCategoriesPage(1);
                      }}
                      className="px-3 py-1 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    >
                      <option value={5}>5</option>
                      <option value={10}>10</option>
                      <option value={20}>20</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-4">
                    <span className="text-sm text-slate-600">
                      Mostrando {categoriesStartIndex + 1} a {Math.min(categoriesStartIndex + categoriesPerPage, categories.length)} de {categories.length}
                    </span>
                    
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => goToPage(categoriesPage - 1, setCategoriesPage, categoriesTotalPages)}
                        disabled={categoriesPage === 1}
                        className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </button>

                      <div className="flex items-center gap-1">
                        {Array.from({ length: Math.min(3, categoriesTotalPages) }, (_, i) => {
                          let pageNumber;
                          if (categoriesTotalPages <= 3) {
                            pageNumber = i + 1;
                          } else if (categoriesPage <= 2) {
                            pageNumber = i + 1;
                          } else if (categoriesPage >= categoriesTotalPages - 1) {
                            pageNumber = categoriesTotalPages - 2 + i;
                          } else {
                            pageNumber = categoriesPage - 1 + i;
                          }

                          return (
                            <button
                              key={pageNumber}
                              onClick={() => goToPage(pageNumber, setCategoriesPage, categoriesTotalPages)}
                              className={`px-3 py-1 text-sm rounded-lg transition-colors ${
                                categoriesPage === pageNumber
                                  ? 'bg-purple-600 text-white'
                                  : 'text-slate-600 hover:bg-slate-100'
                              }`}
                            >
                              {pageNumber}
                            </button>
                          );
                        })}
                      </div>

                      <button
                        onClick={() => goToPage(categoriesPage + 1, setCategoriesPage, categoriesTotalPages)}
                        disabled={categoriesPage === categoriesTotalPages}
                        className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Cost Centers Section */}
        <div className="bg-white rounded-2xl shadow-lg border border-slate-200/50">
          <div className="px-6 py-4 border-b border-slate-200/50 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg">
                <Building2 className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-xl font-semibold text-slate-800">Centros de Custo</h2>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="file"
                accept=".csv,.xlsx,.xls"
                onChange={handleImportCostCenters}
                className="hidden"
                id="import-cost-centers"
                disabled={importing}
              />
              <button
                onClick={downloadCostCenterSample}
                className="flex items-center justify-center gap-2 px-4 py-2.5 bg-lime-600 text-white rounded-xl hover:bg-lime-700 hover:shadow-md transition-all duration-200 font-medium w-24"
                title="Baixar exemplo XLSX"
              >
                <Download className="w-4 h-4" />
                Modelo
              </button>
              <label
                htmlFor="import-cost-centers"
                className={`flex items-center justify-center gap-2 px-4 py-2.5 bg-rose-600 text-white rounded-xl hover:bg-rose-700 hover:shadow-md transition-all duration-200 font-medium cursor-pointer w-24 ${importing ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <Upload className="w-4 h-4" />
                {importing ? 'Importando...' : 'Importar'}
              </label>
              <button
                onClick={() => setShowCostCenterModal(true)}
                className="flex items-center justify-center gap-2 px-4 py-2.5 bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-xl hover:from-cyan-700 hover:to-blue-700 hover:shadow-lg transition-all duration-200 font-medium w-24"
              >
                <Plus className="w-4 h-4" />
                Novo
              </button>
            </div>
          </div>

          <div className="p-6">
            <div className="space-y-4">
              {Array.isArray(costCenters) && paginatedCostCenters.map((costCenter) => (
                <div key={costCenter.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-200/50">
                  {editingCostCenter?.id === costCenter.id ? (
                    <div className="flex-1 space-y-3">
                      <input
                        type="text"
                        value={editingCostCenter.name}
                        onChange={(e) => setEditingCostCenter({...editingCostCenter, name: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                        placeholder="Nome do centro de custo"
                      />
                      <input
                        type="text"
                        value={editingCostCenter.description || ''}
                        onChange={(e) => setEditingCostCenter({...editingCostCenter, description: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                        placeholder="Descrição (opcional)"
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleUpdateCostCenter(costCenter.id)}
                          className="flex items-center gap-1 px-3 py-1 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
                        >
                          <Save className="w-3 h-3" />
                          Salvar
                        </button>
                        <button
                          onClick={() => setEditingCostCenter(null)}
                          className="flex items-center gap-1 px-3 py-1 bg-stone-500 text-white rounded-lg hover:bg-stone-600 transition-colors text-sm"
                        >
                          <X className="w-3 h-3" />
                          Cancelar
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div>
                        <div className="font-medium text-slate-800">{costCenter.name}</div>
                        {costCenter.description && (
                          <div className="text-sm text-slate-500">{costCenter.description}</div>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setEditingCostCenter({
                            id: costCenter.id,
                            name: costCenter.name,
                            description: costCenter.description || ''
                          })}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteCostCenter(costCenter.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ))}
              {costCenters.length === 0 && (
                <div className="text-center py-8">
                  <Building2 className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                  <p className="text-slate-500">Nenhum centro de custo encontrado</p>
                  <p className="text-sm text-slate-400">Crie seu primeiro centro de custo</p>
                </div>
              )}
            </div>

            {/* Cost Centers Pagination */}
            {costCenters.length > 0 && (
              <div className="px-6 py-4 border-t border-slate-200/50 bg-slate-50/50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-600">Itens por página:</span>
                    <select
                      value={costCentersPerPage}
                      onChange={(e) => {
                        setCostCentersPerPage(Number(e.target.value));
                        setCostCentersPage(1);
                      }}
                      className="px-3 py-1 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value={5}>5</option>
                      <option value={10}>10</option>
                      <option value={20}>20</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-4">
                    <span className="text-sm text-slate-600">
                      Mostrando {costCentersStartIndex + 1} a {Math.min(costCentersStartIndex + costCentersPerPage, costCenters.length)} de {costCenters.length}
                    </span>
                    
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => goToPage(costCentersPage - 1, setCostCentersPage, costCentersTotalPages)}
                        disabled={costCentersPage === 1}
                        className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </button>

                      <div className="flex items-center gap-1">
                        {Array.from({ length: Math.min(3, costCentersTotalPages) }, (_, i) => {
                          let pageNumber;
                          if (costCentersTotalPages <= 3) {
                            pageNumber = i + 1;
                          } else if (costCentersPage <= 2) {
                            pageNumber = i + 1;
                          } else if (costCentersPage >= costCentersTotalPages - 1) {
                            pageNumber = costCentersTotalPages - 2 + i;
                          } else {
                            pageNumber = costCentersPage - 1 + i;
                          }

                          return (
                            <button
                              key={pageNumber}
                              onClick={() => goToPage(pageNumber, setCostCentersPage, costCentersTotalPages)}
                              className={`px-3 py-1 text-sm rounded-lg transition-colors ${
                                costCentersPage === pageNumber
                                  ? 'bg-blue-600 text-white'
                                  : 'text-slate-600 hover:bg-slate-100'
                              }`}
                            >
                              {pageNumber}
                            </button>
                          );
                        })}
                      </div>

                      <button
                        onClick={() => goToPage(costCentersPage + 1, setCostCentersPage, costCentersTotalPages)}
                        disabled={costCentersPage === costCentersTotalPages}
                        className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Payroll Descriptions Section */}
        <div className="bg-white rounded-2xl shadow-lg border border-slate-200/50">
          <div className="px-6 py-4 border-b border-slate-200/50 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-lg">
                <User className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-xl font-semibold text-slate-800">Colaboradores</h2>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="file"
                accept=".csv,.xlsx,.xls"
                onChange={handleImportPayrollDescs}
                className="hidden"
                id="import-payroll-descriptions"
                disabled={importing}
              />
              <button
                onClick={downloadPayrollDescSample}
                className="flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 hover:shadow-md transition-all duration-200 font-medium w-24"
                title="Baixar exemplo XLSX"
              >
                <Download className="w-4 h-4" />
                Modelo
              </button>
              <label
                htmlFor="import-payroll-descriptions"
                className={`flex items-center justify-center gap-2 px-4 py-2.5 bg-cyan-600 text-white rounded-xl hover:bg-cyan-700 hover:shadow-md transition-all duration-200 font-medium cursor-pointer w-24 ${importing ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <Upload className="w-4 h-4" />
                {importing ? 'Importando...' : 'Importar'}
              </label>
              <button
                onClick={() => setShowPayrollDescModal(true)}
                className="flex items-center justify-center gap-2 px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl hover:from-emerald-700 hover:to-teal-700 hover:shadow-lg transition-all duration-200 font-medium w-24"
              >
                <Plus className="w-4 h-4" />
                Novo
              </button>
            </div>
          </div>

          <div className="p-6">
            <div className="space-y-4">
              {Array.isArray(payrollDescriptions) && paginatedPayrollDesc.map((desc) => (
                <div key={desc.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-200/50">
                  {editingPayrollDesc?.id === desc.id ? (
                    <div className="flex-1 space-y-3">
                      <input
                        type="text"
                        value={editingPayrollDesc.name}
                        onChange={(e) => setEditingPayrollDesc({...editingPayrollDesc, name: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                        placeholder="Nome do colaborador"
                      />
                      <input
                        type="text"
                        value={editingPayrollDesc.tipo || ''}
                        onChange={(e) => setEditingPayrollDesc({...editingPayrollDesc, tipo: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                        placeholder="Tipo (opcional)"
                      />
                      <input
                        type="text"
                        value={editingPayrollDesc.description || ''}
                        onChange={(e) => setEditingPayrollDesc({...editingPayrollDesc, description: e.target.value})}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm"
                        placeholder="Descrição (opcional)"
                      />
                      
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleUpdatePayrollDesc(desc.id)}
                          className="flex items-center gap-1 px-3 py-1 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors text-sm"
                        >
                          <Save className="w-3 h-3" />
                          Salvar
                        </button>
                        <button
                          onClick={() => setEditingPayrollDesc(null)}
                          className="flex items-center gap-1 px-3 py-1 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors text-sm"
                        >
                          <X className="w-3 h-3" />
                          Cancelar
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div>
                        <div className="font-medium text-slate-800">{desc.name}</div>
                        {desc.tipo && (
                          <div className="text-xs font-medium text-blue-600 mb-1">{desc.tipo}</div>
                        )}
                        {desc.description && (
                          <div className="text-sm text-slate-500">{desc.description}</div>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setEditingPayrollDesc({
                            id: desc.id,
                            name: desc.name,
                            description: desc.description || '',
                            tipo: desc.tipo || ''
                          })}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeletePayrollDesc(desc.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ))}
              {payrollDescriptions.length === 0 && (
                <div className="text-center py-8">
                  <User className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                  <p className="text-slate-500">Nenhum colaborador encontrado</p>
                  <p className="text-sm text-slate-400">Crie seu primeiro colaborador</p>
                </div>
              )}
            </div>

            {/* Payroll Descriptions Pagination */}
            {payrollDescriptions.length > 0 && (
              <div className="px-6 py-4 border-t border-slate-200/50 bg-slate-50/50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-600">Itens por página:</span>
                    <select
                      value={payrollDescPerPage}
                      onChange={(e) => {
                        setPayrollDescPerPage(Number(e.target.value));
                        setPayrollDescPage(1);
                      }}
                      className="px-3 py-1 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                    >
                      <option value={5}>5</option>
                      <option value={10}>10</option>
                      <option value={20}>20</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-4">
                    <span className="text-sm text-slate-600">
                      Mostrando {payrollDescStartIndex + 1} a {Math.min(payrollDescStartIndex + payrollDescPerPage, payrollDescriptions.length)} de {payrollDescriptions.length}
                    </span>
                    
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => goToPage(payrollDescPage - 1, setPayrollDescPage, payrollDescTotalPages)}
                        disabled={payrollDescPage === 1}
                        className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </button>

                      <div className="flex items-center gap-1">
                        {Array.from({ length: Math.min(3, payrollDescTotalPages) }, (_, i) => {
                          let pageNumber;
                          if (payrollDescTotalPages <= 3) {
                            pageNumber = i + 1;
                          } else if (payrollDescPage <= 2) {
                            pageNumber = i + 1;
                          } else if (payrollDescPage >= payrollDescTotalPages - 1) {
                            pageNumber = payrollDescTotalPages - 2 + i;
                          } else {
                            pageNumber = payrollDescPage - 1 + i;
                          }

                          return (
                            <button
                              key={pageNumber}
                              onClick={() => goToPage(pageNumber, setPayrollDescPage, payrollDescTotalPages)}
                              className={`px-3 py-1 text-sm rounded-lg transition-colors ${
                                payrollDescPage === pageNumber
                                  ? 'bg-emerald-600 text-white'
                                  : 'text-slate-600 hover:bg-slate-100'
                              }`}
                            >
                              {pageNumber}
                            </button>
                          );
                        })}
                      </div>

                      <button
                        onClick={() => goToPage(payrollDescPage + 1, setPayrollDescPage, payrollDescTotalPages)}
                        disabled={payrollDescPage === payrollDescTotalPages}
                        className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Category Modal */}
      {showCategoryModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-200/50">
              <h3 className="text-xl font-semibold text-slate-800">Nova Categoria</h3>
            </div>
            
            <div className="p-6 space-y-4">
              {error && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
                  <p className="text-red-800 text-sm font-medium">{error}</p>
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Nome *</label>
                <input
                  type="text"
                  value={newCategory.name}
                  onChange={(e) => {
                    setNewCategory({...newCategory, name: e.target.value});
                    if (error) setError(null); // Limpar erro quando usuário começar a digitar
                  }}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Nome da categoria"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Descrição</label>
                <input
                  type="text"
                  value={newCategory.description}
                  onChange={(e) => setNewCategory({...newCategory, description: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Descrição (opcional)"
                />
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => {
                  setShowCategoryModal(false);
                  setError(null); // Limpar erro ao cancelar
                }}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleCreateCategory}
                disabled={!newCategory.name || newCategory.name.trim() === ''}
                className="px-4 py-2 bg-gradient-to-r from-fuchsia-600 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Criar Categoria
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cost Center Modal */}
      {showCostCenterModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-200/50">
              <h3 className="text-xl font-semibold text-slate-800">Novo Centro de Custo</h3>
            </div>
            
            <div className="p-6 space-y-4">
              {error && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
                  <p className="text-red-800 text-sm font-medium">{error}</p>
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Nome *</label>
                <input
                  type="text"
                  value={newCostCenter.name}
                  onChange={(e) => {
                    setNewCostCenter({...newCostCenter, name: e.target.value});
                    if (error) setError(null);
                  }}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Nome do centro de custo"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Descrição</label>
                <input
                  type="text"
                  value={newCostCenter.description}
                  onChange={(e) => setNewCostCenter({...newCostCenter, description: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Descrição (opcional)"
                />
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => {
                  setShowCostCenterModal(false);
                  setError(null);
                }}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleCreateCostCenter}
                disabled={!newCostCenter.name || newCostCenter.name.trim() === ''}
                className="px-4 py-2 bg-gradient-to-r from-sky-600 to-indigo-600 text-white rounded-lg hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Criar Centro de Custo
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clear Configuration Data Modal */}
      {showClearModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-200/50 flex items-center gap-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold text-slate-800">Limpar Configurações</h3>
            </div>
            
            <div className="p-6">
              <div className="mb-4">
                <h4 className="font-medium text-slate-800 mb-2">🔧 Reparar Dados Importados</h4>
                <p className="text-slate-600 mb-3">
                  Se você importou dados mas eles não aparecem na lista, use o botão "Reparar Dados" acima para associá-los ao seu usuário.
                </p>
              </div>
              
              <div className="mb-4">
                <p className="text-slate-700 mb-2">
                  <strong>Limpar Configurações:</strong> Esta ação irá remover permanentemente apenas:
                </p>
                <ul className="list-disc list-inside text-sm text-slate-600 space-y-1 ml-4">
                  <li>Todas as categorias</li>
                  <li>Todos os centros de custo</li>
                  <li>Todos os colaboradores (descrições da folha)</li>
                </ul>
              </div>
              
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-4">
                <p className="text-amber-800 text-sm font-medium">
                  ℹ️ Seus dados principais serão preservados
                </p>
                <p className="text-amber-700 text-sm">
                  Transações, contas fixas, contas não fixas, folha de pagamento e contas a receber não serão afetadas.
                </p>
              </div>
              
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
                <p className="text-red-800 text-sm font-medium">
                  ⚠️ Esta ação não pode ser desfeita!
                </p>
                <p className="text-red-700 text-sm">
                  As configurações removidas precisarão ser recriadas manualmente ou via importação.
                </p>
              </div>
              
              <p className="text-slate-600 text-sm">
                Use esta opção para limpar apenas as configurações básicas do sistema.
              </p>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => setShowClearModal(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                disabled={clearing}
              >
                Cancelar
              </button>
              <button
                onClick={handleClearAllData}
                disabled={clearing}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {clearing ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                    Limpando...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    Limpar Configurações
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Payroll Description Modal */}
      {showPayrollDescModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-200/50">
              <h3 className="text-xl font-semibold text-slate-800">Novo Colaborador</h3>
            </div>
            
            <div className="p-6 space-y-4">
              {error && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
                  <p className="text-red-800 text-sm font-medium">{error}</p>
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Nome *</label>
                <input
                  type="text"
                  value={newPayrollDesc.name}
                  onChange={(e) => {
                    setNewPayrollDesc({...newPayrollDesc, name: e.target.value});
                    if (error) setError(null);
                  }}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="Nome do colaborador"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Tipo</label>
                <input
                  type="text"
                  value={newPayrollDesc.tipo}
                  onChange={(e) => setNewPayrollDesc({...newPayrollDesc, tipo: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="Ex: Funcionário, Terceirizado, Freelancer"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Descrição</label>
                <input
                  type="text"
                  value={newPayrollDesc.description}
                  onChange={(e) => setNewPayrollDesc({...newPayrollDesc, description: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="Descrição (opcional)"
                />
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => {
                  setShowPayrollDescModal(false);
                  setNewPayrollDesc({ name: '', description: '', tipo: '' });
                  setError(null);
                }}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleCreatePayrollDesc}
                disabled={!newPayrollDesc.name || newPayrollDesc.name.trim() === ''}
                className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-lg hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Criar Colaborador
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
