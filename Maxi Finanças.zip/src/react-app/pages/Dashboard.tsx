import { useEffect, useState } from "react";
import { Building2, CreditCard, Users, DollarSign, TrendingUp, PieChart } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RechartsPieChart, Pie, Cell, Area, AreaChart } from 'recharts';

interface DashboardData {
  balance: number;
  fixed_accounts_pending: number;
  variable_accounts_pending: number;
  payroll_pending: number;
  // Next month data
  fixed_accounts_next_month: number;
  variable_accounts_next_month: number;
  payroll_next_month: number;
  company_cost_next_month: number;
  category_breakdown: Array<{
    name: string;
    color: string;
    total: number;
    count: number;
  }>;
  monthly_data: Array<{
    month: string;
    receitas: number;
    despesas: number;
  }>;
}

export default function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await fetch("/api/dashboard");
      const dashboardData = await response.json();
      setData(dashboardData);
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    const formatted = new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(Math.abs(amount));
    
    return amount < 0 ? `-${formatted}` : formatted;
  };

  const formatMonthName = (monthStr: string) => {
    if (!monthStr) return '';
    const [year, month] = monthStr.split('-');
    const monthNames = [
      'Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun',
      'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'
    ];
    return `${monthNames[parseInt(month) - 1]} ${year}`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="pt-0">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-800 mb-2">Dashboard</h1>
        <p className="text-slate-600">Visão geral das suas finanças</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-gradient-to-br from-red-500 to-red-600 rounded-xl">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
            <span className="text-sm font-medium text-slate-500">Saldo Banco</span>
          </div>
          <div className="text-2xl font-bold text-slate-800">
            {formatCurrency(data?.balance || 0)}
          </div>
          <div className="text-sm text-slate-500 mt-1">
            {data?.balance && data.balance < 0 ? "Saldo negativo" : "Saldo atual"}
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl">
              <CreditCard className="w-6 h-6 text-white" />
            </div>
            <span className="text-sm font-medium text-slate-500">Contas Fixas</span>
          </div>
          <div className="text-2xl font-bold text-slate-800">
            {formatCurrency(data?.fixed_accounts_pending || 0)}
          </div>
          <div className="text-sm text-slate-500 mt-1">
            Contas fixas pendentes
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl">
              <Building2 className="w-6 h-6 text-white" />
            </div>
            <span className="text-sm font-medium text-slate-500">Contas não Fixas</span>
          </div>
          <div className="text-2xl font-bold text-slate-800">
            {formatCurrency(data?.variable_accounts_pending || 0)}
          </div>
          <div className="text-sm text-slate-500 mt-1">
            Contas não fixas pendentes
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl">
              <Users className="w-6 h-6 text-white" />
            </div>
            <span className="text-sm font-medium text-slate-500">Folha de Pagamento</span>
          </div>
          <div className="text-2xl font-bold text-slate-800">
            {formatCurrency(data?.payroll_pending || 0)}
          </div>
          <div className="text-sm text-slate-500 mt-1">
            Folha de pagamento pendente
          </div>
        </div>
      </div>

      {/* Next Month Cards */}
      <div className="mb-8">
        <h2 className="text-2xl font-semibold text-slate-800 mb-4">Próximo Mês</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-blue-400 to-blue-500 rounded-xl">
                <CreditCard className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-medium text-slate-500">Contas Fixas</span>
            </div>
            <div className="text-2xl font-bold text-slate-800">
              {formatCurrency(data?.fixed_accounts_next_month || 0)}
            </div>
            <div className="text-sm text-slate-500 mt-1">
              Próximo mês
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-purple-400 to-purple-500 rounded-xl">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-medium text-slate-500">Contas não Fixas</span>
            </div>
            <div className="text-2xl font-bold text-slate-800">
              {formatCurrency(data?.variable_accounts_next_month || 0)}
            </div>
            <div className="text-sm text-slate-500 mt-1">
              Próximo mês
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-emerald-400 to-emerald-500 rounded-xl">
                <Users className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-medium text-slate-500">Folha de Pagamento</span>
            </div>
            <div className="text-2xl font-bold text-slate-800">
              {formatCurrency(data?.payroll_next_month || 0)}
            </div>
            <div className="text-sm text-slate-500 mt-1">
              Próximo mês
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-medium text-slate-500">Custo Empresa</span>
            </div>
            <div className="text-2xl font-bold text-slate-800">
              {formatCurrency(data?.company_cost_next_month || 0)}
            </div>
            <div className="text-sm text-slate-500 mt-1">
              Custo total próximo mês
            </div>
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Monthly Income vs Expenses Chart */}
        <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-xl font-semibold text-slate-800">Receitas vs Despesas (Últimos 6 Meses)</h2>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data?.monthly_data?.map(item => ({
              name: formatMonthName(item.month),
              receitas: item.receitas,
              despesas: item.despesas
            })) || []}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip 
                formatter={(value: number) => [formatCurrency(value), '']}
                labelStyle={{ color: '#1e293b' }}
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e2e8f0', 
                  borderRadius: '8px' 
                }}
              />
              <Bar dataKey="receitas" fill="#10b981" name="Receitas" radius={[4, 4, 0, 0]} />
              <Bar dataKey="despesas" fill="#ef4444" name="Despesas" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Pie Chart - Next Month Distribution */}
        <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-gradient-to-br from-emerald-500 to-cyan-600 rounded-lg">
              <PieChart className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-xl font-semibold text-slate-800">Distribuição - Próximo Mês</h2>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <RechartsPieChart>
              <Pie
                data={[
                  { 
                    name: 'Contas Fixas', 
                    value: Math.abs(data?.fixed_accounts_next_month || 0),
                    color: '#3b82f6'
                  },
                  { 
                    name: 'Contas não Fixas', 
                    value: Math.abs(data?.variable_accounts_next_month || 0),
                    color: '#8b5cf6'
                  },
                  { 
                    name: 'Folha Pagamento', 
                    value: Math.abs(data?.payroll_next_month || 0),
                    color: '#10b981'
                  }
                ]}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={120}
                paddingAngle={5}
                dataKey="value"
              >
                {[
                  { color: '#3b82f6' },
                  { color: '#8b5cf6' },
                  { color: '#10b981' }
                ].map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value: number) => [formatCurrency(value), '']}
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e2e8f0', 
                  borderRadius: '8px' 
                }}
              />
            </RechartsPieChart>
          </ResponsiveContainer>
          <div className="flex justify-center gap-4 mt-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <span className="text-sm text-slate-600">Contas Fixas</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
              <span className="text-sm text-slate-600">Contas não Fixas</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-emerald-500 rounded-full"></div>
              <span className="text-sm text-slate-600">Folha Pagamento</span>
            </div>
          </div>
        </div>
      </div>

      {/* Financial Overview Chart */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200/50">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-gradient-to-br from-orange-500 to-red-600 rounded-lg">
            <DollarSign className="w-5 h-5 text-white" />
          </div>
          <h2 className="text-xl font-semibold text-slate-800">Visão Geral Financeira</h2>
        </div>
        <ResponsiveContainer width="100%" height={250}>
          <AreaChart data={[
            {
              name: 'Saldo Atual',
              valor: data?.balance || 0,
              tipo: 'Saldo'
            },
            {
              name: 'Pendências Atuais',
              valor: -(Math.abs(data?.fixed_accounts_pending || 0) + Math.abs(data?.variable_accounts_pending || 0) + Math.abs(data?.payroll_pending || 0)),
              tipo: 'Pendente'
            },
            {
              name: 'Custo Próximo Mês',
              valor: -(data?.company_cost_next_month || 0),
              tipo: 'Projeção'
            }
          ]}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis dataKey="name" tick={{ fontSize: 12 }} />
            <YAxis tick={{ fontSize: 12 }} />
            <Tooltip 
              formatter={(value: number) => [formatCurrency(value), '']}
              labelStyle={{ color: '#1e293b' }}
              contentStyle={{ 
                backgroundColor: 'white', 
                border: '1px solid #e2e8f0', 
                borderRadius: '8px' 
              }}
            />
            <Area 
              type="monotone" 
              dataKey="valor" 
              stroke="#f59e0b" 
              fill="url(#colorGradient)" 
              strokeWidth={2}
            />
            <defs>
              <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.1}/>
              </linearGradient>
            </defs>
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
