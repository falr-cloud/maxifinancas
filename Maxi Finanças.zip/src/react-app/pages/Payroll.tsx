import { useEffect, useState } from "react";
import { Plus, Trash2, DollarSign, Filter, Edit3, Download, Upload, X, ChevronLeft, ChevronRight, ChevronUp, ChevronDown, AlertTriangle, Users, RotateCcw } from "lucide-react";
import { PayrollWithDetails, Category, CostCenter, PayrollDescription } from "@/shared/types";
import * as XLSX from 'xlsx';

export default function Payroll() {
  const [payrollItems, setPayrollItems] = useState<PayrollWithDetails[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [payrollDescriptions, setPayrollDescriptions] = useState<PayrollDescription[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingItem, setEditingItem] = useState<PayrollWithDetails | null>(null);
  
  const [newItem, setNewItem] = useState({
    description: '',
    amount: '',
    category_id: '',
    cost_center_id: '',
    status: 'NÃO PAGO'
  });
  
  const [editItem, setEditItem] = useState({
    description: '',
    amount: '',
    category_id: '',
    cost_center_id: '',
    status: 'NÃO PAGO'
  });

  // Amount editing states
  const [editingAmountId, setEditingAmountId] = useState<number | null>(null);
  const [editingAmountValue, setEditingAmountValue] = useState('');

  // Filter states
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [filters, setFilters] = useState({
    categoryIds: [] as string[],
    costCenterIds: [] as string[],
    collaboratorNames: [] as string[],
    collaboratorTypes: [] as string[],
    status: ''
  });
  const [appliedFilters, setAppliedFilters] = useState({
    categoryIds: [] as string[],
    costCenterIds: [] as string[],
    collaboratorNames: [] as string[],
    collaboratorTypes: [] as string[],
    status: ''
  });

  // Import state
  const [importing, setImporting] = useState(false);
  const [importResults, setImportResults] = useState<{
    success: boolean;
    message: string;
    imported: number;
    errors: string[];
  } | null>(null);

  // Selection state
  const [selectedItems, setSelectedItems] = useState<Set<number>>(new Set());
  const [selectAll, setSelectAll] = useState(false);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(25);

  // Sorting state
  const [sortField, setSortField] = useState<'description' | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // Clear data state
  const [showClearModal, setShowClearModal] = useState(false);
  const [clearing, setClearing] = useState(false);

  // Reset payments state
  const [showResetPaymentsModal, setShowResetPaymentsModal] = useState(false);
  const [resettingPayments, setResettingPayments] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Get user data for authorization header
      const userData = localStorage.getItem('maxifinancas_user');
      const authHeaders: HeadersInit = userData ? {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${btoa(userData)}`
      } : {
        'Content-Type': 'application/json',
      };

      const [itemsRes, categoriesRes, costCentersRes, payrollDescRes] = await Promise.all([
        fetch("/api/payroll", {
          credentials: 'include',
          headers: authHeaders
        }),
        fetch("/api/categories", {
          credentials: 'include',
          headers: authHeaders
        }),
        fetch("/api/cost-centers", {
          credentials: 'include',
          headers: authHeaders
        }),
        fetch("/api/payroll-descriptions", {
          credentials: 'include',
          headers: authHeaders
        })
      ]);

      if (!itemsRes.ok || !categoriesRes.ok || !costCentersRes.ok || !payrollDescRes.ok) {
        throw new Error('Failed to fetch data');
      }

      const [itemsData, categoriesData, costCentersData, payrollDescData] = await Promise.all([
        itemsRes.json(),
        categoriesRes.json(),
        costCentersRes.json(),
        payrollDescRes.json()
      ]);

      setPayrollItems(itemsData || []);
      setCategories(categoriesData || []);
      setCostCenters(costCentersData || []);
      setPayrollDescriptions(payrollDescData || []);
    } catch (error) {
      console.error("Error fetching data:", error);
      setPayrollItems([]);
      setCategories([]);
      setCostCenters([]);
      setPayrollDescriptions([]);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateItem = async () => {
    try {
      // Ensure amount is negative for expenses
      let amount = parseFloat(newItem.amount);
      if (amount > 0) {
        amount = -amount;
      }

      // Get user data for authorization header
      const userData = localStorage.getItem('maxifinancas_user');
      const authHeaders: HeadersInit = userData ? {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${btoa(userData)}`
      } : {
        'Content-Type': 'application/json',
      };
      
      const response = await fetch("/api/payroll", {
        method: "POST",
        credentials: 'include',
        headers: authHeaders,
        body: JSON.stringify({
          ...newItem,
          amount: amount,
          category_id: newItem.category_id ? parseInt(newItem.category_id) : undefined,
          cost_center_id: newItem.cost_center_id ? parseInt(newItem.cost_center_id) : undefined,
        })
      });

      if (response.ok) {
        setShowModal(false);
        setNewItem({
          description: '',
          amount: '',
          category_id: '',
          cost_center_id: '',
          status: 'NÃO PAGO'
        });
        fetchData();
      }
    } catch (error) {
      console.error("Error creating payroll item:", error);
    }
  };

  const handleEditItem = (item: PayrollWithDetails) => {
    setEditingItem(item);
    setEditItem({
      description: item.description,
      amount: item.amount.toString(),
      category_id: item.category_id?.toString() || '',
      cost_center_id: item.cost_center_id?.toString() || '',
      status: item.status || 'NÃO PAGO'
    });
    setShowEditModal(true);
  };

  const handleUpdateItem = async () => {
    if (!editingItem) return;

    try {
      // Ensure amount is negative for expenses
      let amount = parseFloat(editItem.amount);
      if (amount > 0) {
        amount = -amount;
      }

      // Get user data for authorization header
      const userData = localStorage.getItem('maxifinancas_user');
      const authHeaders = userData ? {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${btoa(userData)}`
      } : {
        'Content-Type': 'application/json',
      };
      
      const response = await fetch(`/api/payroll/${editingItem.id}`, {
        method: "PUT",
        credentials: 'include',
        headers: authHeaders,
        body: JSON.stringify({
          ...editItem,
          amount: amount,
          category_id: editItem.category_id ? parseInt(editItem.category_id) : undefined,
          cost_center_id: editItem.cost_center_id ? parseInt(editItem.cost_center_id) : undefined,
        })
      });

      if (response.ok) {
        setShowEditModal(false);
        setEditingItem(null);
        setEditItem({
          description: '',
          amount: '',
          category_id: '',
          cost_center_id: '',
          status: 'NÃO PAGO'
        });
        fetchData();
      }
    } catch (error) {
      console.error("Error updating payroll item:", error);
    }
  };

  const handleToggleStatus = async (id: number) => {
    // Find the item to get current status
    const item = payrollItems.find(i => i.id === id);
    if (!item) return;
    
    const currentStatus = item.status || 'NÃO PAGO';
    const newStatus = currentStatus === 'PAGO' ? 'NÃO PAGO' : 'PAGO';
    
    // Show confirmation dialog
    if (!confirm(`Tem certeza que deseja alterar o status deste item da folha de pagamento de "${currentStatus}" para "${newStatus}"?`)) {
      return;
    }
    
    try {
      // Get user data for authorization header
      const userData = localStorage.getItem('maxifinancas_user');
      const authHeaders = userData ? {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${btoa(userData)}`
      } : {
        'Content-Type': 'application/json',
      };

      const response = await fetch(`/api/payroll/${id}/status`, {
        method: "PATCH",
        credentials: 'include',
        headers: authHeaders
      });

      if (response.ok) {
        fetchData();
      }
    } catch (error) {
      console.error("Error toggling payroll item status:", error);
    }
  };

  const handleStartEditAmount = (id: number, currentAmount: number) => {
    setEditingAmountId(id);
    setEditingAmountValue(currentAmount.toString());
  };

  const handleCancelEditAmount = () => {
    setEditingAmountId(null);
    setEditingAmountValue('');
  };

  const handleSaveAmount = async (id: number) => {
    try {
      let amount = parseFloat(editingAmountValue);
      if (isNaN(amount)) {
        alert("Por favor, insira um valor numérico válido");
        return;
      }

      // Ensure amount is negative for expenses
      if (amount > 0) {
        amount = -amount;
      }

      // Get user data for authorization header
      const userData = localStorage.getItem('maxifinancas_user');
      const authHeaders = userData ? {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${btoa(userData)}`
      } : {
        'Content-Type': 'application/json',
      };

      const response = await fetch(`/api/payroll/${id}/amount`, {
        method: "PATCH",
        credentials: 'include',
        headers: authHeaders,
        body: JSON.stringify({ amount })
      });

      if (response.ok) {
        setEditingAmountId(null);
        setEditingAmountValue('');
        fetchData();
      } else {
        alert("Erro ao atualizar o valor");
      }
    } catch (error) {
      console.error("Error updating payroll item amount:", error);
      alert("Erro ao atualizar o valor");
    }
  };

  const handleDeleteItem = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir este item da folha de pagamento?")) return;

    try {
      // Get user data for authorization header
      const userData = localStorage.getItem('maxifinancas_user');
      const authHeaders = userData ? {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${btoa(userData)}`
      } : {
        'Content-Type': 'application/json',
      };

      const response = await fetch(`/api/payroll/${id}`, {
        method: "DELETE",
        credentials: 'include',
        headers: authHeaders
      });

      if (response.ok) {
        fetchData();
      }
    } catch (error) {
      console.error("Error deleting payroll item:", error);
    }
  };

  const handleSelectItem = (id: number, checked: boolean) => {
    const newSelected = new Set(selectedItems);
    if (checked) {
      newSelected.add(id);
    } else {
      newSelected.delete(id);
    }
    setSelectedItems(newSelected);
    
    // Update select all state
    setSelectAll(newSelected.size === paginatedItems.length && paginatedItems.length > 0);
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const allIds = new Set(paginatedItems.map(item => item.id));
      setSelectedItems(allIds);
    } else {
      setSelectedItems(new Set());
    }
    setSelectAll(checked);
  };

  const handleBulkPay = async () => {
    if (selectedItems.size === 0) return;
    
    if (!confirm(`Tem certeza que deseja marcar ${selectedItems.size} item(ns) da folha de pagamento selecionado(s) como PAGO?`)) return;

    try {
      // Get user data for authorization header
      const userData = localStorage.getItem('maxifinancas_user');
      const authHeaders = userData ? {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${btoa(userData)}`
      } : {
        'Content-Type': 'application/json',
      };

      const payPromises = Array.from(selectedItems).map(id =>
        fetch(`/api/payroll/${id}/bulk-pay`, { 
          method: "PATCH",
          credentials: 'include',
          headers: authHeaders
        })
      );

      await Promise.all(payPromises);
      
      setSelectedItems(new Set());
      setSelectAll(false);
      fetchData();
    } catch (error) {
      console.error("Error marking payroll items as paid:", error);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedItems.size === 0) return;
    
    if (!confirm(`Tem certeza que deseja excluir ${selectedItems.size} item(ns) da folha de pagamento selecionado(s)?`)) return;

    try {
      // Get user data for authorization header
      const userData = localStorage.getItem('maxifinancas_user');
      const authHeaders = userData ? {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${btoa(userData)}`
      } : {
        'Content-Type': 'application/json',
      };

      const deletePromises = Array.from(selectedItems).map(id =>
        fetch(`/api/payroll/${id}`, { 
          method: "DELETE",
          credentials: 'include',
          headers: authHeaders
        })
      );

      await Promise.all(deletePromises);
      
      setSelectedItems(new Set());
      setSelectAll(false);
      fetchData();
    } catch (error) {
      console.error("Error deleting payroll items:", error);
    }
  };

  const formatCurrency = (amount: number) => {
    const formatted = new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(Math.abs(amount));
    
    return amount < 0 ? `-${formatted}` : formatted;
  };

  const getCategoryById = (id: number) => categories.find(c => c.id === id);
  const getCostCenterById = (id: number) => costCenters.find(cc => cc.id === id);
  
  // Get unique collaborator names
  const uniqueCollaborators = Array.from(new Set(payrollItems.map(item => item.description)))
    .filter(name => name && name.trim() !== '')
    .sort((a, b) => a.localeCompare(b, 'pt-BR'));
  
  // Get unique collaborator types
  const uniqueCollaboratorTypes = Array.from(new Set(payrollDescriptions
    .map(desc => desc.tipo)
    .filter(tipo => tipo && tipo.trim() !== '')))
    .sort((a, b) => a!.localeCompare(b!, 'pt-BR'));

  // Sorting function
  const handleSort = (field: 'description') => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
    // Reset to first page when sorting
    setCurrentPage(1);
    // Clear selections when sorting
    setSelectedItems(new Set());
    setSelectAll(false);
  };

  // Apply filters and sorting
  const filteredAndSortedItems = payrollItems.filter(item => {
    // Category filter
    if (appliedFilters.categoryIds.length > 0) {
      const categoryIdNumbers = appliedFilters.categoryIds.map(id => parseInt(id));
      if (!item.category_id || !categoryIdNumbers.includes(item.category_id)) {
        return false;
      }
    }

    // Cost center filter
    if (appliedFilters.costCenterIds.length > 0) {
      const costCenterIdNumbers = appliedFilters.costCenterIds.map(id => parseInt(id));
      if (!item.cost_center_id || !costCenterIdNumbers.includes(item.cost_center_id)) {
        return false;
      }
    }

    // Collaborator filter
    if (appliedFilters.collaboratorNames.length > 0) {
      if (!appliedFilters.collaboratorNames.includes(item.description)) {
        return false;
      }
    }

    // Collaborator type filter
    if (appliedFilters.collaboratorTypes.length > 0) {
      // Find the collaborator description that matches this payroll item
      const collaboratorDesc = payrollDescriptions.find(desc => desc.name === item.description);
      const collaboratorType = collaboratorDesc?.tipo;
      
      if (!collaboratorType || !appliedFilters.collaboratorTypes.includes(collaboratorType)) {
        return false;
      }
    }

    // Status filter
    if (appliedFilters.status && (item.status || 'NÃO PAGO') !== appliedFilters.status) {
      return false;
    }

    return true;
  }).sort((a, b) => {
    if (!sortField) return 0;
    
    if (sortField === 'description') {
      const aValue = a.description.toLowerCase();
      const bValue = b.description.toLowerCase();
      const comparison = aValue.localeCompare(bValue, 'pt-BR');
      return sortDirection === 'asc' ? comparison : -comparison;
    }
    
    return 0;
  });

  const filteredItems = filteredAndSortedItems;

  const totalAmount = filteredItems.reduce((sum, item) => {
    if ((item.status || 'NÃO PAGO') !== 'PAGO') {
      return sum + item.amount;
    }
    return sum;
  }, 0);

  // Pagination calculations
  const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedItems = filteredItems.slice(startIndex, endIndex);

  // Reset to first page when items per page changes
  const handleItemsPerPageChange = (newItemsPerPage: number) => {
    setItemsPerPage(newItemsPerPage);
    setCurrentPage(1);
    // Clear selections when changing pagination
    setSelectedItems(new Set());
    setSelectAll(false);
  };

  // Navigate to specific page
  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
      // Clear selections when changing page
      setSelectedItems(new Set());
      setSelectAll(false);
    }
  };

  // Handle right click to clear all selections
  const handleRightClick = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent browser context menu
    if (selectedItems.size > 0) {
      setSelectedItems(new Set());
      setSelectAll(false);
    }
  };

  // Filter functions
  const handleApplyFilters = () => {
    setAppliedFilters(filters);
    setCurrentPage(1); // Reset to first page
    setSelectedItems(new Set()); // Clear selections
    setSelectAll(false);
    setShowFilterModal(false);
  };

  const handleClearFilters = () => {
    const emptyFilters = {
      categoryIds: [] as string[],
      costCenterIds: [] as string[],
      collaboratorNames: [] as string[],
      collaboratorTypes: [] as string[],
      status: ''
    };
    setFilters(emptyFilters);
    setAppliedFilters(emptyFilters);
    setCurrentPage(1);
    setSelectedItems(new Set());
    setSelectAll(false);
    setShowFilterModal(false);
  };

  const handleOpenFilterModal = () => {
    setFilters(appliedFilters);
    setShowFilterModal(true);
  };

  // Count active filters
  const activeFilterCount = Object.entries(appliedFilters).filter(([key, value]) => {
    if (key === 'categoryIds' || key === 'costCenterIds' || key === 'collaboratorNames' || key === 'collaboratorTypes') {
      return Array.isArray(value) && value.length > 0;
    }
    return value !== '';
  }).length;

  // Import functions
  const handleImportPayroll = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImporting(true);
    setImportResults(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      // Get user data for authorization header (no Content-Type for FormData)
      const userData = localStorage.getItem('maxifinancas_user');
      const authHeaders = userData ? {
        'Authorization': `Bearer ${btoa(userData)}`
      } : {};

      const response = await fetch('/api/payroll/import', {
        method: 'POST',
        credentials: 'include',
        headers: authHeaders,
        body: formData
      });

      const result = await response.json();
      setImportResults(result);
      
      if (result.success) {
        fetchData();
      }
    } catch (error) {
      setImportResults({
        success: false,
        message: 'Erro ao importar folha de pagamento',
        imported: 0,
        errors: ['Erro de conexão com o servidor']
      });
    } finally {
      setImporting(false);
      // Reset file input
      event.target.value = '';
    }
  };

  // Clear all payroll
  const handleClearAllPayroll = async () => {
    setClearing(true);
    
    try {
      // Get user data for authorization header
      const userData = localStorage.getItem('maxifinancas_user');
      const authHeaders = userData ? {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${btoa(userData)}`
      } : {
        'Content-Type': 'application/json',
      };

      const response = await fetch('/api/clear-payroll', {
        method: 'POST',
        credentials: 'include',
        headers: authHeaders
      });
      
      const result = await response.json();
      
      if (result.success) {
        setImportResults({
          success: true,
          message: result.message,
          imported: 0,
          errors: []
        });
        fetchData(); // Refresh the data
      } else {
        setImportResults({
          success: false,
          message: 'Erro ao limpar folha de pagamento',
          imported: 0,
          errors: [result.error || 'Erro desconhecido']
        });
      }
    } catch (error) {
      setImportResults({
        success: false,
        message: 'Erro ao conectar com o servidor',
        imported: 0,
        errors: ['Erro de conexão']
      });
    } finally {
      setClearing(false);
      setShowClearModal(false);
    }
  };

  // Reset payments for filtered items only
  const handleResetFilteredPayments = async () => {
    if (filteredItems.length === 0) {
      alert('Nenhum item encontrado com os filtros aplicados.');
      return;
    }

    const paidItems = filteredItems.filter(item => (item.status || 'NÃO PAGO') === 'PAGO');
    
    if (paidItems.length === 0) {
      alert('Nenhum item pago encontrado nos filtros aplicados.');
      return;
    }

    const confirmMessage = activeFilterCount > 0 
      ? `Tem certeza que deseja zerar ${paidItems.length} pagamento(s) dos itens filtrados?\n\nEsta ação irá alterar apenas os itens que aparecem na lista atual (respeitando os filtros aplicados).`
      : `Tem certeza que deseja zerar ${paidItems.length} pagamento(s) de toda a folha de pagamento?`;

    if (!confirm(confirmMessage)) return;

    setResettingPayments(true);

    try {
      // Get user data for authorization header
      const userData = localStorage.getItem('maxifinancas_user');
      const authHeaders = userData ? {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${btoa(userData)}`
      } : {
        'Content-Type': 'application/json',
      };

      // Reset payments for each paid item in the filtered list
      const resetPromises = paidItems.map(item =>
        fetch(`/api/payroll/${item.id}/status`, {
          method: "PATCH",
          credentials: 'include',
          headers: authHeaders
        })
      );

      await Promise.all(resetPromises);

      setImportResults({
        success: true,
        message: `${paidItems.length} pagamento(s) zerado(s) com sucesso`,
        imported: 0,
        errors: []
      });

      fetchData(); // Refresh the data
    } catch (error) {
      setImportResults({
        success: false,
        message: 'Erro ao zerar pagamentos',
        imported: 0,
        errors: ['Erro de conexão com o servidor']
      });
    } finally {
      setResettingPayments(false);
      setShowResetPaymentsModal(false);
    }
  };

  const downloadPayrollSample = () => {
    // Create comprehensive sample data for payroll
    const sampleData = [
      // Salários e benefícios
      { descricao: 'Salário João Silva', categoria: 'Salarios', centro_custo: 'Pessoal', valor: 5000.00, status: 'NÃO PAGO' },
      { descricao: 'Salário Maria Santos', categoria: 'Salarios', centro_custo: 'Pessoal', valor: 4500.00, status: 'PAGO' },
      { descricao: 'Vale Alimentação', categoria: 'Beneficios', centro_custo: 'Pessoal', valor: 800.00, status: 'NÃO PAGO' },
      { descricao: 'Vale Transporte', categoria: 'Beneficios', centro_custo: 'Pessoal', valor: 220.00, status: 'PAGO' },
      { descricao: 'Plano de Saúde', categoria: 'Beneficios', centro_custo: 'Pessoal', valor: 450.00, status: 'NÃO PAGO' },
      
      // Encargos sociais
      { descricao: 'INSS Patronal', categoria: 'Encargos', centro_custo: 'Financeiro', valor: 950.00, status: 'NÃO PAGO' },
      { descricao: 'FGTS', categoria: 'Encargos', centro_custo: 'Financeiro', valor: 760.00, status: 'PAGO' },
      { descricao: 'PIS sobre Folha', categoria: 'Encargos', centro_custo: 'Financeiro', valor: 95.00, status: 'NÃO PAGO' },
      
      // Benefícios extras
      { descricao: 'Hora Extra João', categoria: 'Extras', centro_custo: 'Operacional', valor: 350.00, status: 'PAGO' },
      { descricao: 'Comissão Vendas', categoria: 'Comissoes', centro_custo: 'Vendas', valor: 1200.00, status: 'NÃO PAGO' },
      { descricao: 'Adicional Noturno', categoria: 'Extras', centro_custo: 'Operacional', valor: 280.00, status: 'NÃO PAGO' },
      
      // Descontos e provisões
      { descricao: 'Provisão 13º Salário', categoria: 'Provisoes', centro_custo: 'Financeiro', valor: 792.00, status: 'PAGO' },
      { descricao: 'Provisão Férias', categoria: 'Provisoes', centro_custo: 'Financeiro', valor: 875.00, status: 'NÃO PAGO' },
      { descricao: 'Seguro de Vida', categoria: 'Beneficios', centro_custo: 'Pessoal', valor: 35.00, status: 'PAGO' }
    ];

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(sampleData);

    // Auto-size columns
    const colWidths = [
      { wch: 25 }, // descricao
      { wch: 15 }, // categoria
      { wch: 15 }, // centro_custo
      { wch: 12 }, // valor
      { wch: 10 }  // status
    ];
    ws['!cols'] = colWidths;

    // Add the worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Exemplo_Folha_Pagamento');

    // Generate Excel file and download
    XLSX.writeFile(wb, 'exemplo_importacao_folha_pagamento.xlsx');
  };

  const handleExportPayroll = () => {
    // Export current filtered data
    const exportData = filteredItems.map(item => {
      const category = getCategoryById(item.category_id || 0);
      const costCenter = getCostCenterById(item.cost_center_id || 0);
      
      return {
        descricao: item.description,
        categoria: category?.name || '',
        centro_custo: costCenter?.name || '',
        valor: item.amount,
        status: item.status || 'NÃO PAGO'
      };
    });

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(exportData);

    // Auto-size columns
    const colWidths = [
      { wch: 25 }, // descricao
      { wch: 15 }, // categoria
      { wch: 15 }, // centro_custo
      { wch: 12 }, // valor
      { wch: 10 }  // status
    ];
    ws['!cols'] = colWidths;

    // Add the worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Folha_Pagamento');

    // Generate Excel file and download
    const today = new Date().toISOString().split('T')[0].replace(/-/g, '');
    XLSX.writeFile(wb, `folha_pagamento_export_${today}.xlsx`);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="p-8">
      {/* Import Results */}
      {importResults && (
        <div className={`mb-6 p-4 rounded-xl border ${
          importResults.success 
            ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
            : 'bg-red-50 border-red-200 text-red-800'
        }`}>
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">{importResults.message}</h3>
              {importResults.success && (
                <p className="text-sm mt-1">
                  {importResults.imported} item(ns) da folha de pagamento importado(s) com sucesso
                </p>
              )}
            </div>
            <button
              onClick={() => setImportResults(null)}
              className="text-current hover:opacity-70"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          {importResults.errors && importResults.errors.length > 0 && (
            <div className="mt-3">
              <p className="text-sm font-medium">Erros encontrados:</p>
              <ul className="text-sm mt-1 list-disc list-inside">
                {importResults.errors.map((error, index) => (
                  <li key={index}>{error}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Folha de Pagamento</h1>
          <p className="text-slate-600">Gerencie os custos da folha de pagamento da empresa</p>
        </div>
        
        <div className="flex gap-3">
          {/* Reset Payments Button */}
          <button
            onClick={() => setShowResetPaymentsModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-xl hover:bg-orange-700 hover:shadow-lg transition-all duration-200 font-medium"
            title="Alterar todos os lançamentos de PAGO para NÃO PAGO"
          >
            <RotateCcw className="w-4 h-4" />
            Zerar Pagamentos
          </button>
          
          {/* Clear All Payroll Button */}
          <button
            onClick={() => setShowClearModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 hover:shadow-lg transition-all duration-200 font-medium"
            title="Limpar toda a folha de pagamento"
          >
            <AlertTriangle className="w-4 h-4" />
            Limpar Tudo
          </button>
        </div>
      </div>

      <div className="flex items-center justify-between mb-8">
        <div className="invisible">
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Folha de Pagamento</h1>
          <p className="text-slate-600">Gerencie os custos da folha de pagamento da empresa</p>
        </div>
        <div className="flex gap-3">
          {selectedItems.size > 0 && (
            <>
              <button
                onClick={handleBulkPay}
                className="flex items-center justify-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-colors font-medium min-w-[140px]"
              >
                <DollarSign className="w-4 h-4" />
                Pagar ({selectedItems.size})
              </button>
              <button
                onClick={handleBulkDelete}
                className="flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors font-medium min-w-[140px]"
              >
                <Trash2 className="w-4 h-4" />
                Excluir ({selectedItems.size})
              </button>
            </>
          )}
          
          <button 
            onClick={handleOpenFilterModal}
            className={`flex items-center justify-center gap-2 px-4 py-2 rounded-xl transition-colors font-medium relative ${
              activeFilterCount > 0 
                ? 'bg-blue-600 text-white hover:bg-blue-700' 
                : 'bg-indigo-600 text-white hover:bg-indigo-700'
            }`}
          >
            <Filter className="w-4 h-4" />
            Filtros
            {activeFilterCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
          </button>
          <button 
            onClick={handleExportPayroll}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-teal-600 text-white rounded-xl hover:bg-teal-700 transition-colors font-medium min-w-[100px]"
          >
            <Download className="w-4 h-4" />
            Exportar
          </button>
          <input
            type="file"
            accept=".csv,.xlsx,.xls"
            onChange={handleImportPayroll}
            className="hidden"
            id="import-payroll"
            disabled={importing}
          />
          <button
            onClick={downloadPayrollSample}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-amber-600 text-white rounded-xl hover:bg-amber-700 transition-colors font-medium min-w-[120px]"
            title="Baixar planilha de exemplo com dados de teste"
          >
            <Download className="w-4 h-4" />
            Baixar Modelo
          </button>
          <label
            htmlFor="import-payroll"
            className={`flex items-center justify-center gap-2 px-4 py-2 bg-violet-600 text-white rounded-xl hover:bg-violet-700 transition-colors cursor-pointer font-medium min-w-[100px] ${importing ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            <Upload className="w-4 h-4" />
            {importing ? 'Importando...' : 'Importar'}
          </label>
          <button 
            onClick={() => setShowModal(true)}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-600 to-cyan-600 text-white rounded-xl hover:shadow-lg transition-all font-medium"
          >
            <Plus className="w-4 h-4" />
            Novo Item da Folha
          </button>
        </div>
      </div>

      {/* Cards Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Selection Summary Card */}
        {selectedItems.size > 0 && (
          <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-6 text-white shadow-xl border-2 border-blue-400/30">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-blue-200 mb-2">Itens Selecionados</p>
                <p className="text-2xl font-bold text-white mb-1">
                  {selectedItems.size} {selectedItems.size === 1 ? 'item' : 'itens'}
                </p>
                <p className={`text-xl font-semibold ${
                  payrollItems
                    .filter(item => selectedItems.has(item.id))
                    .reduce((sum, item) => sum + item.amount, 0) < 0 
                    ? 'text-red-300' 
                    : 'text-emerald-300'
                }`}>
                  Valor Total: {formatCurrency(
                    payrollItems
                      .filter(item => selectedItems.has(item.id))
                      .reduce((sum, item) => sum + item.amount, 0)
                  )}
                </p>
              </div>
              <div className="p-4 bg-white/15 rounded-xl backdrop-blur-sm">
                <DollarSign className="w-8 h-8 text-blue-200" />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="text-sm text-blue-200">
                Selecionados de {filteredItems.length} itens
              </div>
              <button
                onClick={() => {
                  setSelectedItems(new Set());
                  setSelectAll(false);
                }}
                className="text-xs bg-white/20 hover:bg-white/30 px-3 py-1 rounded-lg transition-colors"
              >
                Limpar Seleção
              </button>
            </div>
          </div>
        )}

        {/* Summary Cards */}
        <div className={`${selectedItems.size === 0 ? 'lg:col-span-2' : ''}`}>
          {/* Total Amount */}
          <div className="bg-gradient-to-r from-emerald-600 to-teal-700 rounded-2xl p-6 text-white shadow-xl max-w-md">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-emerald-200 mb-2">Valor Total Folha de Pagamento</p>
                <p className="text-2xl font-bold text-white">
                  {formatCurrency(totalAmount)}
                </p>
              </div>
              <div className="p-3 bg-white/15 rounded-xl backdrop-blur-sm">
                <DollarSign className="w-6 h-6 text-emerald-200" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Payroll Table */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-200/50 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200/50">
          <h2 className="text-xl font-semibold text-slate-800">Lista da Folha de Pagamento</h2>
        </div>
        
        {filteredItems.length === 0 ? (
          /* Empty State */
          <div className="flex flex-col items-center justify-center py-16 px-6">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mb-4">
              <Users className="w-10 h-10 text-slate-400" />
            </div>
            <h3 className="text-lg font-semibold text-slate-800 mb-2">Nenhuma folha de pagamento</h3>
            <p className="text-slate-500 text-center mb-6 max-w-md">
              Comece adicionando seu primeiro item da folha de pagamento.
            </p>
            <button
              onClick={() => setShowModal(true)}
              className="flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 hover:shadow-lg transition-all font-medium"
            >
              <Plus className="w-4 h-4" />
              Criar Item da Folha
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full" onContextMenu={handleRightClick}>
              <thead className="bg-slate-50 border-b border-slate-200/50">
                <tr>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">
                    <input
                      type="checkbox"
                      checked={selectAll}
                      onChange={(e) => handleSelectAll(e.target.checked)}
                      className="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500"
                    />
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">
                    <button
                      onClick={() => handleSort('description')}
                      className="flex items-center gap-2 hover:bg-slate-100 px-2 py-1 rounded-lg transition-colors group"
                      title="Clique para ordenar por Colaborador"
                    >
                      <span>Colaborador</span>
                      <div className="flex flex-col">
                        <ChevronUp 
                          className={`w-3 h-3 transition-colors ${
                            sortField === 'description' && sortDirection === 'asc' 
                              ? 'text-emerald-600' 
                              : 'text-slate-400 group-hover:text-slate-600'
                          }`} 
                        />
                        <ChevronDown 
                          className={`w-3 h-3 -mt-1 transition-colors ${
                            sortField === 'description' && sortDirection === 'desc' 
                              ? 'text-emerald-600' 
                              : 'text-slate-400 group-hover:text-slate-600'
                          }`} 
                        />
                      </div>
                    </button>
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Categoria</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Centro de Custo</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-slate-700">Valor</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">Status</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/50">
                {paginatedItems.map((item) => {
                  const category = getCategoryById(item.category_id || 0);
                  const costCenter = getCostCenterById(item.cost_center_id || 0);
                  
                  return (
                    <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4 text-center">
                        <input
                          type="checkbox"
                          checked={selectedItems.has(item.id)}
                          onChange={(e) => handleSelectItem(item.id, e.target.checked)}
                          className="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-slate-800">
                          {item.description}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {category?.name || "-"}
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600">
                        {costCenter?.name || "-"}
                      </td>
                      <td className={`px-6 py-4 text-right font-semibold whitespace-nowrap ${
                        item.amount < 0 ? 'text-red-600' : 'text-emerald-600'
                      }`}>
                        {editingAmountId === item.id ? (
                          <div className="flex items-center justify-end gap-2">
                            <input
                              type="number"
                              step="0.01"
                              value={editingAmountValue}
                              onChange={(e) => setEditingAmountValue(e.target.value)}
                              className="w-32 px-3 py-2 text-sm border border-slate-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right"
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  handleSaveAmount(item.id);
                                } else if (e.key === 'Escape') {
                                  handleCancelEditAmount();
                                }
                              }}
                              autoFocus
                            />
                            <button
                              onClick={() => handleSaveAmount(item.id)}
                              className="text-emerald-600 hover:bg-emerald-50 p-1 rounded text-xs"
                              title="Salvar"
                            >
                              ✓
                            </button>
                            <button
                              onClick={handleCancelEditAmount}
                              className="text-red-600 hover:bg-red-50 p-1 rounded text-xs"
                              title="Cancelar"
                            >
                              ✕
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => handleStartEditAmount(item.id, item.amount)}
                            className="hover:bg-slate-100 px-2 py-1 rounded transition-colors cursor-pointer w-full text-right"
                            title="Clique para editar o valor"
                          >
                            {formatCurrency(item.amount)}
                          </button>
                        )}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <button
                          onClick={() => handleToggleStatus(item.id)}
                          className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium transition-all hover:scale-105 hover:shadow-md cursor-pointer ${
                            (item.status || 'NÃO PAGO') === 'PAGO' 
                              ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200' 
                              : 'bg-red-100 text-red-800 hover:bg-red-200'
                          }`}
                          title="Clique para alterar o status"
                        >
                          {item.status || 'NÃO PAGO'}
                        </button>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleEditItem(item)}
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="Editar item da folha de pagamento"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteItem(item.id)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Excluir item da folha de pagamento"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination - Always show when there are items */}
        {payrollItems.length > 0 && (
          <div className="px-6 py-4 border-t border-slate-200/50 bg-slate-50/50">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              {/* Items per page selector */}
              <div className="flex items-center gap-3">
                <span className="text-sm font-medium text-slate-700">Itens por página:</span>
                <select
                  value={itemsPerPage}
                  onChange={(e) => handleItemsPerPageChange(Number(e.target.value))}
                  className="px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 bg-white font-medium"
                >
                  <option value={10}>10</option>
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                  <option value={200}>200</option>
                </select>
              </div>

              {/* Page info */}
              <div className="flex items-center gap-4">
                <span className="text-sm text-slate-600 font-medium">
                  Mostrando <span className="text-emerald-600 font-semibold">{startIndex + 1}</span> a{' '}
                  <span className="text-emerald-600 font-semibold">{Math.min(endIndex, filteredItems.length)}</span> de{' '}
                  <span className="text-slate-800 font-semibold">{filteredItems.length}</span> registros
                  {activeFilterCount > 0 && (
                    <span className="text-blue-600"> (filtrados)</span>
                  )}
                </span>
              </div>

              {/* Page navigation */}
              <div className="flex items-center gap-2">
                {/* First page */}
                {currentPage > 2 && totalPages > 5 && (
                  <>
                    <button
                      onClick={() => goToPage(1)}
                      className="px-3 py-2 text-sm text-slate-600 hover:bg-slate-100 rounded-lg transition-colors border border-slate-300"
                    >
                      1
                    </button>
                    {currentPage > 3 && (
                      <span className="px-2 text-slate-400">...</span>
                    )}
                  </>
                )}

                {/* Previous button */}
                <button
                  onClick={() => goToPage(currentPage - 1)}
                  disabled={currentPage === 1}
                  className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed border border-slate-300 disabled:border-slate-200"
                  title="Página anterior"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>

                {/* Page numbers */}
                <div className="flex items-center gap-1">
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    let pageNumber;
                    if (totalPages <= 5) {
                      pageNumber = i + 1;
                    } else if (currentPage <= 3) {
                      pageNumber = i + 1;
                    } else if (currentPage >= totalPages - 2) {
                      pageNumber = totalPages - 4 + i;
                    } else {
                      pageNumber = currentPage - 2 + i;
                    }

                    if (pageNumber < 1 || pageNumber > totalPages) return null;

                    return (
                      <button
                        key={pageNumber}
                        onClick={() => goToPage(pageNumber)}
                        className={`px-3 py-2 text-sm rounded-lg transition-colors font-medium border ${
                          currentPage === pageNumber
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-md'
                            : 'text-slate-600 hover:bg-slate-100 border-slate-300'
                        }`}
                      >
                        {pageNumber}
                      </button>
                    );
                  })}
                </div>

                {/* Next button */}
                <button
                  onClick={() => goToPage(currentPage + 1)}
                  disabled={currentPage === totalPages}
                  className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed border border-slate-300 disabled:border-slate-200"
                  title="Próxima página"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>

                {/* Last page */}
                {currentPage < totalPages - 1 && totalPages > 5 && (
                  <>
                    {currentPage < totalPages - 2 && (
                      <span className="px-2 text-slate-400">...</span>
                    )}
                    <button
                      onClick={() => goToPage(totalPages)}
                      className="px-3 py-2 text-sm text-slate-600 hover:bg-slate-100 rounded-lg transition-colors border border-slate-300"
                    >
                      {totalPages}
                    </button>
                  </>
                )}

                {/* Direct page input for large datasets */}
                {totalPages > 10 && (
                  <div className="flex items-center gap-2 ml-3 pl-3 border-l border-slate-300">
                    <span className="text-sm text-slate-600">Ir para:</span>
                    <input
                      type="number"
                      min={1}
                      max={totalPages}
                      value={currentPage}
                      onChange={(e) => {
                        const page = Number(e.target.value);
                        if (page >= 1 && page <= totalPages) {
                          goToPage(page);
                        }
                      }}
                      className="w-20 px-2 py-1 border border-slate-300 rounded-lg text-sm text-center focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                      placeholder="Página"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Mobile-friendly pagination summary */}
            <div className="mt-3 md:hidden">
              <div className="text-center">
                <span className="text-sm text-slate-600">
                  Página <span className="font-semibold text-emerald-600">{currentPage}</span> de{' '}
                  <span className="font-semibold text-slate-800">{totalPages}</span>
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Enhanced Footer Information */}
      <div className="mt-8 py-6 border-t border-slate-200/50 bg-slate-50/30">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-sm text-slate-600">
            {activeFilterCount > 0 ? (
              <div className="flex items-center gap-2">
                <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                  {activeFilterCount} filtro{activeFilterCount > 1 ? 's' : ''} ativo{activeFilterCount > 1 ? 's' : ''}
                </span>
                <span>
                  Exibindo <span className="font-semibold text-blue-600">{filteredItems.length}</span> de{' '}
                  <span className="font-semibold text-slate-800">{payrollItems.length}</span> registros
                </span>
              </div>
            ) : (
              <span>
                Total de registros: <span className="font-semibold text-slate-800">{payrollItems.length}</span>
              </span>
            )}
          </div>
          
          {totalAmount !== 0 && (
            <div className="text-sm">
              <span className="text-slate-600">Valor total exibido: </span>
              <span className={`font-bold text-lg ${totalAmount < 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                {formatCurrency(totalAmount)}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Create Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-slate-200/50">
              <h3 className="text-xl font-semibold text-slate-800">Novo Item da Folha de Pagamento</h3>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Colaborador</label>
                <select
                  value={newItem.description}
                  onChange={(e) => setNewItem({...newItem, description: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                >
                  <option value="">Selecione um colaborador</option>
                  {payrollDescriptions.map((desc) => (
                    <option key={desc.id} value={desc.name}>
                      {desc.name}
                    </option>
                  ))}
                </select>
                {payrollDescriptions.length === 0 && (
                  <p className="text-xs text-slate-500 mt-1">
                    Nenhum colaborador disponível. Crie colaboradores em Configurações.
                  </p>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Categoria</label>
                <select
                  value={newItem.category_id}
                  onChange={(e) => setNewItem({...newItem, category_id: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                >
                  <option value="">Selecione uma categoria</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Centro de Custo</label>
                <select
                  value={newItem.cost_center_id}
                  onChange={(e) => setNewItem({...newItem, cost_center_id: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                >
                  <option value="">Selecione um centro de custo</option>
                  {costCenters.map((costCenter) => (
                    <option key={costCenter.id} value={costCenter.id}>
                      {costCenter.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Valor (Despesa)</label>
                <input
                  type="number"
                  step="0.01"
                  value={newItem.amount}
                  onChange={(e) => {
                    let value = e.target.value;
                    // Ensure value is negative for expenses
                    if (value && parseFloat(value) > 0) {
                      value = `-${value}`;
                    }
                    setNewItem({...newItem, amount: value});
                  }}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="-0.00"
                />
                <p className="text-xs text-slate-500 mt-1">Valor será automaticamente convertido para negativo (despesa)</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Status</label>
                <select
                  value={newItem.status}
                  onChange={(e) => setNewItem({...newItem, status: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                >
                  <option value="NÃO PAGO">NÃO PAGO</option>
                  <option value="PAGO">PAGO</option>
                </select>
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleCreateItem}
                className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-lg hover:shadow-lg transition-all"
              >
                Criar Item
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {showEditModal && editingItem && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-slate-200/50">
              <h3 className="text-xl font-semibold text-slate-800">Editar Item da Folha de Pagamento</h3>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Colaborador</label>
                <select
                  value={editItem.description}
                  onChange={(e) => setEditItem({...editItem, description: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Selecione um colaborador</option>
                  {payrollDescriptions.map((desc) => (
                    <option key={desc.id} value={desc.name}>
                      {desc.name}
                    </option>
                  ))}
                </select>
                {payrollDescriptions.length === 0 && (
                  <p className="text-xs text-slate-500 mt-1">
                    Nenhum colaborador disponível. Crie colaboradores em Configurações.
                  </p>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Categoria</label>
                <select
                  value={editItem.category_id}
                  onChange={(e) => setEditItem({...editItem, category_id: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Selecione uma categoria</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Centro de Custo</label>
                <select
                  value={editItem.cost_center_id}
                  onChange={(e) => setEditItem({...editItem, cost_center_id: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Selecione um centro de custo</option>
                  {costCenters.map((costCenter) => (
                    <option key={costCenter.id} value={costCenter.id}>
                      {costCenter.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Valor (Despesa)</label>
                <input
                  type="number"
                  step="0.01"
                  value={editItem.amount}
                  onChange={(e) => {
                    let value = e.target.value;
                    // Ensure value is negative for expenses
                    if (value && parseFloat(value) > 0) {
                      value = `-${value}`;
                    }
                    setEditItem({...editItem, amount: value});
                  }}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="-0.00"
                />
                <p className="text-xs text-slate-500 mt-1">Valor será automaticamente convertido para negativo (despesa)</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Status</label>
                <select
                  value={editItem.status}
                  onChange={(e) => setEditItem({...editItem, status: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="NÃO PAGO">NÃO PAGO</option>
                  <option value="PAGO">PAGO</option>
                </select>
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => {
                  setShowEditModal(false);
                  setEditingItem(null);
                }}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleUpdateItem}
                className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:shadow-lg transition-all"
              >
                Salvar Alterações
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Filter Modal */}
      {showFilterModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-6xl max-h-[95vh] overflow-y-auto">
            <div className="px-8 py-6 border-b border-slate-200/50">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-semibold text-slate-800">Filtrar Folha de Pagamento</h3>
                {activeFilterCount > 0 && (
                  <span className="bg-blue-100 text-blue-800 text-sm px-4 py-2 rounded-full font-medium">
                    {activeFilterCount} filtro{activeFilterCount > 1 ? 's' : ''} ativo{activeFilterCount > 1 ? 's' : ''}
                  </span>
                )}
              </div>
            </div>
            
            <div className="p-8 space-y-8">
              {/* Category, Cost Center and Collaborators */}
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                <div className="space-y-3">
                  <label className="block text-base font-semibold text-slate-700 mb-4">
                    Categorias ({filters.categoryIds.length} selecionada{filters.categoryIds.length !== 1 ? 's' : ''})
                  </label>
                  <div className="relative">
                    <div className="border-2 border-slate-200 rounded-xl p-4 min-h-[280px] max-h-80 overflow-y-auto bg-slate-50/30">
                      <div className="space-y-3">
                        <label className="flex items-center gap-3 cursor-pointer hover:bg-white/80 p-3 rounded-lg transition-colors">
                          <input
                            type="checkbox"
                            checked={filters.categoryIds.length === categories.length}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFilters({...filters, categoryIds: categories.map(c => c.id.toString())});
                              } else {
                                setFilters({...filters, categoryIds: []});
                              }
                            }}
                            className="w-5 h-5 text-blue-600 border-slate-300 rounded focus:ring-blue-500 focus:ring-2"
                          />
                          <span className="text-sm font-semibold text-slate-700">Todas as categorias</span>
                        </label>
                        <hr className="border-slate-300 my-3" />
                        {categories.map((category) => (
                          <label key={category.id} className="flex items-center gap-3 cursor-pointer hover:bg-white/80 p-3 rounded-lg transition-colors">
                            <input
                              type="checkbox"
                              checked={filters.categoryIds.includes(category.id.toString())}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setFilters({
                                    ...filters, 
                                    categoryIds: [...filters.categoryIds, category.id.toString()]
                                  });
                                } else {
                                  setFilters({
                                    ...filters, 
                                    categoryIds: filters.categoryIds.filter(id => id !== category.id.toString())
                                  });
                                }
                              }}
                              className="w-5 h-5 text-blue-600 border-slate-300 rounded focus:ring-blue-500 focus:ring-2"
                            />
                            <span className="text-sm text-slate-700 font-medium">{category.name}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="space-y-3">
                  <label className="block text-base font-semibold text-slate-700 mb-4">
                    Centros de Custo ({filters.costCenterIds.length} selecionado{filters.costCenterIds.length !== 1 ? 's' : ''})
                  </label>
                  <div className="relative">
                    <div className="border-2 border-slate-200 rounded-xl p-4 min-h-[280px] max-h-80 overflow-y-auto bg-slate-50/30">
                      <div className="space-y-3">
                        <label className="flex items-center gap-3 cursor-pointer hover:bg-white/80 p-3 rounded-lg transition-colors">
                          <input
                            type="checkbox"
                            checked={filters.costCenterIds.length === costCenters.length}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFilters({...filters, costCenterIds: costCenters.map(cc => cc.id.toString())});
                              } else {
                                setFilters({...filters, costCenterIds: []});
                              }
                            }}
                            className="w-5 h-5 text-blue-600 border-slate-300 rounded focus:ring-blue-500 focus:ring-2"
                          />
                          <span className="text-sm font-semibold text-slate-700">Todos os centros de custo</span>
                        </label>
                        <hr className="border-slate-300 my-3" />
                        {costCenters.map((costCenter) => (
                          <label key={costCenter.id} className="flex items-center gap-3 cursor-pointer hover:bg-white/80 p-3 rounded-lg transition-colors">
                            <input
                              type="checkbox"
                              checked={filters.costCenterIds.includes(costCenter.id.toString())}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setFilters({
                                    ...filters, 
                                    costCenterIds: [...filters.costCenterIds, costCenter.id.toString()]
                                  });
                                } else {
                                  setFilters({
                                    ...filters, 
                                    costCenterIds: filters.costCenterIds.filter(id => id !== costCenter.id.toString())
                                  });
                                }
                              }}
                              className="w-5 h-5 text-blue-600 border-slate-300 rounded focus:ring-blue-500 focus:ring-2"
                            />
                            <span className="text-sm text-slate-700 font-medium">{costCenter.name}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="space-y-3">
                  <label className="block text-base font-semibold text-slate-700 mb-4">
                    Colaboradores ({filters.collaboratorNames.length} selecionado{filters.collaboratorNames.length !== 1 ? 's' : ''})
                  </label>
                  <div className="relative">
                    <div className="border-2 border-slate-200 rounded-xl p-4 min-h-[280px] max-h-80 overflow-y-auto bg-slate-50/30">
                      <div className="space-y-3">
                        <label className="flex items-center gap-3 cursor-pointer hover:bg-white/80 p-3 rounded-lg transition-colors">
                          <input
                            type="checkbox"
                            checked={filters.collaboratorNames.length === uniqueCollaborators.length}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFilters({...filters, collaboratorNames: uniqueCollaborators});
                              } else {
                                setFilters({...filters, collaboratorNames: []});
                              }
                            }}
                            className="w-5 h-5 text-blue-600 border-slate-300 rounded focus:ring-blue-500 focus:ring-2"
                          />
                          <span className="text-sm font-semibold text-slate-700">Todos os colaboradores</span>
                        </label>
                        <hr className="border-slate-300 my-3" />
                        {uniqueCollaborators.map((collaborator) => (
                          <label key={collaborator} className="flex items-center gap-3 cursor-pointer hover:bg-white/80 p-3 rounded-lg transition-colors">
                            <input
                              type="checkbox"
                              checked={filters.collaboratorNames.includes(collaborator)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setFilters({
                                    ...filters, 
                                    collaboratorNames: [...filters.collaboratorNames, collaborator]
                                  });
                                } else {
                                  setFilters({
                                    ...filters, 
                                    collaboratorNames: filters.collaboratorNames.filter(name => name !== collaborator)
                                  });
                                }
                              }}
                              className="w-5 h-5 text-blue-600 border-slate-300 rounded focus:ring-blue-500 focus:ring-2"
                            />
                            <span className="text-sm text-slate-700 font-medium">{collaborator}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="space-y-3">
                  <label className="block text-base font-semibold text-slate-700 mb-4">
                    Tipos de Colaborador ({filters.collaboratorTypes.length} selecionado{filters.collaboratorTypes.length !== 1 ? 's' : ''})
                  </label>
                  <div className="relative">
                    <div className="border-2 border-slate-200 rounded-xl p-4 min-h-[280px] max-h-80 overflow-y-auto bg-slate-50/30">
                      <div className="space-y-3">
                        <label className="flex items-center gap-3 cursor-pointer hover:bg-white/80 p-3 rounded-lg transition-colors">
                          <input
                            type="checkbox"
                            checked={filters.collaboratorTypes.length === uniqueCollaboratorTypes.length}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFilters({...filters, collaboratorTypes: uniqueCollaboratorTypes});
                              } else {
                                setFilters({...filters, collaboratorTypes: []});
                              }
                            }}
                            className="w-5 h-5 text-blue-600 border-slate-300 rounded focus:ring-blue-500 focus:ring-2"
                          />
                          <span className="text-sm font-semibold text-slate-700">Todos os tipos</span>
                        </label>
                        <hr className="border-slate-300 my-3" />
                        {uniqueCollaboratorTypes.map((type) => (
                          <label key={type} className="flex items-center gap-3 cursor-pointer hover:bg-white/80 p-3 rounded-lg transition-colors">
                            <input
                              type="checkbox"
                              checked={filters.collaboratorTypes.includes(type!)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setFilters({
                                    ...filters, 
                                    collaboratorTypes: [...filters.collaboratorTypes, type!]
                                  });
                                } else {
                                  setFilters({
                                    ...filters, 
                                    collaboratorTypes: filters.collaboratorTypes.filter(t => t !== type)
                                  });
                                }
                              }}
                              className="w-5 h-5 text-blue-600 border-slate-300 rounded focus:ring-blue-500 focus:ring-2"
                            />
                            <span className="text-sm text-slate-700 font-medium">{type}</span>
                          </label>
                        ))}
                        {uniqueCollaboratorTypes.length === 0 && (
                          <div className="text-center py-8 text-slate-500">
                            <p className="text-sm">Nenhum tipo de colaborador encontrado</p>
                            <p className="text-xs mt-1">Configure os tipos nas descrições da folha de pagamento</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Status */}
              <div className="pt-4 border-t border-slate-200">
                <label className="block text-base font-semibold text-slate-700 mb-4">Status do Pagamento</label>
                <select
                  value={filters.status}
                  onChange={(e) => setFilters({...filters, status: e.target.value})}
                  className="w-full max-w-md px-4 py-3 border-2 border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base font-medium bg-white"
                >
                  <option value="">Todos os status</option>
                  <option value="PAGO">PAGO</option>
                  <option value="NÃO PAGO">NÃO PAGO</option>
                </select>
              </div>
            </div>
            
            <div className="px-8 py-6 border-t border-slate-200/50 bg-slate-50/50">
              <div className="flex items-center justify-between">
                <div className="flex gap-4">
                  <button
                    onClick={() => setShowFilterModal(false)}
                    className="px-6 py-3 text-slate-600 hover:bg-slate-100 rounded-xl transition-colors font-medium text-base"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={handleClearFilters}
                    className="px-6 py-3 text-red-600 hover:bg-red-50 rounded-xl transition-colors font-medium text-base border border-red-200"
                  >
                    Limpar Filtros
                  </button>
                </div>
                <button
                  onClick={handleApplyFilters}
                  className="px-8 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl hover:shadow-lg transition-all font-semibold text-base"
                >
                  Aplicar Filtros
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Clear All Payroll Modal */}
      {showClearModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-200/50 flex items-center gap-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold text-slate-800">Limpar Toda a Folha de Pagamento</h3>
            </div>
            
            <div className="p-6">
              <div className="mb-4">
                <p className="text-slate-700 mb-2">
                  <strong>Atenção:</strong> Esta ação irá remover permanentemente:
                </p>
                <ul className="list-disc list-inside text-sm text-slate-600 space-y-1 ml-4">
                  <li>Todos os itens da folha de pagamento</li>
                  <li>Histórico de salários e benefícios</li>
                  <li>Dados de custos trabalhistas</li>
                </ul>
              </div>
              
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
                <p className="text-red-800 text-sm font-medium">
                  ⚠️ Esta ação não pode ser desfeita!
                </p>
                <p className="text-red-700 text-sm">
                  Certifique-se de ter um backup dos seus dados se necessário.
                </p>
              </div>
              
              <p className="text-slate-600 text-sm">
                As categorias, centros de custo e colaboradores permanecerão inalterados.
              </p>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => setShowClearModal(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                disabled={clearing}
              >
                Cancelar
              </button>
              <button
                onClick={handleClearAllPayroll}
                disabled={clearing}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {clearing ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                    Limpando...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    Confirmar Limpeza
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reset Payments Modal */}
      {showResetPaymentsModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-200/50 flex items-center gap-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <RotateCcw className="w-5 h-5 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold text-slate-800">Zerar Pagamentos</h3>
            </div>
            
            <div className="p-6">
              <div className="mb-4">
                <p className="text-slate-700 mb-2">
                  <strong>Atenção:</strong> Esta ação irá alterar o status de:
                </p>
                <ul className="list-disc list-inside text-sm text-slate-600 space-y-1 ml-4">
                  <li>{filteredItems.filter(item => (item.status || 'NÃO PAGO') === 'PAGO').length} item(ns) com status "PAGO" para "NÃO PAGO"</li>
                  {activeFilterCount > 0 && (
                    <li>Apenas os itens que aparecem na lista atual (respeitando filtros)</li>
                  )}
                  {activeFilterCount === 0 && (
                    <li>Todos os itens pagos da folha de pagamento</li>
                  )}
                </ul>
              </div>

              {activeFilterCount > 0 && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
                  <p className="text-blue-800 text-sm font-medium">
                    🔍 Filtros ativos: {activeFilterCount}
                  </p>
                  <p className="text-blue-700 text-sm">
                    Apenas os itens visíveis na lista filtrada serão afetados.
                  </p>
                </div>
              )}
              
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 mb-4">
                <p className="text-orange-800 text-sm font-medium">
                  ⚠️ Esta ação pode ser revertida individualmente
                </p>
                <p className="text-orange-700 text-sm">
                  Você pode marcar os itens como "PAGO" novamente quando necessário.
                </p>
              </div>
              
              <p className="text-slate-600 text-sm">
                Os dados dos colaboradores, valores e outras informações permanecerão inalterados.
              </p>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => setShowResetPaymentsModal(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                disabled={resettingPayments}
              >
                Cancelar
              </button>
              <button
                onClick={handleResetFilteredPayments}
                disabled={resettingPayments}
                className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {resettingPayments ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                    Zerando...
                  </>
                ) : (
                  <>
                    <RotateCcw className="w-4 h-4" />
                    Confirmar Operação
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
