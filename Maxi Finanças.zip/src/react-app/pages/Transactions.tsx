import { useEffect, useState } from "react";
import { Plus, Trash2, DollarSign, Filter, Download, Upload, X, ChevronLeft, ChevronRight, Edit3, AlertTriangle } from "lucide-react";
import { TransactionWithDetails, Category, CostCenter } from "@/shared/types";
import { useAuth } from "@/react-app/contexts/AuthContext";
import * as XLSX from 'xlsx';

export default function Transactions() {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState<TransactionWithDetails[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<TransactionWithDetails | null>(null);
  const [newTransaction, setNewTransaction] = useState({
    date: new Date().toISOString().split('T')[0],
    description: '',
    amount: '',
    category_id: '',
    cost_center_id: '',
    is_recurring: false,
    status: 'NÃO PAGO'
  });
  const [editTransaction, setEditTransaction] = useState({
    date: '',
    description: '',
    amount: '',
    category_id: '',
    cost_center_id: '',
    is_recurring: false,
    status: 'NÃO PAGO'
  });

  // Amount editing states
  const [editingAmountId, setEditingAmountId] = useState<number | null>(null);
  const [editingAmountValue, setEditingAmountValue] = useState('');

  // Filter state
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [filters, setFilters] = useState({
    dateFrom: '',
    dateTo: '',
    categoryIds: [] as string[],
    costCenterIds: [] as string[],
    amountMin: '',
    amountMax: '',
    transactionType: '', // 'income', 'expense', ''
    description: ''
  });
  const [appliedFilters, setAppliedFilters] = useState({
    dateFrom: '',
    dateTo: '',
    categoryIds: [] as string[],
    costCenterIds: [] as string[],
    amountMin: '',
    amountMax: '',
    transactionType: '',
    description: ''
  });

  // Import state
  const [importing, setImporting] = useState(false);
  const [importResults, setImportResults] = useState<{
    success: boolean;
    message: string;
    imported: number;
    errors: string[];
  } | null>(null);

  // Selection state
  const [selectedTransactions, setSelectedTransactions] = useState<Set<number>>(new Set());
  const [selectAll, setSelectAll] = useState(false);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // Clear data state
  const [showClearModal, setShowClearModal] = useState(false);
  const [clearing, setClearing] = useState(false);
  
  // Create transaction state
  const [creating, setCreating] = useState(false);
  const [updateError, setUpdateError] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      console.log("🔄 Fetching transactions data...");
      
      // Add retry logic for better reliability
      const fetchWithRetry = async (url: string, retries = 2): Promise<Response> => {
        for (let i = 0; i <= retries; i++) {
          try {
            const response = await fetch(url, {
              credentials: 'include', // Ensure cookies are sent
              headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
              }
            });
            
            if (response.ok || i === retries) {
              return response;
            }
            
            console.log(`⚠️ API call failed (attempt ${i + 1}/${retries + 1}):`, url, response.status);
            
            // Wait before retry
            if (i < retries) {
              await new Promise(resolve => setTimeout(resolve, 500 * (i + 1)));
            }
          } catch (fetchError) {
            console.error(`❌ Fetch error (attempt ${i + 1}/${retries + 1}):`, fetchError);
            if (i === retries) {
              throw fetchError;
            }
            // Wait before retry
            await new Promise(resolve => setTimeout(resolve, 500 * (i + 1)));
          }
        }
        throw new Error('All retry attempts failed');
      };

      const headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${btoa(JSON.stringify(user))}`
      };

      const [transactionsRes, categoriesRes, costCentersRes] = await Promise.all([
        fetch("/api/transactions", { credentials: 'include', headers }),
        fetch("/api/categories", { credentials: 'include', headers }),
        fetch("/api/cost-centers", { credentials: 'include', headers })
      ]);

      console.log("📊 API responses:", {
        transactions: transactionsRes.status,
        categories: categoriesRes.status,
        costCenters: costCentersRes.status
      });

      // Process responses - don't fail if individual APIs fail
      let transactionsData = [];
      let categoriesData = [];
      let costCentersData = [];

      try {
        if (transactionsRes.ok) {
          transactionsData = await transactionsRes.json();
        } else {
          console.warn("⚠️ Transactions API failed:", transactionsRes.status);
        }
      } catch (error) {
        console.warn("⚠️ Error parsing transactions response:", error);
      }

      try {
        if (categoriesRes.ok) {
          categoriesData = await categoriesRes.json();
        } else {
          console.warn("⚠️ Categories API failed:", categoriesRes.status);
        }
      } catch (error) {
        console.warn("⚠️ Error parsing categories response:", error);
      }

      try {
        if (costCentersRes.ok) {
          costCentersData = await costCentersRes.json();
        } else {
          console.warn("⚠️ Cost Centers API failed:", costCentersRes.status);
        }
      } catch (error) {
        console.warn("⚠️ Error parsing cost centers response:", error);
      }

      console.log("📋 Data received:", {
        transactions: Array.isArray(transactionsData) ? transactionsData.length : 'not array',
        categories: Array.isArray(categoriesData) ? categoriesData.length : 'not array',
        costCenters: Array.isArray(costCentersData) ? costCentersData.length : 'not array'
      });

      // Ensure data is always an array
      setTransactions(Array.isArray(transactionsData) ? transactionsData : []);
      setCategories(Array.isArray(categoriesData) ? categoriesData : []);
      setCostCenters(Array.isArray(costCentersData) ? costCentersData : []);
      
    } catch (error) {
      console.error("❌ Error fetching data:", error);
      
      // Set empty arrays to prevent crashes
      setTransactions([]);
      setCategories([]);
      setCostCenters([]);
      
      // Only show error after multiple failures
      console.warn("⚠️ Transações carregando com dados básicos devido a problemas de conectividade");
      
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTransaction = async () => {
    // Clear previous errors
    setUpdateError('');
    
    console.log('🔄 FRONTEND: Starting transaction creation...');
    console.log('📋 FRONTEND: Current transaction data:', newTransaction);
    
    // Validation
    if (!newTransaction.description.trim()) {
      console.log('❌ FRONTEND: Missing description');
      setUpdateError('Descrição é obrigatória');
      return;
    }
    
    if (!newTransaction.amount || isNaN(parseFloat(newTransaction.amount))) {
      console.log('❌ FRONTEND: Invalid amount:', newTransaction.amount);
      setUpdateError('Valor é obrigatório e deve ser um número válido');
      return;
    }
    
    if (!newTransaction.date) {
      console.log('❌ FRONTEND: Missing date');
      setUpdateError('Data é obrigatória');
      return;
    }
    
    console.log('✅ FRONTEND: Validation passed');
    setCreating(true);
    
    try {
      console.log('🔄 FRONTEND: Creating transaction:', newTransaction);
      
      const transactionData = {
        ...newTransaction,
        amount: parseFloat(newTransaction.amount),
        category_id: newTransaction.category_id ? parseInt(newTransaction.category_id) : undefined,
        cost_center_id: newTransaction.cost_center_id ? parseInt(newTransaction.cost_center_id) : undefined,
      };
      
      console.log('📤 FRONTEND: Sending transaction data to API:', transactionData);
      
      const response = await fetch("/api/transactions", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Accept": "application/json",
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        },
        credentials: 'include',
        body: JSON.stringify(transactionData)
      });

      console.log('📨 FRONTEND: API response status:', response.status, response.ok);
      console.log('🌐 FRONTEND: Response headers:', Object.fromEntries(response.headers.entries()));

      const responseText = await response.text();
      console.log('📄 FRONTEND: Raw response:', responseText);

      let result;
      try {
        result = JSON.parse(responseText);
        console.log('📊 FRONTEND: Parsed response:', result);
      } catch (parseError) {
        console.error('❌ FRONTEND: Failed to parse response JSON:', parseError);
        setUpdateError(`Erro de resposta do servidor: ${responseText.substring(0, 100)}`);
        return;
      }

      if (response.ok) {
        console.log('✅ FRONTEND: Transaction created successfully:', result);
        
        // Close modal and reset form
        setShowModal(false);
        setNewTransaction({
          date: new Date().toISOString().split('T')[0],
          description: '',
          amount: '',
          category_id: '',
          cost_center_id: '',
          is_recurring: false,
          status: 'NÃO PAGO'
        });
        setUpdateError('');
        
        // Refresh data
        console.log('🔄 FRONTEND: Refreshing transaction list...');
        await fetchData();
        
        // Show success message
        setImportResults({
          success: true,
          message: 'Transação criada com sucesso!',
          imported: 1,
          errors: []
        });
      } else {
        console.error('❌ FRONTEND: API returned error:', result);
        setUpdateError(result.error || `Erro ${response.status}: Falha ao criar transação`);
      }
    } catch (error) {
      console.error("❌ FRONTEND: Error creating transaction:", error);
      setUpdateError(`Erro de conexão: ${error instanceof Error ? error.message : 'Erro desconhecido'}`);
    } finally {
      setCreating(false);
    }
  };

  const handleEditTransaction = (transaction: TransactionWithDetails) => {
    setEditingTransaction(transaction);
    setEditTransaction({
      date: transaction.date,
      description: transaction.description,
      amount: transaction.amount.toString(),
      category_id: transaction.category_id?.toString() || '',
      cost_center_id: transaction.cost_center_id?.toString() || '',
      is_recurring: Boolean(transaction.is_recurring),
      status: transaction.status || (transaction.amount > 0 ? 'NÃO RECEBIDO' : 'NÃO PAGO')
    });
    setShowEditModal(true);
  };

  const handleUpdateTransaction = async () => {
    if (!editingTransaction) return;

    try {
      const response = await fetch(`/api/transactions/${editingTransaction.id}`, {
        method: "PUT",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        },
        credentials: 'include',
        body: JSON.stringify({
          ...editTransaction,
          amount: parseFloat(editTransaction.amount),
          category_id: editTransaction.category_id ? parseInt(editTransaction.category_id) : undefined,
          cost_center_id: editTransaction.cost_center_id ? parseInt(editTransaction.cost_center_id) : undefined,
        })
      });

      if (response.ok) {
        setShowEditModal(false);
        setEditingTransaction(null);
        setEditTransaction({
          date: '',
          description: '',
          amount: '',
          category_id: '',
          cost_center_id: '',
          is_recurring: false,
          status: 'NÃO PAGO'
        });
        fetchData();
      }
    } catch (error) {
      console.error("Error updating transaction:", error);
    }
  };

  const handleToggleStatus = async (id: number) => {
    try {
      const response = await fetch(`/api/transactions/${id}/status`, {
        method: "PATCH",
        headers: {
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        },
        credentials: 'include'
      });

      if (response.ok) {
        fetchData();
      }
    } catch (error) {
      console.error("Error toggling transaction status:", error);
    }
  };

  const handleStartEditAmount = (id: number, currentAmount: number) => {
    setEditingAmountId(id);
    setEditingAmountValue(currentAmount.toString());
  };

  const handleCancelEditAmount = () => {
    setEditingAmountId(null);
    setEditingAmountValue('');
  };

  const handleSaveAmount = async (id: number) => {
    try {
      const amount = parseFloat(editingAmountValue);
      if (isNaN(amount)) {
        alert("Por favor, insira um valor numérico válido");
        return;
      }

      const response = await fetch(`/api/transactions/${id}/amount`, {
        method: "PATCH",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        },
        credentials: 'include',
        body: JSON.stringify({ amount })
      });

      if (response.ok) {
        setEditingAmountId(null);
        setEditingAmountValue('');
        fetchData();
      } else {
        alert("Erro ao atualizar o valor");
      }
    } catch (error) {
      console.error("Error updating transaction amount:", error);
      alert("Erro ao atualizar o valor");
    }
  };

  const handleDeleteTransaction = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir esta transação?")) return;

    try {
      const response = await fetch(`/api/transactions/${id}`, {
        method: "DELETE",
        headers: {
          "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
        },
        credentials: 'include'
      });

      if (response.ok) {
        fetchData();
      }
    } catch (error) {
      console.error("Error deleting transaction:", error);
    }
  };

  const handleSelectTransaction = (id: number, checked: boolean) => {
    const newSelected = new Set(selectedTransactions);
    if (checked) {
      newSelected.add(id);
    } else {
      newSelected.delete(id);
    }
    setSelectedTransactions(newSelected);
    
    // Update select all state
    setSelectAll(newSelected.size === paginatedTransactions.length && paginatedTransactions.length > 0);
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const allIds = new Set(paginatedTransactions.map(t => t.id));
      setSelectedTransactions(allIds);
    } else {
      setSelectedTransactions(new Set());
    }
    setSelectAll(checked);
  };

  const handleBulkDelete = async () => {
    if (selectedTransactions.size === 0) return;
    
    if (!confirm(`Tem certeza que deseja excluir ${selectedTransactions.size} transação(ões) selecionada(s)?`)) return;

    try {
      const deletePromises = Array.from(selectedTransactions).map(id =>
        fetch(`/api/transactions/${id}`, { 
          method: "DELETE",
          headers: {
            "Authorization": `Bearer ${btoa(JSON.stringify(user))}`
          },
          credentials: 'include'
        })
      );

      await Promise.all(deletePromises);
      
      setSelectedTransactions(new Set());
      setSelectAll(false);
      fetchData();
    } catch (error) {
      console.error("Error deleting transactions:", error);
    }
  };

  const formatCurrency = (amount: number) => {
    const formatted = new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(Math.abs(amount));
    
    return amount < 0 ? `-${formatted}` : formatted;
  };

  const formatDate = (dateString: string) => {
    if (!dateString || typeof dateString !== 'string') {
      return 'Data inválida';
    }
    
    try {
      // Remove any time component if present
      const dateOnly = dateString.split('T')[0];
      
      // Force parsing as ISO format YYYY-MM-DD from database
      if (dateOnly.match(/^\d{4}-\d{2}-\d{2}$/)) {
        const [year, month, day] = dateOnly.split('-');
        
        // Convert to numbers for validation
        const yearNum = parseInt(year, 10);
        const monthNum = parseInt(month, 10);
        const dayNum = parseInt(day, 10);
        
        // Basic validation
        if (yearNum >= 1900 && monthNum >= 1 && monthNum <= 12 && dayNum >= 1 && dayNum <= 31) {
          // Return in Brazilian format DD/MM/YYYY
          return `${day}/${month}/${year}`;
        }
      }
      
      return dateString; // Return original if parsing fails
    } catch (error) {
      return dateString;
    }
  };

  const getCategoryById = (id: number) => categories.find(c => c.id === id);
  const getCostCenterById = (id: number) => costCenters.find(cc => cc.id === id);

  // Apply filters to transactions
  const filteredTransactions = transactions.filter(transaction => {
    // Date filter
    if (appliedFilters.dateFrom && transaction.date < appliedFilters.dateFrom) {
      return false;
    }
    if (appliedFilters.dateTo && transaction.date > appliedFilters.dateTo) {
      return false;
    }

    // Category filter - multiple categories
    if (appliedFilters.categoryIds.length > 0) {
      const categoryIdNumbers = appliedFilters.categoryIds.map(id => parseInt(id));
      if (!transaction.category_id || !categoryIdNumbers.includes(transaction.category_id)) {
        return false;
      }
    }

    // Cost center filter - multiple cost centers
    if (appliedFilters.costCenterIds.length > 0) {
      const costCenterIdNumbers = appliedFilters.costCenterIds.map(id => parseInt(id));
      if (!transaction.cost_center_id || !costCenterIdNumbers.includes(transaction.cost_center_id)) {
        return false;
      }
    }

    // Amount range filter
    if (appliedFilters.amountMin && Math.abs(transaction.amount) < parseFloat(appliedFilters.amountMin)) {
      return false;
    }
    if (appliedFilters.amountMax && Math.abs(transaction.amount) > parseFloat(appliedFilters.amountMax)) {
      return false;
    }

    // Transaction type filter
    if (appliedFilters.transactionType === 'income' && transaction.amount <= 0) {
      return false;
    }
    if (appliedFilters.transactionType === 'expense' && transaction.amount >= 0) {
      return false;
    }

    // Description filter
    if (appliedFilters.description && !transaction.description.toLowerCase().includes(appliedFilters.description.toLowerCase())) {
      return false;
    }

    return true;
  });

  const balance = filteredTransactions
    .filter(t => t.status === 'PAGO' || t.status === 'RECEBIDO')
    .reduce((sum, t) => sum + t.amount, 0);

  // Pagination calculations
  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedTransactions = filteredTransactions.slice(startIndex, endIndex);

  // Reset to first page when items per page changes
  const handleItemsPerPageChange = (newItemsPerPage: number) => {
    setItemsPerPage(newItemsPerPage);
    setCurrentPage(1);
    // Clear selections when changing pagination
    setSelectedTransactions(new Set());
    setSelectAll(false);
  };

  // Navigate to specific page
  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
      // Clear selections when changing page
      setSelectedTransactions(new Set());
      setSelectAll(false);
    }
  };

  // Handle right click to clear all selections
  const handleRightClick = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent browser context menu
    if (selectedTransactions.size > 0) {
      setSelectedTransactions(new Set());
      setSelectAll(false);
    }
  };

  // Filter functions
  const handleApplyFilters = () => {
    setAppliedFilters(filters);
    setCurrentPage(1); // Reset to first page
    setSelectedTransactions(new Set()); // Clear selections
    setSelectAll(false);
    setShowFilterModal(false);
  };

  const handleClearFilters = () => {
    const emptyFilters = {
      dateFrom: '',
      dateTo: '',
      categoryIds: [] as string[],
      costCenterIds: [] as string[],
      amountMin: '',
      amountMax: '',
      transactionType: '',
      description: ''
    };
    setFilters(emptyFilters);
    setAppliedFilters(emptyFilters);
    setCurrentPage(1);
    setSelectedTransactions(new Set());
    setSelectAll(false);
    setShowFilterModal(false);
  };

  const handleOpenFilterModal = () => {
    setFilters(appliedFilters); // Initialize modal with current applied filters
    setShowFilterModal(true);
  };

  // Count active filters
  const activeFilterCount = Object.entries(appliedFilters).filter(([key, value]) => {
    if (key === 'categoryIds' || key === 'costCenterIds') {
      return Array.isArray(value) && value.length > 0;
    }
    return value !== '';
  }).length;

  // Import functions
  const handleImportTransactions = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImporting(true);
    setImportResults(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('/api/transactions/import', {
        method: 'POST',
        credentials: 'include',
        body: formData
      });

      const result = await response.json();
      setImportResults(result);
      
      if (result.success) {
        fetchData();
      }
    } catch (error) {
      setImportResults({
        success: false,
        message: 'Erro ao importar transações',
        imported: 0,
        errors: ['Erro de conexão com o servidor']
      });
    } finally {
      setImporting(false);
      // Reset file input
      event.target.value = '';
    }
  };

  // Clear all transactions
  const handleClearAllTransactions = async () => {
    setClearing(true);
    
    try {
      const response = await fetch('/api/clear-transactions', {
        method: 'POST',
        credentials: 'include'
      });
      
      const result = await response.json();
      
      if (result.success) {
        setImportResults({
          success: true,
          message: result.message,
          imported: 0,
          errors: []
        });
        fetchData(); // Refresh the data
      } else {
        setImportResults({
          success: false,
          message: 'Erro ao limpar transações',
          imported: 0,
          errors: [result.error || 'Erro desconhecido']
        });
      }
    } catch (error) {
      setImportResults({
        success: false,
        message: 'Erro ao conectar com o servidor',
        imported: 0,
        errors: ['Erro de conexão']
      });
    } finally {
      setClearing(false);
      setShowClearModal(false);
    }
  };

  const downloadTransactionSample = () => {
    // Criar dados de exemplo IDÊNTICOS à imagem enviada pelo usuário
    const sampleData = [
      // Receitas
      { data: new Date(2025, 0, 29), descricao: 'Salário Janeiro', valor: 5000, categoria: 'Renda', centro_custo: 'Pessoal', status: 'RECEBIDO' },
      { data: new Date(2025, 1, 12), descricao: 'Freelance Design', valor: 800, categoria: 'Renda', centro_custo: 'Trabalho', status: 'RECEBIDO' },
      { data: new Date(2025, 1, 25), descricao: 'Venda Produto', valor: 350, categoria: 'Renda', centro_custo: 'Negócio', status: 'RECEBIDO' },
      
      // Despesas - Moradia
      { data: new Date(2025, 0, 3), descricao: 'Conta de Luz', valor: -180.5, categoria: 'Moradia', centro_custo: 'Casa', status: 'PAGO' },
      { data: new Date(2025, 0, 5), descricao: 'Conta de Água', valor: -95.3, categoria: 'Moradia', centro_custo: 'Casa', status: 'PAGO' },
      { data: new Date(2025, 1, 8), descricao: 'Internet Fibra', valor: -120, categoria: 'Moradia', centro_custo: 'Casa', status: 'PAGO' },
      { data: new Date(2025, 1, 10), descricao: 'Gás de Cozinha', valor: -85, categoria: 'Moradia', centro_custo: 'Casa', status: 'PAGO' },
      
      // Despesas - Alimentação
      { data: new Date(2025, 0, 1), descricao: 'Supermercado Extra', valor: -280.75, categoria: 'Alimentacao', centro_custo: 'Casa', status: 'PAGO' },
      { data: new Date(2025, 0, 6), descricao: 'Padaria São João', valor: -25.5, categoria: 'Alimentacao', centro_custo: 'Casa', status: 'PAGO' },
      { data: new Date(2025, 1, 12), descricao: 'Restaurante Japonês', valor: -120, categoria: 'Alimentacao', centro_custo: 'Pessoal', status: 'PAGO' },
      { data: new Date(2025, 1, 16), descricao: 'Lanchonete', valor: -18.9, categoria: 'Alimentacao', centro_custo: 'Pessoal', status: 'PAGO' },
      { data: new Date(2025, 1, 20), descricao: 'Açougue Central', valor: -65, categoria: 'Alimentacao', centro_custo: 'Casa', status: 'PAGO' },
      
      // Despesas - Transporte
      { data: new Date(2024, 11, 31), descricao: 'Combustível Posto Shell', valor: -150, categoria: 'Transporte', centro_custo: 'Carro', status: 'PAGO' },
      { data: new Date(2025, 1, 7), descricao: 'Uber Centro', valor: -23.5, categoria: 'Transporte', centro_custo: 'Pessoal', status: 'PAGO' },
      { data: new Date(2025, 1, 14), descricao: '99 Aeroporto', valor: -45.8, categoria: 'Transporte', centro_custo: 'Pessoal', status: 'PAGO' },
      
      // Despesas - Saúde
      { data: new Date(2025, 0, 9), descricao: 'Consulta Médica', valor: -200, categoria: 'Saude', centro_custo: 'Pessoal', status: 'PAGO' },
      { data: new Date(2025, 1, 11), descricao: 'Farmácia Remédios', valor: -85.6, categoria: 'Saude', centro_custo: 'Pessoal', status: 'PAGO' },
      
      // Despesas - Lazer
      { data: new Date(2025, 0, 4), descricao: 'Cinema Shopping', valor: -45, categoria: 'Lazer', centro_custo: 'Pessoal', status: 'PAGO' },
      { data: new Date(2025, 1, 15), descricao: 'Academia Mensal', valor: -89.9, categoria: 'Lazer', centro_custo: 'Pessoal', status: 'PAGO' },
      { data: new Date(2025, 1, 19), descricao: 'Livros Amazon', valor: -67.5, categoria: 'Lazer', centro_custo: 'Pessoal', status: 'PAGO' },
      
      // Despesas - Educação
      { data: new Date(2025, 0, 2), descricao: 'Curso Online', valor: -199, categoria: 'Educacao', centro_custo: 'Trabalho', status: 'PAGO' },
      
      // Março
      { data: new Date(2025, 2, 2), descricao: 'Supermercado Março', valor: -320.45, categoria: 'Alimentacao', centro_custo: 'Casa', status: 'PAGO' },
      { data: new Date(2025, 2, 9), descricao: 'Salário Março', valor: 5000, categoria: 'Renda', centro_custo: 'Pessoal', status: 'RECEBIDO' },
      { data: new Date(2025, 2, 17), descricao: 'Comissão Vendas', valor: 1200, categoria: 'Renda', centro_custo: 'Comercial', status: 'RECEBIDO' }
    ];

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(sampleData);

    // Auto-size columns
    const colWidths = [
      { wch: 12 }, // data
      { wch: 25 }, // descricao  
      { wch: 12 }, // valor
      { wch: 15 }, // categoria
      { wch: 15 }, // centro_custo
      { wch: 12 }  // status
    ];
    ws['!cols'] = colWidths;

    // Configure date format for data column (column A) - use dd/mm/yyyy format for Brazilian compatibility
    const range = XLSX.utils.decode_range(ws['!ref'] || 'A1');
    for (let rowNum = range.s.r + 1; rowNum <= range.e.r; rowNum++) {
      const cellAddress = XLSX.utils.encode_cell({ r: rowNum, c: 0 }); // Column A (data)
      if (ws[cellAddress] && ws[cellAddress].t === 'd') {
        // Use Brazilian date format: dd/mm/yyyy
        ws[cellAddress].z = 'dd/mm/yyyy'; // Brazilian format: 31/01/2025
        ws[cellAddress].t = 'd'; // Ensure it's treated as date
      }
    }

    // Add the worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Exemplo_Transacoes');

    // Generate Excel file and download
    XLSX.writeFile(wb, 'exemplo_importacao_transacoes.xlsx');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-slate-600">Carregando transações...</p>
        </div>
      </div>
    );
  }

  // Error boundary - if something goes wrong, show a friendly message
  if (!Array.isArray(transactions)) {
    return (
      <div className="p-8">
        <div className="bg-red-50 border border-red-200 rounded-xl p-6 text-center">
          <h2 className="text-xl font-semibold text-red-800 mb-2">Erro ao Carregar Transações</h2>
          <p className="text-red-600 mb-4">Houve um problema ao carregar os dados. Tente atualizar a página.</p>
          <button 
            onClick={() => window.location.reload()} 
            className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
          >
            Atualizar Página
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      {/* Import Results */}
      {importResults && (
        <div className={`mb-6 p-4 rounded-xl border ${
          importResults.success 
            ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
            : 'bg-red-50 border-red-200 text-red-800'
        }`}>
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">{importResults.message}</h3>
              {importResults.success && (
                <p className="text-sm mt-1">
                  {importResults.imported} transação(ões) importada(s) com sucesso
                </p>
              )}
            </div>
            <button
              onClick={() => setImportResults(null)}
              className="text-current hover:opacity-70"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          {importResults.errors && importResults.errors.length > 0 && (
            <div className="mt-3">
              <p className="text-sm font-medium">Erros encontrados:</p>
              <ul className="text-sm mt-1 list-disc list-inside">
                {importResults.errors.map((error, index) => (
                  <li key={index}>{error}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Transações</h1>
          <p className="text-slate-600">Gerencie suas movimentações financeiras</p>
        </div>
        
        {/* Clear All Transactions Button */}
        <button
          onClick={() => setShowClearModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 hover:shadow-lg transition-all duration-200 font-medium"
          title="Limpar todas as transações"
        >
          <AlertTriangle className="w-4 h-4" />
          Limpar Tudo
        </button>
      </div>

      <div className="flex items-center justify-between mb-8">
        <div className="invisible">
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Transações</h1>
          <p className="text-slate-600">Gerencie suas movimentações financeiras</p>
        </div>
        <div className="flex gap-3">
          {selectedTransactions.size > 0 && (
            <button
              onClick={handleBulkDelete}
              className="flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors font-medium min-w-[140px]"
            >
              <Trash2 className="w-4 h-4" />
              Excluir ({selectedTransactions.size})
            </button>
          )}
          <button 
            onClick={handleOpenFilterModal}
            className={`flex items-center justify-center gap-2 px-4 py-2 rounded-xl transition-colors font-medium relative ${
              activeFilterCount > 0 
                ? 'bg-blue-600 text-white hover:bg-blue-700' 
                : 'bg-indigo-600 text-white hover:bg-indigo-700'
            }`}
          >
            <Filter className="w-4 h-4" />
            Filtros
            {activeFilterCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
          </button>
          <button className="flex items-center justify-center gap-2 px-4 py-2 bg-teal-600 text-white rounded-xl hover:bg-teal-700 transition-colors font-medium w-24">
            <Download className="w-4 h-4" />
            Exportar
          </button>
          <input
            type="file"
            accept=".csv,.xlsx,.xls"
            onChange={handleImportTransactions}
            className="hidden"
            id="import-transactions"
            disabled={importing}
          />
          <button
            onClick={downloadTransactionSample}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-amber-600 text-white rounded-xl hover:bg-amber-700 transition-colors font-medium min-w-[120px]"
            title="Baixar planilha de exemplo com dados de teste"
          >
            <Download className="w-4 h-4" />
            Baixar Modelo
          </button>
          <label
            htmlFor="import-transactions"
            className={`flex items-center justify-center gap-2 px-4 py-2 bg-violet-600 text-white rounded-xl hover:bg-violet-700 transition-colors cursor-pointer font-medium w-24 ${importing ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            <Upload className="w-4 h-4" />
            {importing ? 'Importando...' : 'Importar'}
          </label>
          <button 
            onClick={() => {
              setShowModal(true);
              setUpdateError(''); // Clear any previous errors
            }}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-600 to-cyan-600 text-white rounded-xl hover:shadow-lg transition-all font-medium w-24"
          >
            <Plus className="w-4 h-4" />
            Nova
          </button>
        </div>
      </div>

      {/* Cards Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Selection Summary Card */}
        {selectedTransactions.size > 0 && (
          <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-6 text-white shadow-xl border-2 border-blue-400/30">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-blue-200 mb-2">Transações Selecionadas</p>
                <p className="text-2xl font-bold text-white mb-1">
                  {selectedTransactions.size} {selectedTransactions.size === 1 ? 'transação' : 'transações'}
                </p>
                <p className={`text-xl font-semibold ${
                  transactions
                    .filter(t => selectedTransactions.has(t.id))
                    .reduce((sum, t) => sum + t.amount, 0) < 0 
                    ? 'text-red-300' 
                    : 'text-emerald-300'
                }`}>
                  Soma: {formatCurrency(
                    transactions
                      .filter(t => selectedTransactions.has(t.id))
                      .reduce((sum, t) => sum + t.amount, 0)
                  )}
                </p>
              </div>
              <div className="p-4 bg-white/15 rounded-xl backdrop-blur-sm">
                <DollarSign className="w-8 h-8 text-blue-200" />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="text-sm text-blue-200">
                Receitas: {transactions.filter(t => selectedTransactions.has(t.id) && t.amount > 0).length} | 
                Despesas: {transactions.filter(t => selectedTransactions.has(t.id) && t.amount < 0).length}
              </div>
              <button
                onClick={() => {
                  setSelectedTransactions(new Set());
                  setSelectAll(false);
                }}
                className="text-xs bg-white/20 hover:bg-white/30 px-3 py-1 rounded-lg transition-colors"
              >
                Limpar Seleção
              </button>
            </div>
          </div>
        )}

        {/* Balance Card */}
        <div className={`bg-gradient-to-r from-slate-800 to-slate-900 rounded-2xl p-6 text-white shadow-xl ${selectedTransactions.size === 0 ? 'lg:col-span-2' : ''}`}>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-300 mb-2">Saldo Banco</p>
              <p className={`text-3xl font-bold ${balance < 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                {formatCurrency(balance)}
              </p>
            </div>
            <div className="p-4 bg-white/10 rounded-xl backdrop-blur-sm">
              <DollarSign className="w-8 h-8 text-emerald-400" />
            </div>
          </div>
          <div className="mt-4 text-sm text-slate-300">
            {transactions.length} transações encontradas
          </div>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-white rounded-2xl shadow-lg border border-slate-200/50 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200/50">
          <h2 className="text-xl font-semibold text-slate-800">Lista de Transações</h2>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full" onContextMenu={handleRightClick}>
            <thead className="bg-slate-50 border-b border-slate-200/50">
              <tr>
                <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">
                  <input
                    type="checkbox"
                    checked={selectAll}
                    onChange={(e) => handleSelectAll(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500"
                  />
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Data</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Descrição</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Categoria</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">Centro de Custo</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-slate-700">Valor</th>
                <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">Status</th>
                <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/50">
              {paginatedTransactions.map((transaction) => {
                const category = getCategoryById(transaction.category_id || 0);
                const costCenter = getCostCenterById(transaction.cost_center_id || 0);
                
                return (
                  <tr key={transaction.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4 text-center">
                      <input
                        type="checkbox"
                        checked={selectedTransactions.has(transaction.id)}
                        onChange={(e) => handleSelectTransaction(transaction.id, e.target.checked)}
                        className="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500"
                      />
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">
                      {formatDate(transaction.date)}
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-medium text-slate-800">
                        {transaction.description}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">
                      {category?.name || "-"}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">
                      {costCenter?.name || "-"}
                    </td>
                    <td className={`px-6 py-4 text-right font-semibold whitespace-nowrap ${
                      transaction.amount < 0 ? 'text-red-600' : 'text-emerald-600'
                    }`}>
                      {editingAmountId === transaction.id ? (
                        <div className="flex items-center justify-end gap-2">
                          <input
                            type="number"
                            step="0.01"
                            value={editingAmountValue}
                            onChange={(e) => setEditingAmountValue(e.target.value)}
                            className="w-32 px-3 py-2 text-sm border border-slate-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-right"
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                handleSaveAmount(transaction.id);
                              } else if (e.key === 'Escape') {
                                handleCancelEditAmount();
                              }
                            }}
                            autoFocus
                          />
                          <button
                            onClick={() => handleSaveAmount(transaction.id)}
                            className="text-emerald-600 hover:bg-emerald-50 p-1 rounded text-xs"
                            title="Salvar"
                          >
                            ✓
                          </button>
                          <button
                            onClick={handleCancelEditAmount}
                            className="text-red-600 hover:bg-red-50 p-1 rounded text-xs"
                            title="Cancelar"
                          >
                            ✕
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => handleStartEditAmount(transaction.id, transaction.amount)}
                          className="hover:bg-slate-100 px-2 py-1 rounded transition-colors cursor-pointer w-full text-right"
                          title="Clique para editar o valor"
                        >
                          {formatCurrency(transaction.amount)}
                        </button>
                      )}
                    </td>
                    <td className="px-6 py-4 text-center">
                      <button
                        onClick={() => handleToggleStatus(transaction.id)}
                        className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium transition-all hover:scale-105 hover:shadow-md cursor-pointer ${
                          (transaction.status === 'PAGO' || transaction.status === 'RECEBIDO')
                            ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200' 
                            : 'bg-red-100 text-red-800 hover:bg-red-200'
                        }`}
                        title="Clique para alterar o status"
                      >
                        {transaction.status || (transaction.amount > 0 ? 'NÃO RECEBIDO' : 'NÃO PAGO')}
                      </button>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => handleEditTransaction(transaction)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Editar transação"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteTransaction(transaction.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Excluir transação"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {filteredTransactions.length > 0 && (
          <div className="px-6 py-4 border-t border-slate-200/50 bg-slate-50/50">
            <div className="flex items-center justify-between">
              {/* Items per page selector */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-slate-600">Itens por página:</span>
                <select
                  value={itemsPerPage}
                  onChange={(e) => handleItemsPerPageChange(Number(e.target.value))}
                  className="px-3 py-1 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                >
                  <option value={5}>5</option>
                  <option value={10}>10</option>
                  <option value={20}>20</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>

              {/* Page info and navigation */}
              <div className="flex items-center gap-4">
                <span className="text-sm text-slate-600">
                  Mostrando {startIndex + 1} a {Math.min(endIndex, filteredTransactions.length)} de {filteredTransactions.length} registros
                </span>
                
                <div className="flex items-center gap-2">
                  {/* Previous button */}
                  <button
                    onClick={() => goToPage(currentPage - 1)}
                    disabled={currentPage === 1}
                    className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    title="Página anterior"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>

                  {/* Page number selector */}
                  <div className="flex items-center gap-1">
                    {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                      let pageNumber;
                      if (totalPages <= 5) {
                        pageNumber = i + 1;
                      } else if (currentPage <= 3) {
                        pageNumber = i + 1;
                      } else if (currentPage >= totalPages - 2) {
                        pageNumber = totalPages - 4 + i;
                      } else {
                        pageNumber = currentPage - 2 + i;
                      }

                      return (
                        <button
                          key={pageNumber}
                          onClick={() => goToPage(pageNumber)}
                          className={`px-3 py-1 text-sm rounded-lg transition-colors ${
                            currentPage === pageNumber
                              ? 'bg-emerald-600 text-white'
                              : 'text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          {pageNumber}
                        </button>
                      );
                    })}
                  </div>

                  {/* Next button */}
                  <button
                    onClick={() => goToPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                    className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    title="Próxima página"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Direct page input */}
                {totalPages > 5 && (
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-600">Ir para:</span>
                    <input
                      type="number"
                      min={1}
                      max={totalPages}
                      value={currentPage}
                      onChange={(e) => {
                        const page = Number(e.target.value);
                        if (page >= 1 && page <= totalPages) {
                          goToPage(page);
                        }
                      }}
                      className="w-16 px-2 py-1 border border-slate-300 rounded-lg text-sm text-center focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer Information */}
      <div className="mt-8 py-4 border-t border-slate-200/50">
        <div className="text-center text-sm text-slate-600">
          {activeFilterCount > 0 ? (
            <>
              Registros filtrados: <span className="font-semibold">{filteredTransactions.length}</span> de {transactions.length}
              {filteredTransactions.length > 0 && (
                <span className="ml-4">
                  Mostrando {Math.min(startIndex + 1, filteredTransactions.length)} a {Math.min(endIndex, filteredTransactions.length)} de {filteredTransactions.length} registros filtrados
                </span>
              )}
            </>
          ) : (
            <>
              Total de registros: <span className="font-semibold">{transactions.length}</span>
              {transactions.length > 0 && (
                <span className="ml-4">
                  Mostrando {Math.min(startIndex + 1, filteredTransactions.length)} a {Math.min(endIndex, filteredTransactions.length)} de {filteredTransactions.length} registros
                </span>
              )}
            </>
          )}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-200/50">
              <h3 className="text-xl font-semibold text-slate-800">Nova Transação</h3>
            </div>
            
            <div className="p-6 space-y-4">
              {/* Error Message */}
              {updateError && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                  <p className="text-red-700 text-sm font-medium">{updateError}</p>
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Data</label>
                <input
                  type="date"
                  value={newTransaction.date}
                  onChange={(e) => setNewTransaction({...newTransaction, date: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  disabled={creating}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Descrição</label>
                <input
                  type="text"
                  value={newTransaction.description}
                  onChange={(e) => setNewTransaction({...newTransaction, description: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="Descrição da transação"
                  disabled={creating}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Valor</label>
                <input
                  type="number"
                  step="0.01"
                  value={newTransaction.amount}
                  onChange={(e) => {
                    const amount = parseFloat(e.target.value);
                    const newStatus = amount > 0 ? 'NÃO RECEBIDO' : 'NÃO PAGO';
                    setNewTransaction({
                      ...newTransaction, 
                      amount: e.target.value,
                      status: newStatus
                    });
                  }}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="0.00"
                  disabled={creating}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Categoria</label>
                <select
                  value={newTransaction.category_id}
                  onChange={(e) => setNewTransaction({...newTransaction, category_id: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  disabled={creating}
                >
                  <option value="">Selecione uma categoria</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Centro de Custo</label>
                <select
                  value={newTransaction.cost_center_id}
                  onChange={(e) => setNewTransaction({...newTransaction, cost_center_id: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  disabled={creating}
                >
                  <option value="">Selecione um centro de custo</option>
                  {costCenters.map((costCenter) => (
                    <option key={costCenter.id} value={costCenter.id}>
                      {costCenter.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Status</label>
                <select
                  value={newTransaction.status}
                  onChange={(e) => setNewTransaction({...newTransaction, status: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  disabled={creating}
                >
                  {parseFloat(newTransaction.amount) > 0 ? (
                    <>
                      <option value="NÃO RECEBIDO">NÃO RECEBIDO</option>
                      <option value="RECEBIDO">RECEBIDO</option>
                    </>
                  ) : (
                    <>
                      <option value="NÃO PAGO">NÃO PAGO</option>
                      <option value="PAGO">PAGO</option>
                    </>
                  )}
                </select>
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => {
                  if (!creating) {
                    setShowModal(false);
                    setUpdateError('');
                  }
                }}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={creating}
              >
                Cancelar
              </button>
              <button
                onClick={handleCreateTransaction}
                disabled={creating}
                className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-lg hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 min-w-[140px] justify-center"
              >
                {creating ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                    Criando...
                  </>
                ) : (
                  'Criar Transação'
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {showEditModal && editingTransaction && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-200/50">
              <h3 className="text-xl font-semibold text-slate-800">Editar Transação</h3>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Data</label>
                <input
                  type="date"
                  value={editTransaction.date}
                  onChange={(e) => setEditTransaction({...editTransaction, date: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Descrição</label>
                <input
                  type="text"
                  value={editTransaction.description}
                  onChange={(e) => setEditTransaction({...editTransaction, description: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Descrição da transação"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Valor</label>
                <input
                  type="number"
                  step="0.01"
                  value={editTransaction.amount}
                  onChange={(e) => {
                    const amount = parseFloat(e.target.value);
                    const newStatus = amount > 0 ? 'NÃO RECEBIDO' : 'NÃO PAGO';
                    setEditTransaction({
                      ...editTransaction, 
                      amount: e.target.value,
                      status: newStatus
                    });
                  }}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="0.00"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Categoria</label>
                <select
                  value={editTransaction.category_id}
                  onChange={(e) => setEditTransaction({...editTransaction, category_id: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Selecione uma categoria</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Centro de Custo</label>
                <select
                  value={editTransaction.cost_center_id}
                  onChange={(e) => setEditTransaction({...editTransaction, cost_center_id: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Selecione um centro de custo</option>
                  {costCenters.map((costCenter) => (
                    <option key={costCenter.id} value={costCenter.id}>
                      {costCenter.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Status</label>
                <select
                  value={editTransaction.status}
                  onChange={(e) => setEditTransaction({...editTransaction, status: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  {parseFloat(editTransaction.amount) > 0 ? (
                    <>
                      <option value="NÃO RECEBIDO">NÃO RECEBIDO</option>
                      <option value="RECEBIDO">RECEBIDO</option>
                    </>
                  ) : (
                    <>
                      <option value="NÃO PAGO">NÃO PAGO</option>
                      <option value="PAGO">PAGO</option>
                    </>
                  )}
                </select>
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => {
                  setShowEditModal(false);
                  setEditingTransaction(null);
                }}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleUpdateTransaction}
                className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:shadow-lg transition-all"
              >
                Salvar Alterações
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Filter Modal */}
      {showFilterModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-slate-200/50">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold text-slate-800">Filtrar Transações</h3>
                {activeFilterCount > 0 && (
                  <span className="bg-blue-100 text-blue-800 text-sm px-3 py-1 rounded-full">
                    {activeFilterCount} filtro{activeFilterCount > 1 ? 's' : ''} ativo{activeFilterCount > 1 ? 's' : ''}
                  </span>
                )}
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Date Range */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Data Inicial</label>
                  <input
                    type="date"
                    value={filters.dateFrom}
                    onChange={(e) => setFilters({...filters, dateFrom: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Data Final</label>
                  <input
                    type="date"
                    value={filters.dateTo}
                    onChange={(e) => setFilters({...filters, dateTo: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>

              {/* Category and Cost Center */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Categorias ({filters.categoryIds.length} selecionada{filters.categoryIds.length !== 1 ? 's' : ''})
                  </label>
                  <div className="relative">
                    <div className="border border-slate-300 rounded-lg p-3 max-h-40 overflow-y-auto bg-white">
                      <div className="space-y-2">
                        <label className="flex items-center gap-2 cursor-pointer hover:bg-slate-50 p-1 rounded">
                          <input
                            type="checkbox"
                            checked={filters.categoryIds.length === categories.length}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFilters({...filters, categoryIds: categories.map(c => c.id.toString())});
                              } else {
                                setFilters({...filters, categoryIds: []});
                              }
                            }}
                            className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                          />
                          <span className="text-sm font-medium text-slate-700">Todas as categorias</span>
                        </label>
                        <hr className="border-slate-200" />
                        {categories.map((category) => (
                          <label key={category.id} className="flex items-center gap-2 cursor-pointer hover:bg-slate-50 p-1 rounded">
                            <input
                              type="checkbox"
                              checked={filters.categoryIds.includes(category.id.toString())}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setFilters({
                                    ...filters, 
                                    categoryIds: [...filters.categoryIds, category.id.toString()]
                                  });
                                } else {
                                  setFilters({
                                    ...filters, 
                                    categoryIds: filters.categoryIds.filter(id => id !== category.id.toString())
                                  });
                                }
                              }}
                              className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm text-slate-700">{category.name}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Centros de Custo ({filters.costCenterIds.length} selecionado{filters.costCenterIds.length !== 1 ? 's' : ''})
                  </label>
                  <div className="relative">
                    <div className="border border-slate-300 rounded-lg p-3 max-h-40 overflow-y-auto bg-white">
                      <div className="space-y-2">
                        <label className="flex items-center gap-2 cursor-pointer hover:bg-slate-50 p-1 rounded">
                          <input
                            type="checkbox"
                            checked={filters.costCenterIds.length === costCenters.length}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFilters({...filters, costCenterIds: costCenters.map(cc => cc.id.toString())});
                              } else {
                                setFilters({...filters, costCenterIds: []});
                              }
                            }}
                            className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                          />
                          <span className="text-sm font-medium text-slate-700">Todos os centros de custo</span>
                        </label>
                        <hr className="border-slate-200" />
                        {costCenters.map((costCenter) => (
                          <label key={costCenter.id} className="flex items-center gap-2 cursor-pointer hover:bg-slate-50 p-1 rounded">
                            <input
                              type="checkbox"
                              checked={filters.costCenterIds.includes(costCenter.id.toString())}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setFilters({
                                    ...filters, 
                                    costCenterIds: [...filters.costCenterIds, costCenter.id.toString()]
                                  });
                                } else {
                                  setFilters({
                                    ...filters, 
                                    costCenterIds: filters.costCenterIds.filter(id => id !== costCenter.id.toString())
                                  });
                                }
                              }}
                              className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm text-slate-700">{costCenter.name}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Amount Range */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Valor Mínimo</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={filters.amountMin}
                    onChange={(e) => setFilters({...filters, amountMin: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="0.00"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Valor Máximo</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={filters.amountMax}
                    onChange={(e) => setFilters({...filters, amountMax: e.target.value})}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="0.00"
                  />
                </div>
              </div>

              {/* Transaction Type */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Tipo de Transação</label>
                <select
                  value={filters.transactionType}
                  onChange={(e) => setFilters({...filters, transactionType: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Todos os tipos</option>
                  <option value="income">Apenas Receitas</option>
                  <option value="expense">Apenas Despesas</option>
                </select>
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Descrição</label>
                <input
                  type="text"
                  value={filters.description}
                  onChange={(e) => setFilters({...filters, description: e.target.value})}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Buscar na descrição..."
                />
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-between">
              <div className="flex gap-3">
                <button
                  onClick={() => setShowFilterModal(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleClearFilters}
                  className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  Limpar Filtros
                </button>
              </div>
              <button
                onClick={handleApplyFilters}
                className="px-6 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:shadow-lg transition-all font-medium"
              >
                Aplicar Filtros
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clear All Transactions Modal */}
      {showClearModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="px-6 py-4 border-b border-slate-200/50 flex items-center gap-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold text-slate-800">Limpar Todas as Transações</h3>
            </div>
            
            <div className="p-6">
              <div className="mb-4">
                <p className="text-slate-700 mb-2">
                  <strong>Atenção:</strong> Esta ação irá remover permanentemente:
                </p>
                <ul className="list-disc list-inside text-sm text-slate-600 space-y-1 ml-4">
                  <li>Todas as transações registradas</li>
                  <li>Histórico completo de movimentações</li>
                  <li>Dados de receitas e despesas</li>
                </ul>
              </div>
              
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
                <p className="text-red-800 text-sm font-medium">
                  ⚠️ Esta ação não pode ser desfeita!
                </p>
                <p className="text-red-700 text-sm">
                  Certifique-se de ter um backup dos seus dados se necessário.
                </p>
              </div>
              
              <p className="text-slate-600 text-sm">
                As categorias e centros de custo permanecerão inalterados.
              </p>
            </div>
            
            <div className="px-6 py-4 border-t border-slate-200/50 flex gap-3 justify-end">
              <button
                onClick={() => setShowClearModal(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                disabled={clearing}
              >
                Cancelar
              </button>
              <button
                onClick={handleClearAllTransactions}
                disabled={clearing}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {clearing ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                    Limpando...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    Confirmar Limpeza
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
