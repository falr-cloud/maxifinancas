import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider } from "@/react-app/contexts/AuthContext";
import Layout from "@/react-app/components/Layout";
import ProtectedRoute from "@/react-app/components/ProtectedRoute";
import Login from "@/react-app/pages/Login";
import Dashboard from "@/react-app/pages/Dashboard";
import Transactions from "@/react-app/pages/Transactions";
import AccountsReceivable from "@/react-app/pages/AccountsReceivable";
import FixedAccounts from "@/react-app/pages/FixedAccounts";
import VariableAccounts from "@/react-app/pages/VariableAccounts";
import Payroll from "@/react-app/pages/Payroll";
import Settings from "@/react-app/pages/Settings";
import LicenseManagement from "@/react-app/pages/LicenseManagement";
import UserManagement from "@/react-app/pages/UserManagement";

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={
            <ProtectedRoute>
              <Layout>
                <Dashboard />
              </Layout>
            </ProtectedRoute>
          } />
          <Route path="/transactions" element={
            <ProtectedRoute>
              <Layout>
                <Transactions />
              </Layout>
            </ProtectedRoute>
          } />
          <Route path="/accounts-receivable" element={
            <ProtectedRoute>
              <Layout>
                <AccountsReceivable />
              </Layout>
            </ProtectedRoute>
          } />
          <Route path="/fixed-accounts" element={
            <ProtectedRoute>
              <Layout>
                <FixedAccounts />
              </Layout>
            </ProtectedRoute>
          } />
          <Route path="/variable-accounts" element={
            <ProtectedRoute>
              <Layout>
                <VariableAccounts />
              </Layout>
            </ProtectedRoute>
          } />
          <Route path="/payroll" element={
            <ProtectedRoute>
              <Layout>
                <Payroll />
              </Layout>
            </ProtectedRoute>
          } />
          <Route path="/reports" element={
            <ProtectedRoute>
              <Layout>
                <div className="p-8"><h1 className="text-2xl font-bold">Relatórios - Em Desenvolvimento</h1></div>
              </Layout>
            </ProtectedRoute>
          } />
          <Route path="/settings" element={
            <ProtectedRoute>
              <Layout>
                <Settings />
              </Layout>
            </ProtectedRoute>
          } />
          <Route path="/admin/licenses" element={
            <ProtectedRoute>
              <Layout>
                <LicenseManagement />
              </Layout>
            </ProtectedRoute>
          } />
          <Route path="/admin/users" element={
            <ProtectedRoute>
              <Layout>
                <UserManagement />
              </Layout>
            </ProtectedRoute>
          } />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
