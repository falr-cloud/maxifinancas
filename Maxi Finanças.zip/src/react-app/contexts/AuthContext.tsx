import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  tipo: string;
}

interface AuthContextType {
  user: User | null;
  isPending: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [isPending, setIsPending] = useState(true);

  // Check for existing session on mount
  useEffect(() => {
    const checkSession = () => {
      try {
        const savedUser = localStorage.getItem('maxifinancas_user');
        console.log('🔍 AUTH: Checking stored user data:', savedUser);
        
        if (savedUser) {
          const userData = JSON.parse(savedUser);
          console.log('🔍 AUTH: Parsed user data:', userData);
          
          if (userData && userData.id && userData.email) {
            setUser(userData);
            console.log('✅ AUTH: User restored from localStorage');
            
            // Also ensure cookies are set for backend requests
            const sessionData = JSON.stringify(userData);
            const encodedUserData = encodeURIComponent(sessionData);
            document.cookie = `user_session=${encodedUserData}; path=/; max-age=${7 * 24 * 60 * 60}; SameSite=Lax`;
            document.cookie = `maxifinancas_user=${encodedUserData}; path=/; max-age=${7 * 24 * 60 * 60}; SameSite=Lax`;
            console.log('🍪 AUTH: Cookies refreshed from localStorage');
          } else {
            console.log('❌ AUTH: Invalid user data structure, clearing storage');
            localStorage.removeItem('maxifinancas_user');
            setUser(null);
          }
        } else {
          console.log('ℹ️ AUTH: No stored user data found');
          setUser(null);
        }
      } catch (error) {
        console.error('❌ AUTH: Error checking session:', error);
        localStorage.removeItem('maxifinancas_user');
        setUser(null);
      } finally {
        setIsPending(false);
      }
    };

    checkSession();
  }, []);

  const login = async (email: string, password: string) => {
    try {
      console.log('🔑 FRONTEND: Starting login for:', email);
      setIsPending(true);
      
      const response = await fetch('/api/usuarios/auth', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ email, senha: password }),
      });
      
      console.log('🔑 FRONTEND: Login response status:', response.status);
      console.log('🔑 FRONTEND: Response headers:', Object.fromEntries(response.headers.entries()));

      const data = await response.json();
      console.log('🔑 FRONTEND: Response data:', data);

      if (!response.ok) {
        throw new Error(data.error || 'Erro ao fazer login');
      }

      if (data.success && data.user) {
        const userData: User = {
          id: data.user.id,
          name: data.user.name,
          email: data.user.email,
          tipo: data.user.tipo,
        };
        
        console.log('🔑 FRONTEND: Setting user data:', userData);
        setUser(userData);
        localStorage.setItem('maxifinancas_user', JSON.stringify(userData));
        
        // Also set cookies manually for immediate API requests
        const sessionData = JSON.stringify(userData);
        const encodedUserData = encodeURIComponent(sessionData);
        document.cookie = `user_session=${encodedUserData}; path=/; max-age=${7 * 24 * 60 * 60}; SameSite=Lax`;
        document.cookie = `maxifinancas_user=${encodedUserData}; path=/; max-age=${7 * 24 * 60 * 60}; SameSite=Lax`;
        
        console.log('✅ FRONTEND: Login successful, user data stored and cookies set');
      } else {
        throw new Error('Credenciais inválidas');
      }
    } catch (error) {
      console.error('❌ FRONTEND: Login error:', error);
      throw error;
    } finally {
      setIsPending(false);
    }
  };

  const logout = () => {
    console.log('🚪 FRONTEND: Logging out user');
    setUser(null);
    localStorage.removeItem('maxifinancas_user');
    
    // Clear any cookies that might exist
    document.cookie = 'user_session=; path=/; max-age=0';
    document.cookie = 'maxifinancas_user=; path=/; max-age=0';
    
    window.location.href = '/login';
  };

  const value = {
    user,
    isPending,
    login,
    logout,
  };

  console.log('🔍 AUTH: Current auth state:', {
    user: user ? { id: user.id, email: user.email } : null,
    isPending
  });

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
