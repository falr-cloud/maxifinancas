import z from "zod";

export const CategorySchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CostCenterSchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const TransactionSchema = z.object({
  id: z.number(),
  date: z.string(),
  description: z.string(),
  amount: z.number(),
  category_id: z.number().nullable(),
  cost_center_id: z.number().nullable(),
  is_recurring: z.number(),
  status: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateTransactionSchema = z.object({
  date: z.string(),
  description: z.string(),
  amount: z.number(),
  category_id: z.number().optional(),
  cost_center_id: z.number().optional(),
  is_recurring: z.boolean().optional(),
  status: z.string().optional(),
});

export const UpdateTransactionSchema = z.object({
  date: z.string().optional(),
  description: z.string().optional(),
  amount: z.number().optional(),
  category_id: z.number().optional(),
  cost_center_id: z.number().optional(),
  is_recurring: z.boolean().optional(),
  status: z.string().optional(),
});

export const CreateCategorySchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
});

export const UpdateCategorySchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
});

export const CreateCostCenterSchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
});

export const UpdateCostCenterSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
});

export type Category = z.infer<typeof CategorySchema>;
export type CostCenter = z.infer<typeof CostCenterSchema>;
export type Transaction = z.infer<typeof TransactionSchema>;
export type CreateTransaction = z.infer<typeof CreateTransactionSchema>;
export type UpdateTransaction = z.infer<typeof UpdateTransactionSchema>;
export type CreateCategory = z.infer<typeof CreateCategorySchema>;
export type UpdateCategory = z.infer<typeof UpdateCategorySchema>;
export type CreateCostCenter = z.infer<typeof CreateCostCenterSchema>;
export type UpdateCostCenter = z.infer<typeof UpdateCostCenterSchema>;

export const FixedAccountSchema = z.object({
  id: z.number(),
  due_day: z.number(),
  description: z.string(),
  amount: z.number(),
  category_id: z.number().nullable(),
  cost_center_id: z.number().nullable(),
  payee: z.string(),
  is_active: z.number(),
  status: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateFixedAccountSchema = z.object({
  due_day: z.number().min(1).max(31),
  description: z.string().min(1),
  amount: z.number(),
  category_id: z.number().optional(),
  cost_center_id: z.number().optional(),
  payee: z.string().min(1),
  is_active: z.boolean().optional(),
});

export const UpdateFixedAccountSchema = z.object({
  due_day: z.number().min(1).max(31).optional(),
  description: z.string().min(1).optional(),
  amount: z.number().optional(),
  category_id: z.number().optional(),
  cost_center_id: z.number().optional(),
  payee: z.string().min(1).optional(),
  is_active: z.boolean().optional(),
  status: z.string().optional(),
});

export type FixedAccount = z.infer<typeof FixedAccountSchema>;
export type CreateFixedAccount = z.infer<typeof CreateFixedAccountSchema>;
export type UpdateFixedAccount = z.infer<typeof UpdateFixedAccountSchema>;

export interface TransactionWithDetails extends Transaction {
  category?: Category;
  cost_center?: CostCenter;
}

export interface FixedAccountWithDetails extends FixedAccount {
  category?: Category;
  cost_center?: CostCenter;
}

export const VariableAccountSchema = z.object({
  id: z.number(),
  due_date: z.string(),
  description: z.string(),
  amount: z.number(),
  category_id: z.number().nullable(),
  cost_center_id: z.number().nullable(),
  payee: z.string(),
  status: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateVariableAccountSchema = z.object({
  due_date: z.string(),
  description: z.string().min(1),
  amount: z.number(),
  category_id: z.number().optional(),
  cost_center_id: z.number().optional(),
  payee: z.string().min(1),
  status: z.string().optional(),
});

export const UpdateVariableAccountSchema = z.object({
  due_date: z.string().optional(),
  description: z.string().min(1).optional(),
  amount: z.number().optional(),
  category_id: z.number().optional(),
  cost_center_id: z.number().optional(),
  payee: z.string().min(1).optional(),
  status: z.string().optional(),
});

export type VariableAccount = z.infer<typeof VariableAccountSchema>;
export type CreateVariableAccount = z.infer<typeof CreateVariableAccountSchema>;
export type UpdateVariableAccount = z.infer<typeof UpdateVariableAccountSchema>;

export interface VariableAccountWithDetails extends VariableAccount {
  category?: Category;
  cost_center?: CostCenter;
}

export const PayrollSchema = z.object({
  id: z.number(),
  description: z.string(),
  category_id: z.number().nullable(),
  cost_center_id: z.number().nullable(),
  amount: z.number(),
  status: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreatePayrollSchema = z.object({
  description: z.string().min(1),
  category_id: z.number().optional(),
  cost_center_id: z.number().optional(),
  amount: z.number(),
  status: z.string().optional(),
});

export const UpdatePayrollSchema = z.object({
  description: z.string().min(1).optional(),
  category_id: z.number().optional(),
  cost_center_id: z.number().optional(),
  amount: z.number().optional(),
  status: z.string().optional(),
});

export type Payroll = z.infer<typeof PayrollSchema>;
export type CreatePayroll = z.infer<typeof CreatePayrollSchema>;
export type UpdatePayroll = z.infer<typeof UpdatePayrollSchema>;

export interface PayrollWithDetails extends Payroll {
  category?: Category;
  cost_center?: CostCenter;
}

export const PayrollDescriptionSchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  tipo: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreatePayrollDescriptionSchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
  tipo: z.string().optional(),
});

export const UpdatePayrollDescriptionSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
  tipo: z.string().optional(),
});

export type PayrollDescription = z.infer<typeof PayrollDescriptionSchema>;
export type CreatePayrollDescription = z.infer<typeof CreatePayrollDescriptionSchema>;
export type UpdatePayrollDescription = z.infer<typeof UpdatePayrollDescriptionSchema>;

// Accounts Receivable Schemas
export const AccountsReceivableSchema = z.object({
  id: z.number(),
  due_date: z.string(),
  description: z.string(),
  amount: z.number(),
  category_id: z.number().nullable(),
  cost_center_id: z.number().nullable(),
  payer: z.string(),
  status: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateAccountsReceivableSchema = z.object({
  due_date: z.string(),
  description: z.string().min(1),
  amount: z.number().positive(),
  category_id: z.number().optional(),
  cost_center_id: z.number().optional(),
  payer: z.string().min(1),
  status: z.string().optional(),
});

export const UpdateAccountsReceivableSchema = z.object({
  due_date: z.string().optional(),
  description: z.string().min(1).optional(),
  amount: z.number().positive().optional(),
  category_id: z.number().optional(),
  cost_center_id: z.number().optional(),
  payer: z.string().min(1).optional(),
  status: z.string().optional(),
});

export type AccountsReceivable = z.infer<typeof AccountsReceivableSchema>;
export type CreateAccountsReceivable = z.infer<typeof CreateAccountsReceivableSchema>;
export type UpdateAccountsReceivable = z.infer<typeof UpdateAccountsReceivableSchema>;

export interface AccountsReceivableWithDetails extends AccountsReceivable {
  category?: Category;
  cost_center?: CostCenter;
}

// License Schemas
export const LicenseSchema = z.object({
  id: z.number(),
  usuario_id: z.string(),
  plano: z.string(),
  data_inicio: z.string(),
  data_fim: z.string(),
  status: z.string(),
  observacoes: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateLicenseSchema = z.object({
  usuario_id: z.string().min(1),
  plano: z.string().min(1),
  data_inicio: z.string(),
  data_fim: z.string(),
  status: z.string().optional(),
  observacoes: z.string().optional(),
});

export const UpdateLicenseSchema = z.object({
  usuario_id: z.string().min(1).optional(),
  plano: z.string().min(1).optional(),
  data_inicio: z.string().optional(),
  data_fim: z.string().optional(),
  status: z.string().optional(),
  observacoes: z.string().optional(),
});

export type License = z.infer<typeof LicenseSchema>;
export type CreateLicense = z.infer<typeof CreateLicenseSchema>;
export type UpdateLicense = z.infer<typeof UpdateLicenseSchema>;
