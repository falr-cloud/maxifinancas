
ALTER TABLE transactions DROP COLUMN status;
