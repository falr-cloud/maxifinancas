
-- Remove user_id column from all tables
ALTER TABLE categories DROP COLUMN user_id;
ALTER TABLE cost_centers DROP COLUMN user_id;
ALTER TABLE transactions DROP COLUMN user_id;
ALTER TABLE fixed_accounts DROP COLUMN user_id;
ALTER TABLE variable_accounts DROP COLUMN user_id;
ALTER TABLE payroll DROP COLUMN user_id;
ALTER TABLE payroll_descriptions DROP COLUMN user_id;
ALTER TABLE accounts_receivable DROP COLUMN user_id;
