
-- Add user_id column to all tables
ALTER TABLE categories ADD COLUMN user_id TEXT;
ALTER TABLE cost_centers ADD COLUMN user_id TEXT;
ALTER TABLE transactions ADD COLUMN user_id TEXT;
ALTER TABLE fixed_accounts ADD COLUMN user_id TEXT;
ALTER TABLE variable_accounts ADD COLUMN user_id TEXT;
ALTER TABLE payroll ADD COLUMN user_id TEXT;
ALTER TABLE payroll_descriptions ADD COLUMN user_id TEXT;
ALTER TABLE accounts_receivable ADD COLUMN user_id TEXT;
