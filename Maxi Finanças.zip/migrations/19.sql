
ALTER TABLE payroll_descriptions ADD COLUMN tipo TEXT;
