
DROP TABLE payroll_descriptions;
