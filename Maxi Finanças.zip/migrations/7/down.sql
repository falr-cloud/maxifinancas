
DROP TABLE variable_accounts;
