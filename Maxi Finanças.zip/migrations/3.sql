
-- Adicionar categorias padrão
INSERT INTO categories (name, description, color) VALUES
('Alimentação', 'Gastos com comida e bebida', '#ef4444'),
('Transporte', 'Combustível, transporte público, Uber', '#f97316'),
('Moradia', 'Aluguel, financiamento, condomínio', '#22c55e'),
('Saúde', 'Médicos, medicamentos, plano de saúde', '#06b6d4'),
('Educação', 'Cursos, livros, escola', '#8b5cf6'),
('Lazer', 'Cinema, restaurantes, viagens', '#ec4899'),
('Serviços', 'Internet, telefone, streaming', '#64748b'),
('Receita', 'Salário, freelances, vendas', '#10b981');

-- Adicionar centros de custo padrão
INSERT INTO cost_centers (name, description) VALUES
('Pessoal', 'Gastos pessoais e familiares'),
('Trabalho', 'Despesas relacionadas ao trabalho'),
('Casa', 'Manutenção e melhorias da casa'),
('Investimentos', 'Aplicações e investimentos');
