
DROP TABLE transactions;
DROP TABLE cost_centers;
DROP TABLE categories;
