
DROP TABLE fixed_accounts;
