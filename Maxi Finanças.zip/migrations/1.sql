
CREATE TABLE categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  color TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE cost_centers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date DATE NOT NULL,
  description TEXT NOT NULL,
  amount REAL NOT NULL,
  category_id INTEGER,
  cost_center_id INTEGER,
  is_recurring BOOLEAN DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO categories (name, description, color) VALUES
  ('Aluguel', 'Despesas com aluguel e condomínio', '#ef4444'),
  ('Serviços Contábeis', 'Gastos com contabilidade', '#3b82f6'),
  ('Salários', 'Pagamentos de funcionários', '#10b981'),
  ('Outros Gastos Fixos', 'Demais gastos fixos', '#8b5cf6'),
  ('Comissão sobre Vendas', 'Comissões pagas', '#f59e0b');

INSERT INTO cost_centers (name, description) VALUES
  ('Recorrente', 'Custos recorrentes'),
  ('Outros', 'Outros custos'),
  ('Comissão', 'Centro de custos para comissões');
