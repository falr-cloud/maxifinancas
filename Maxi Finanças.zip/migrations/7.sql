
CREATE TABLE variable_accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  due_date DATE NOT NULL,
  description TEXT NOT NULL,
  amount REAL NOT NULL,
  category_id INTEGER,
  cost_center_id INTEGER,
  payee TEXT NOT NULL,
  status TEXT DEFAULT 'NÃO PAGO',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
