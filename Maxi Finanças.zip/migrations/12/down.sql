
DROP INDEX IF EXISTS idx_licencas_data_fim;
DROP INDEX IF EXISTS idx_licencas_status;
DROP INDEX IF EXISTS idx_licencas_usuario_id;
DROP TABLE licencas;
