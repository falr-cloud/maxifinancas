
-- Não há mudanças para reverter
SELECT 1;
