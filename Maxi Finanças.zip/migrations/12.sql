
CREATE TABLE licencas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id TEXT NOT NULL,
  plano TEXT NOT NULL,
  data_inicio DATETIME NOT NULL,
  data_fim DATETIME NOT NULL,
  status TEXT NOT NULL DEFAULT 'ativa',
  observacoes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_licencas_usuario_id ON licencas(usuario_id);
CREATE INDEX idx_licencas_status ON licencas(status);
CREATE INDEX idx_licencas_data_fim ON licencas(data_fim);
