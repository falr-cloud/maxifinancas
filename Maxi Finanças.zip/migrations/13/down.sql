
DROP TABLE usuarios;
