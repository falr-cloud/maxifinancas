
-- Remove test users
DELETE FROM usuarios WHERE id IN ('admin-user', 'user-demo');
