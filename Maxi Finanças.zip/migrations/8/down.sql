
DROP TABLE payroll;
