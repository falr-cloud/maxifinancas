
CREATE TABLE usuarios (
  id TEXT PRIMARY KEY,
  nome TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  senha_hash TEXT NOT NULL,
  tipo TEXT DEFAULT 'usuario',
  ativo BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Inserir usuários padrão
INSERT INTO usuarios (id, nome, email, senha_hash, tipo, ativo) VALUES 
('admin-user', 'Administrador', 'admin@maxifinancas.com', 'admin123', 'admin', 1),
('default-user', 'Usuário Padrão', 'usuario@maxifinancas.com', 'user123', 'usuario', 1),
('cliente-001', 'Cliente Teste 1', 'cliente1@teste.com', 'teste123', 'usuario', 1),
('cliente-002', 'Cliente Teste 2', 'cliente2@teste.com', 'teste123', 'usuario', 1),
('cliente-003', 'Maria Silva', 'maria@empresa.com', 'senha123', 'usuario', 1);
