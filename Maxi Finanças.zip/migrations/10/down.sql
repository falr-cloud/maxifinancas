
DROP TABLE accounts_receivable;
