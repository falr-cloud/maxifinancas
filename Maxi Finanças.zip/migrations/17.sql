
-- A coluna 'tipo' já existe na tabela payroll_descriptions
-- Não é necessário criar nenhuma nova coluna
SELECT 1;
