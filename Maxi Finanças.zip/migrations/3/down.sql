
-- Remover dados padrão
DELETE FROM categories WHERE name IN ('Alimentação', 'Transporte', 'Moradia', 'Saúde', 'Educação', 'Lazer', 'Serviços', 'Receita');
DELETE FROM cost_centers WHERE name IN ('Pessoal', 'Trabalho', 'Casa', 'Investimentos');
