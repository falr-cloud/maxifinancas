
DELETE FROM transactions;
