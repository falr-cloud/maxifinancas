
-- Insert test users if they don't exist
INSERT OR IGNORE INTO usuarios (id, nome, email, senha_hash, tipo, ativo) 
VALUES 
('admin-user', 'Administrador', 'admin@maxifinancas.com', 'admin123', 'admin', 1),
('user-demo', 'Usuário de Demonstração', 'usuario@maxifinancas.com', 'user123', 'usuario', 1);
