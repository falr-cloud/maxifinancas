
ALTER TABLE payroll_descriptions DROP COLUMN tipo;
